---
name: btg-pactual-pdf-reports
description: Genera informes PDF corporativos con la identidad de marca de BTG Pactual (azul marino #1E2A52/#2F3D72 + azul cian #00A0E3) a partir de cualquier documento de análisis, backlog de casos, incidentes o datos tabulares. Usa esta skill siempre que el usuario pida un "PDF corporativo para BTG Pactual", un "informe" o "reporte" con los colores/paleta de BTG, o quiera reproducir/extender el estilo del informe de casos de Beneficiarios Finales. También aplica al convertir un .md, .csv o análisis de Jira en un PDF ejecutivo con portada, tarjetas de estadísticas, tablas con badges de estado y gráficos de marca — incluso si no se menciona "BTG" explícitamente pero el contexto del workspace es claramente de esa organización.
license: Proprietary. Internal use — BTG Pactual.
compatibility: Requiere Python 3.9+, y las librerías weasyprint y matplotlib. Para el control de calidad visual requiere poppler-utils (pdftoppm). Sin dependencia de red salvo para instalar esos paquetes.
metadata:
  author: btg-it-colombia
  version: "1.0"
  origin: adaptado desde la skill equivalente para Claude (mismo estándar Agent Skills, agentskills.io)
---

# Informes PDF corporativos BTG Pactual (Kiro)

Skill para producir documentos PDF densos en datos (análisis de casos, incidentes, backlogs,
resúmenes ejecutivos) con el sistema de diseño de marca de BTG Pactual: portada de gradiente
navy/azure, tarjetas de estadísticas, callouts semánticos, fichas de grupo, tablas con badges de
estado y gráficos matplotlib en la misma paleta.

Esta skill sigue el estándar abierto [Agent Skills](https://agentskills.io) — el mismo `SKILL.md`
(carpeta `scripts/` + `references/`) funciona igual en Kiro y en Claude sin modificarlo. Si tu
equipo también usa Claude, pueden compartir literalmente la misma carpeta entre `.kiro/skills/` y
`.claude/skills/` (o el directorio de skills de Claude que corresponda).

## Dónde vive esta skill en Kiro

- **Workspace** (solo este proyecto): `<raíz-del-repo>/.kiro/skills/btg-pactual-pdf-reports/`
- **Global** (todos tus proyectos): `~/.kiro/skills/btg-pactual-pdf-reports/`

Si el nombre coincide en ambos niveles, Kiro prioriza la versión de workspace. Para un equipo que
comparte estos informes, lo recomendable es commitear la carpeta bajo `.kiro/skills/` en el
repositorio del equipo, para que todos activen la misma versión.

**Importante:** el nombre de la carpeta debe coincidir exactamente con el campo `name` del
frontmatter (`btg-pactual-pdf-reports`) — es un requisito del estándar, no solo una convención.

## Cómo se activa

Kiro activa esta skill automáticamente cuando tu petición coincide con la `description` de arriba.
También puedes invocarla de forma explícita escribiendo `/` en el chat y seleccionándola de la lista
de slash commands, si quieres forzar su uso o revisar sus instrucciones sin depender del
auto-match.

## Cuándo usarla

- Piden explícitamente un PDF/informe "para BTG Pactual" o "con los colores corporativos".
- Adjuntan o referencian un `.md`/`.csv`/análisis de Jira y piden convertirlo en un reporte ejecutivo.
- Piden reproducir o extender el estilo de un informe BTG ya generado antes.
- Piden "lineamientos de estilo" o "guía de marca" para replicar este tipo de informe.

## Requisitos previos (verificar siempre al inicio de la tarea)

Esta skill no asume un entorno sandboxed específico — corre en el proyecto real del usuario, así
que verifica el entorno antes de generar nada:

```bash
python3 -c "import weasyprint" 2>&1 || pip install weasyprint
# En macOS/Linux con paquetes del sistema gestionados externamente, puede requerir:
#   pip install weasyprint --break-system-packages
# o crear un virtualenv dedicado si el proyecto ya usa uno.

python3 -c "import matplotlib" 2>&1 || pip install matplotlib

# Para el control de calidad visual (renderizar páginas del PDF a imagen):
which pdftoppm || echo "Instala poppler-utils: apt install poppler-utils (Linux) / brew install poppler (macOS)"
```

Confirma también qué fuente sans-serif corporativa hay disponible en la máquina del usuario. Si no
hay "Liberation Sans" ni "Arial", usa "DejaVu Sans" o la fuente sans-serif por defecto del sistema
como fallback en el CSS — no bloquees la generación del informe por esto.

## Flujo de trabajo (sigue este orden — no lo saltes)

### 1. Ingerir y entender el documento fuente
Lee el documento/datos completos del usuario. Si es largo, léelo en partes — nunca resumas ni
generes contenido a partir de una lectura parcial/truncada. Identifica: secciones numeradas
existentes, tablas, cifras clave, casos/IDs individuales, estados, fechas.

### 2. Extraer los datos tabulares a estructuras Python
**No transcribas tablas largas directo a strings HTML.** Crea un archivo `data.py` (en el workspace
del proyecto, no dentro de la carpeta de la skill) con listas de tuplas/diccionarios para cada tabla
del documento fuente. Verifica los conteos con `assert len(...) == N` contra los totales que el
propio documento declara — esto es lo que más reduce errores de transcripción.

### 3. Preparar los gráficos
Importa `scripts/report_toolkit.py` de esta skill y usa `mpl_style()` / `style_axes()` para que
cualquier gráfico matplotlib use la paleta BTG automáticamente. Guarda cada gráfico como PNG
transparente en una carpeta `assets/` del proyecto del usuario (no en la carpeta de la skill).

### 4. Construir el HTML con los helpers del toolkit
```python
import sys; sys.path.insert(0, "<ruta-a-esta-skill>/scripts")
from report_toolkit import wrap_document, cover_page, section, stat_card, callout, data_table, status_badge, tags, img_tag
```
Usa `cover_page()`, `section()`, `stat_card()`, `callout()`, `group_card()`, `data_table()`,
`status_badge()`, `tags()` para ensamblar el documento pieza por pieza. Ver `references/usage.md`
para un ejemplo completo. **No inventes componentes nuevos fuera del sistema de diseño** salvo que
te lo pidan explícitamente — la consistencia entre informes es el punto de esta skill.

### 5. Renderizar a PDF
```python
from weasyprint import HTML
HTML("informe.html").write_pdf("informe.pdf")
```

### 6. Control de calidad visual — obligatorio
Nunca entregues un PDF corporativo sin revisarlo visualmente primero:
```bash
pdftoppm -png -r 110 -f <pagina> -l <pagina> informe.pdf qa/p<N>
```
Abre esas imágenes (con el visor de imágenes de tu editor, o pidiéndole a Kiro que las lea) y
revisa al menos: la portada, una página de resumen/estadísticas, una página con tabla larga, y la
última página. Verifica que no haya texto cortado, tablas desbordadas, ni encabezados huérfanos al
final de una página. Corrige y vuelve a renderizar si algo se ve mal — que WeasyPrint no lance error
no significa que el diseño esté bien.

### 7. Entregar
Guarda el PDF final en la carpeta de salida que uses en este proyecto (p. ej. `./reports/` o
`./output/`) con un nombre descriptivo.

## Reglas de fidelidad de datos (no negociables)

- Nunca "corrijas" una cifra del documento fuente aunque parezca inconsistente (ej. una suma que no
  cuadra). Repórtala tal cual — el diseño no reinterpreta el contenido.
- Nunca inventes IDs, nombres, fechas o cifras que no estén en la fuente.
- Si el documento fuente tiene numeración de secciones (1., 2., 3.…), consérvala igual en el PDF.
- Todo ticket/caso mencionado debe verse igual (mismo formato/prefijo) que en la fuente.

## Archivos de referencia

- `references/style-guide.md` — el sistema de diseño completo y autocontenido (colores exactos,
  tipografía, retícula, especificación de cada componente). Léelo siempre que generes un informe
  nuevo para no perder ningún detalle de estilo. Es también el documento que se le puede entregar a
  cualquier persona (o a otra IA sin esta skill instalada) como "lineamientos de estilo" portables.
- `references/usage.md` — ejemplo end-to-end funcional (portada + 2 secciones + tabla + gráfico).
- `scripts/report_toolkit.py` — el CSS framework completo (`BTG_CSS`) más todos los helpers Python
  (`cover_page`, `section`, `stat_card`, `callout`, `group_card`, `data_table`, `status_badge`,
  `tags`, `mpl_style`, `style_axes`, `img_tag`, etc.). Impórtalo siempre en vez de reescribir CSS
  desde cero — esa es la garantía de que dos informes distintos se vean como la misma familia visual.

## Extendiendo el sistema

Si un informe nuevo necesita un componente que no existe (ej. un semáforo de riesgo, un mapa de
calor), añádelo a `BTG_CSS` en `scripts/report_toolkit.py` siguiendo los mismos tokens de color y
las mismas convenciones de espaciado (`.32cm`, `.4cm`, bordes `1px solid var(--gray-300)`, radios de
4-8px) en vez de crear un estilo aislado solo para ese informe. Si esta skill es de workspace,
commitea el cambio junto con el resto del repo para que el equipo lo herede.

## Diferencia con Steering y Powers de Kiro

Esto es una **skill** (paquete portable, se activa on-demand, incluye código ejecutable) — no un
steering file. Si además quieres que Kiro *siempre* recuerde, por ejemplo, "en este proyecto los
informes van en `./reports/beneficiarios-finales/`", eso es mejor guardarlo como steering
(`.kiro/steering/`, modo `always` o `fileMatch`), no dentro de esta skill. Mantén ambos mecanismos
separados: steering = contexto permanente del proyecto; skills = cómo ejecutar esta tarea específica.
