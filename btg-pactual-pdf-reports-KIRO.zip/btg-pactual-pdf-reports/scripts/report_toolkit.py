# -*- coding: utf-8 -*-
"""
report_toolkit.py — Motor reutilizable para informes PDF corporativos BTG Pactual.

Provee:
  - BTG_CSS: framework CSS completo (design tokens + componentes) listo para
    inyectar en un <style> de un documento HTML que luego se renderiza con WeasyPrint.
  - Helpers de Python para construir piezas de HTML sin errores de transcripción
    (tags de grupo, badges de estado, escapado, imágenes embebidas en base64).
  - mpl_style(): aplica la paleta BTG a matplotlib para que los gráficos combinen
    visualmente con el documento.

Ver references/style-guide.md para la explicación completa de cada decisión de diseño.
Ver references/usage.md para un ejemplo end-to-end.
"""
import base64
import html

# ----------------------------------------------------------------------------
# 1) PALETA DE COLORES BTG PACTUAL (fuente: identidad de marca real)
# ----------------------------------------------------------------------------
COLORS = {
    "navy":        "#1E2A52",
    "navy2":       "#2F3D72",
    "azure":       "#00A0E3",
    "azure_light": "#EAF7FD",
    "azure_mid":   "#CBEBF9",
    "gray50":      "#F7F8FA",
    "gray100":     "#EEF1F5",
    "gray300":     "#D5DAE1",
    "gray500":     "#8A93A3",
    "gray700":     "#5B6472",
    "ink":         "#1B222C",
    "amber":       "#D98C00",
    "amber_bg":    "#FCF1DD",
    "red":         "#C0392B",
    "red_bg":      "#FBE7E4",
    "green":       "#1E8E5A",
    "green_bg":    "#E4F5EC",
    "gray_bg":     "#EEF0F3",
}

# ----------------------------------------------------------------------------
# 2) CSS FRAMEWORK — pégalo dentro de <style>{BTG_CSS}</style>
#    Cambia el texto de los @top-left / @top-right si quieres otro encabezado.
# ----------------------------------------------------------------------------
BTG_CSS = """
@page {
  size: A4;
  margin: 2.05cm 1.7cm 1.95cm 1.7cm;
  @top-left {
    content: "Informe · BTG Pactual";
    font-family: "Liberation Sans"; font-size: 7.6pt; color: #8A93A3;
    letter-spacing: .02em;
  }
  @top-right {
    content: "BTG Pactual  —  Confidencial";
    font-family: "Liberation Sans"; font-size: 7.6pt; color: #2F3D72; font-weight: 700;
    letter-spacing: .03em;
  }
  @bottom-left {
    content: "Documento interno";
    font-family: "Liberation Sans"; font-size: 7.4pt; color: #B0B6C0;
  }
  @bottom-right {
    content: "Página " counter(page) " de " counter(pages);
    font-family: "Liberation Sans"; font-size: 7.4pt; color: #B0B6C0;
  }
}
@page cover { margin: 0; }

* { box-sizing: border-box; }
html, body {
  margin: 0; padding: 0;
  font-family: "Liberation Sans", sans-serif;
  color: #232B3D; font-size: 9.6pt; line-height: 1.52;
}
:root {
  --navy: #1E2A52; --navy2: #2F3D72; --azure: #00A0E3;
  --azure-light: #EAF7FD; --azure-mid: #CBEBF9;
  --gray-50: #F7F8FA; --gray-100: #EEF1F5; --gray-300: #D5DAE1;
  --gray-500: #8A93A3; --gray-700: #5B6472; --ink: #1B222C;
  --amber: #D98C00; --amber-bg: #FCF1DD;
  --red: #C0392B; --red-bg: #FBE7E4;
  --green: #1E8E5A; --green-bg: #E4F5EC; --gray-bg: #EEF0F3;
}

/* ---------------- COVER ---------------- */
.cover {
  page: cover; position: relative; width: 21cm; height: 29.7cm;
  background: linear-gradient(160deg, var(--navy) 0%, var(--navy2) 62%, #274A82 100%);
  color: white; overflow: hidden;
}
.cover .arc { position: absolute; border-radius: 50%; border: 1.4px solid rgba(255,255,255,0.14); }
.cover .arc1 { width: 30cm; height: 30cm; right: -13cm; top: -9cm; }
.cover .arc2 { width: 24cm; height: 24cm; right: -10cm; top: -6cm; border-color: rgba(0,160,227,0.35); }
.cover .arc3 { width: 18cm; height: 18cm; right: -7cm; top: -3cm; border-color: rgba(255,255,255,0.10); }
.cover .azure-dot {
  position: absolute; width: 9cm; height: 9cm; border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, rgba(0,160,227,0.55), rgba(0,160,227,0) 70%);
  right: -2.4cm; bottom: -2.5cm;
}
.cover-inner { position: relative; z-index: 2; padding: 2.6cm 2.2cm 0 2.2cm; height: 100%; }
.cover-brand { display: flex; align-items: center; gap: .32cm; }
.cover-brand .mark { width: .62cm; height: .62cm; border-radius: 50%; background: linear-gradient(135deg, var(--azure), #6FCBEF); }
.cover-brand .word { font-size: 15pt; font-weight: 700; letter-spacing: .02em; color: #FFFFFF; }
.cover-brand .word b { color: var(--azure); font-weight: 700; }
.cover-kicker {
  margin-top: 3.6cm; display: inline-block; font-size: 8pt; letter-spacing: .16em;
  text-transform: uppercase; color: var(--azure); font-weight: 700;
  border: 1px solid rgba(0,160,227,0.55); padding: .18cm .38cm; border-radius: 20px;
}
.cover h1 { font-size: 29pt; line-height: 1.18; font-weight: 700; color: #fff; margin: .55cm 0 0 0; max-width: 15cm; }
.cover h1 .accent { color: var(--azure); }
.cover .subtitle { margin-top: .45cm; font-size: 12.5pt; color: #C9D6EE; max-width: 13.5cm; font-weight: 400; }
.cover-meta { margin-top: 1.5cm; display: flex; flex-wrap: wrap; gap: .9cm; }
.cover-meta .item { min-width: 4.6cm; }
.cover-meta .label { font-size: 7.6pt; text-transform: uppercase; letter-spacing: .1em; color: #8FA3CC; margin-bottom: .12cm; }
.cover-meta .value { font-size: 10.5pt; color: #fff; font-weight: 700; }
.cover-bottom {
  position: absolute; left: 2.2cm; right: 2.2cm; bottom: 1.5cm; z-index: 2;
  display: flex; justify-content: space-between; align-items: flex-end;
  border-top: 1px solid rgba(255,255,255,0.18); padding-top: .5cm;
}
.cover-bottom .conf { font-size: 8pt; color: #AEB9D6; max-width: 10.5cm; line-height: 1.5; }
.cover-bottom .num { text-align: right; }
.cover-bottom .num .big { font-size: 26pt; font-weight: 700; color: #fff; }
.cover-bottom .num .small { font-size: 7.6pt; color: #8FA3CC; text-transform: uppercase; letter-spacing: .08em; }

/* ---------------- CONTENT ---------------- */
.section { page-break-before: always; }
.section:first-child { page-break-before: avoid; }
h1.h-section {
  font-size: 16.5pt; color: var(--navy); font-weight: 700; margin: 0 0 .12cm 0;
  padding-bottom: .22cm; border-bottom: 2.4px solid var(--navy2);
  display: flex; align-items: baseline; gap: .28cm;
}
h1.h-section .num { display: inline-block; color: var(--azure); font-weight: 700; }
h2.h-sub { font-size: 11.8pt; color: var(--navy2); font-weight: 700; margin: .62cm 0 .28cm 0; }
h3.h-sub3 { font-size: 10.2pt; color: var(--navy2); font-weight: 700; margin: .4cm 0 .16cm 0; }
p { margin: .18cm 0; text-align: left; }
.lead { font-size: 10.6pt; color: #3A4256; }
strong { color: var(--navy); }
.small { font-size: 8.4pt; color: var(--gray-700); }
.mono { font-family: "Liberation Mono", monospace; }

.stat-grid { display: flex; gap: .32cm; margin: .35cm 0 .5cm 0; flex-wrap: wrap; }
.stat-card { flex: 1; min-width: 3.6cm; background: var(--gray-50); border: 1px solid var(--gray-300);
  border-radius: 6px; padding: .32cm .34cm; border-top: 3px solid var(--azure); }
.stat-card .n { font-size: 17pt; font-weight: 700; color: var(--navy); line-height: 1.05; }
.stat-card .l { font-size: 7.6pt; color: var(--gray-700); margin-top: .1cm; line-height: 1.3; }
.stat-card.hi { border-top-color: var(--red); } .stat-card.hi .n { color: var(--red); }
.stat-card.ok { border-top-color: var(--green); } .stat-card.ok .n { color: var(--green); }

.callout { background: var(--azure-light); border-left: 4px solid var(--azure); border-radius: 4px; padding: .34cm .5cm; margin: .4cm 0; }
.callout p { margin: .08cm 0; }
.callout .k { color: var(--navy); font-weight: 700; }
.box-warn { background: var(--amber-bg); border-left: 4px solid var(--amber); border-radius: 4px; padding: .34cm .5cm; margin: .4cm 0; }
.box-danger { background: var(--red-bg); border-left: 4px solid var(--red); border-radius: 4px; padding: .34cm .5cm; margin: .4cm 0; }
.box-neutral { background: var(--gray-50); border-left: 4px solid var(--gray-500); border-radius: 4px; padding: .34cm .5cm; margin: .4cm 0; }

.steps { margin: .4cm 0; }
.step { display: flex; gap: .3cm; margin-bottom: .2cm; align-items: flex-start; }
.step .b { flex: 0 0 .58cm; height: .58cm; border-radius: 50%; background: var(--navy2); color: #fff;
  font-size: 8.6pt; font-weight: 700; display: flex; align-items: center; justify-content: center; }
.step .t { padding-top: .04cm; font-size: 9.4pt; }

.cause-grid { display: flex; flex-wrap: wrap; gap: .28cm; margin: .35cm 0; }
.cause-card { flex: 1 1 46%; min-width: 7.6cm; background: #fff; border: 1px solid var(--gray-300); border-radius: 6px; padding: .3cm .38cm; }
.cause-card .ttl { font-size: 9.4pt; font-weight: 700; color: var(--navy2); margin-bottom: .08cm; }

.tag { display: inline-block; background: var(--azure-light); color: var(--navy2); border: 1px solid var(--azure-mid);
  border-radius: 3px; font-size: 7.2pt; padding: .03cm .16cm; margin: 0 .08cm .08cm 0; font-weight: 700; }
.badge { display: inline-block; border-radius: 10px; font-size: 7.4pt; font-weight: 700; padding: .05cm .24cm; white-space: nowrap; }
.b-ok { background: var(--green-bg); color: var(--green); }
.b-open { background: var(--red-bg); color: var(--red); }
.b-pending { background: var(--amber-bg); color: var(--amber); }
.b-cancel { background: var(--gray-bg); color: var(--gray-700); }

.group-card { border: 1px solid var(--gray-300); border-radius: 8px; margin: 0 0 .4cm 0; overflow: hidden; page-break-inside: avoid; }
.group-head { background: var(--navy); color: #fff; padding: .28cm .4cm; display: flex; align-items: center; gap: .3cm; }
.group-head .gid { background: var(--azure); color: var(--navy); font-weight: 700; font-size: 10pt; border-radius: 4px; padding: .06cm .22cm; flex-shrink: 0; }
.group-head .gt { font-weight: 700; font-size: 10.6pt; flex: 1; }
.group-head .gn { font-size: 8.6pt; color: #C9D6EE; text-align: right; flex-shrink: 0; }
.group-body { padding: .32cm .42cm .18cm .42cm; }
.group-body .resumen { font-size: 9.3pt; color: #3A4256; margin-bottom: .18cm; }
.subpoint { margin: 0 0 .2cm 0; }
.subpoint .stt { font-weight: 700; color: var(--navy2); font-size: 9.1pt; }
.subpoint .std { font-size: 8.9pt; color: #3A4256; }
.subpoint .stc { font-size: 7.4pt; color: var(--gray-500); font-family: "Liberation Mono", monospace; margin-top: .04cm; }
.group-note { margin-top: .18cm; font-size: 8.5pt; color: var(--navy2); background: var(--gray-50); border-radius: 4px; padding: .2cm .3cm; border-left: 3px solid var(--gray-500); }
.group-cases-lbl { font-size: 7.4pt; color: var(--gray-500); text-transform: uppercase; letter-spacing: .06em; margin-bottom: .06cm; margin-top: .2cm; }
.group-cases-list { font-size: 7.1pt; color: var(--gray-700); font-family: "Liberation Mono", monospace; line-height: 1.55; }

table { border-collapse: collapse; width: 100%; margin: .28cm 0 .4cm 0; }
table.data th { background: var(--navy2); color: #fff; font-size: 7.8pt; text-align: left; padding: .16cm .22cm; font-weight: 700; }
table.data td { font-size: 8.1pt; padding: .13cm .22cm; border-bottom: 1px solid var(--gray-100); vertical-align: top; }
table.data tr:nth-child(even) td { background: var(--gray-50); }
table.compact th { font-size: 7.3pt; padding: .12cm .18cm; }
table.compact td { font-size: 7.5pt; padding: .1cm .18cm; }
.col-caso { font-family: "Liberation Mono", monospace; font-weight: 700; color: var(--navy2); white-space: nowrap; }
.col-fecha { white-space: nowrap; color: var(--gray-700); }
.col-num { text-align: right; font-variant-numeric: tabular-nums; }

.rec { display: flex; gap: .32cm; margin-bottom: .3cm; page-break-inside: avoid; border: 1px solid var(--gray-300); border-radius: 6px; padding: .28cm .36cm; }
.rec .rn { flex: 0 0 .8cm; height: .8cm; border-radius: 50%; background: var(--azure-light); color: var(--navy); font-weight: 700; font-size: 13pt;
  display: flex; align-items: center; justify-content: center; border: 1.6px solid var(--azure); }
.rec .rc { flex: 1; }
.rec .rt { font-weight: 700; color: var(--navy); font-size: 9.6pt; margin-bottom: .06cm; }
.rec .rd { font-size: 8.7pt; color: #3A4256; }
.rec .ri { margin-top: .12cm; display: inline-block; font-size: 7.4pt; font-weight: 700; color: var(--green); background: var(--green-bg); border-radius: 3px; padding: .05cm .2cm; }

.pend { border: 1px solid var(--red); border-left-width: 4px; border-radius: 6px; padding: .28cm .38cm; margin-bottom: .26cm; background: #FFFDFB; page-break-inside: avoid; }
.pend.pending { border-color: var(--amber); }
.pend .ph { display: flex; justify-content: space-between; align-items: center; margin-bottom: .08cm; }
.pend .pid { font-family: "Liberation Mono", monospace; font-weight: 700; color: var(--navy); font-size: 10.4pt; }
.pend .pdays { font-size: 7.6pt; color: var(--red); font-weight: 700; }
.pend.pending .pdays { color: var(--amber); }
.pend .pd { font-size: 8.9pt; color: #3A4256; }

.doc-note { margin-top: .5cm; font-size: 7.8pt; color: var(--gray-500); font-style: italic; border-top: 1px solid var(--gray-300); padding-top: .24cm; }
.chart-wrap { text-align: center; margin: .25cm 0; }
.chart-wrap img { max-width: 100%; }
.two-col { display: flex; gap: .5cm; align-items: flex-start; }
.two-col > div { flex: 1; }
.divider { border: none; border-top: 1px solid var(--gray-300); margin: .4cm 0; }
ul.plain { margin: .14cm 0; padding-left: .5cm; }
ul.plain li { margin-bottom: .1cm; font-size: 9.1pt; }
.people-grid { display: flex; gap: .6cm; }
.people-grid > div { flex: 1; }
.people-row { display: flex; justify-content: space-between; padding: .1cm 0; border-bottom: 1px solid var(--gray-100); font-size: 8.5pt; }
.people-row .pn { color: var(--ink); }
.people-row .pv { font-weight: 700; color: var(--navy2); }
"""

# ----------------------------------------------------------------------------
# 3) HELPERS DE PYTHON
# ----------------------------------------------------------------------------

def esc(s):
    """Escapa texto para insertarlo seguro en HTML."""
    return html.escape(str(s), quote=False)


def b64_image(path):
    """Lee un PNG/JPG del disco y lo devuelve como string base64 para <img src='data:...'>."""
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


def img_tag(path, mime="image/png"):
    return f'<img src="data:{mime};base64,{b64_image(path)}">'


def tags(csv_string):
    """'P-01, P-02' -> dos <span class="tag"> ... </span>."""
    if not csv_string:
        return ""
    parts = [p.strip() for p in csv_string.split(",")]
    return "".join(f'<span class="tag">{esc(p)}</span>' for p in parts)


# Vocabulario de estados soportado de forma nativa. Añade sinónimos aquí si tu
# fuente usa otras palabras (ej. "Done", "Open", "Closed", "In Progress").
_STATUS_MAP = {
    "completado": "ok", "cerrada": "ok", "cerrado": "ok", "done": "ok", "closed": "ok", "resuelto": "ok",
    "abierta": "open", "abierto": "open", "open": "open",
    "pending": "pending", "pendiente": "pending", "en curso": "pending", "in progress": "pending",
    "cancelado": "cancel", "cancelada": "cancel", "cancelled": "cancel", "canceled": "cancel", "no aplica": "cancel",
}


def status_class(status):
    return _STATUS_MAP.get(status.strip().lower(), "ok")


def status_badge(status):
    return f'<span class="badge b-{status_class(status)}">{esc(status)}</span>'


def stat_card(number, label, variant=None):
    """variant: None (azul default), 'hi' (rojo, para alertas), 'ok' (verde, para positivos)."""
    cls = f"stat-card {variant}" if variant else "stat-card"
    return f'<div class="{cls}"><div class="n">{esc(number)}</div><div class="l">{esc(label)}</div></div>'


def callout(html_inner, variant="callout"):
    """variant: 'callout' (azul), 'box-warn' (ámbar), 'box-danger' (rojo), 'box-neutral' (gris)."""
    return f'<div class="{variant}">{html_inner}</div>'


def group_card(gid, titulo, n, pct, body_html):
    return f"""
<div class="group-card">
  <div class="group-head">
    <div class="gid">{esc(gid)}</div>
    <div class="gt">{esc(titulo)}</div>
    <div class="gn">{n} casos · {pct}&nbsp;% del total</div>
  </div>
  <div class="group-body">{body_html}</div>
</div>
"""


def data_table(headers, rows, compact=True, col_classes=None):
    """
    headers: lista de strings.
    rows: lista de listas de HTML ya-formateado por celda (usa tags()/status_badge()/esc() antes).
    col_classes: lista opcional de clases CSS por columna (mismo largo que headers).
    """
    cls = "data compact" if compact else "data"
    col_classes = col_classes or [""] * len(headers)
    thead = "".join(f"<th>{esc(h)}</th>" for h in headers)
    trs = ""
    for row in rows:
        tds = "".join(
            f'<td class="{c}">{cell}</td>' if c else f"<td>{cell}</td>"
            for cell, c in zip(row, col_classes)
        )
        trs += f"<tr>{tds}</tr>"
    return f'<table class="{cls}"><thead><tr>{thead}</tr></thead><tbody>{trs}</tbody></table>'


def cover_page(kicker, title_line1, title_line2_accent, subtitle, meta_items, footer_note, footer_number, footer_number_label):
    """
    meta_items: lista de tuplas (label, value) — se muestran en una fila de metadatos.
    """
    meta_html = "".join(
        f'<div class="item"><div class="label">{esc(l)}</div><div class="value">{esc(v)}</div></div>'
        for l, v in meta_items
    )
    return f"""
<section class="cover">
  <div class="arc arc1"></div><div class="arc arc2"></div><div class="arc arc3"></div>
  <div class="azure-dot"></div>
  <div class="cover-inner">
    <div class="cover-brand">
      <div class="mark"></div>
      <div class="word">BTG <b>Pactual</b></div>
    </div>
    <div class="cover-kicker">{esc(kicker)}</div>
    <h1>{esc(title_line1)}<br><span class="accent">{esc(title_line2_accent)}</span></h1>
    <div class="subtitle">{esc(subtitle)}</div>
    <div class="cover-meta">{meta_html}</div>
  </div>
  <div class="cover-bottom">
    <div class="conf">{esc(footer_note)}</div>
    <div class="num"><div class="big">{esc(footer_number)}</div><div class="small">{esc(footer_number_label)}</div></div>
  </div>
</section>
"""


def section(number, title, body_html):
    return f'<section class="section"><h1 class="h-section"><span class="num">{number}.</span> {esc(title)}</h1>{body_html}</section>'


def wrap_document(cover_html, sections_html):
    return f"""<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><style>{BTG_CSS}</style></head>
<body>
{cover_html}
<div class="content">
{sections_html}
</div>
</body>
</html>"""


# ----------------------------------------------------------------------------
# 4) MATPLOTLIB — aplica la paleta BTG a cualquier gráfico
# ----------------------------------------------------------------------------
def mpl_style():
    """Llama esto una vez al inicio de tu script de gráficos, antes de crear figuras."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = "Liberation Sans"
    plt.rcParams["text.color"] = COLORS["navy"]
    plt.rcParams["axes.edgecolor"] = COLORS["gray300"]
    plt.rcParams["axes.labelcolor"] = COLORS["navy"]
    plt.rcParams["xtick.color"] = COLORS["gray700"]
    plt.rcParams["ytick.color"] = COLORS["ink"]
    return plt


def style_axes(ax):
    """Aplica el look sobrio estándar (sin bordes sup/der/izq, grid horizontal tenue) a un eje matplotlib."""
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color(COLORS["gray300"])
    ax.set_axisbelow(True)
    return ax
