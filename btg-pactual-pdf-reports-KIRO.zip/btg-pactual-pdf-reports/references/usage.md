# Ejemplo de uso end-to-end — report_toolkit.py (Kiro)

Este ejemplo mínimo genera un PDF de dos secciones para validar que el entorno funciona. Ajusta las
rutas a la estructura de tu proyecto — aquí se asume que corres el script desde la raíz del
workspace y que esta skill está en `.kiro/skills/btg-pactual-pdf-reports/`.

```python
import sys
sys.path.insert(0, ".kiro/skills/btg-pactual-pdf-reports/scripts")
# Si la skill es global, usa la ruta absoluta a ~/.kiro/skills/btg-pactual-pdf-reports/scripts
from report_toolkit import (
    wrap_document, cover_page, section, stat_card, callout,
    data_table, status_badge, tags, esc, mpl_style, style_axes, img_tag
)

# 1) Portada
cover = cover_page(
    kicker="Área X · Tipo de análisis",
    title_line1="Título del informe",
    title_line2_accent="Subtítulo en azul",
    subtitle="Una frase que resume el alcance del documento.",
    meta_items=[
        ("Proyecto", "COL · Equipo Y"),
        ("Periodo", "01 ene 2026 – 30 jun 2026"),
        ("Fecha del informe", "29 de julio de 2026"),
        ("Casos", "42"),
    ],
    footer_note="Documento de uso interno. Elaborado con información de Jira.",
    footer_number="42",
    footer_number_label="casos revisados",
)

# 2) Sección de resumen con tarjetas de estadística
resumen_body = f"""
<p class="lead">Resumen de una frase sobre el hallazgo principal.</p>
<div class="stat-grid">
  {stat_card(42, "Casos revisados")}
  {stat_card(30, "Cerrados", variant="ok")}
  {stat_card(5, "Abiertos", variant="hi")}
</div>
{callout("<p><span class='k'>Hallazgo clave:</span> texto del hallazgo más importante.</p>")}
"""
sec1 = section(1, "Resumen", resumen_body)

# 3) Sección con tabla de datos (badges de estado + tags de categoría)
rows = [
    ['<span class="col-caso">CASE-001</span>', "2026-07-01", "Descripción", tags("CAT-A, CAT-B"), status_badge("Abierta")],
    ['<span class="col-caso">CASE-002</span>', "2026-06-15", "Otra descripción", tags("CAT-A"), status_badge("Completado")],
]
tabla_html = data_table(
    headers=["Caso", "Fecha", "Descripción", "Categorías", "Estado"],
    rows=rows,
)
sec2 = section(2, "Tabla de casos", tabla_html)

# 4) Ensamblar y renderizar
html_doc = wrap_document(cover, sec1 + sec2)
with open("informe.html", "w", encoding="utf-8") as f:
    f.write(html_doc)

from weasyprint import HTML
HTML("informe.html").write_pdf("informe.pdf")
```

## Gráficos con la paleta BTG

```python
import sys
sys.path.insert(0, ".kiro/skills/btg-pactual-pdf-reports/scripts")
from report_toolkit import mpl_style, style_axes, COLORS

plt = mpl_style()
fig, ax = plt.subplots(figsize=(9, 4), dpi=220)
ax.barh(["Categoría A", "Categoría B", "Categoría C"], [10, 25, 15], color=COLORS["navy2"])
style_axes(ax)
fig.tight_layout()
fig.savefig("assets/mi_grafico.png", transparent=True, bbox_inches="tight")
```

Luego insértalo en el HTML con `img_tag("assets/mi_grafico.png")` dentro de un
`<div class="chart-wrap">...</div>`.

## Control de calidad visual (obligatorio antes de entregar)

```bash
pdftoppm -png -r 110 -f 1 -l 1 informe.pdf qa/p1   # portada
pdftoppm -png -r 110 -f 2 -l 2 informe.pdf qa/p2   # primera sección
# repite para 3-4 páginas representativas y ábrelas para revisarlas
# antes de entregar el PDF final.
```

Si `poppler-utils` no está instalado en la máquina del usuario:
- Linux (Debian/Ubuntu): `sudo apt install poppler-utils`
- macOS: `brew install poppler`
- Windows: instala poppler y agrega su carpeta `bin/` al PATH, o usa WSL.
