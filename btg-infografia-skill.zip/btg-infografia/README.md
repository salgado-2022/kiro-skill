# btg-infografia

Skill de Kiro que convierte un documento Markdown en una infografía corporativa
BTG Pactual de una sola página, en PDF y PNG.

Sin librerías de gráficas: las barras, los porcentajes y las tarjetas son HTML y
CSS, y el render lo hace Chromium.

## Instalación

Copie la carpeta `btg-infografia/` a una de estas ubicaciones:

- `.kiro/skills/btg-infografia/` — alcance de proyecto (recomendado, versionable)
- `~/.kiro/skills/btg-infografia/` — alcance global

Luego:

```bash
pip install -r requirements.txt
playwright install chromium     # opcional
```

En entornos con descargas restringidas, omita `playwright install` y use
`--navegador msedge`. Si ni siquiera puede instalar playwright, la skill cae sola
al navegador del sistema.

Ponga su logo en `assets/btg-logo.png`. Si no está, se usa un respaldo
tipográfico y la infografía se genera igual.

## Uso desde Kiro

Basta pedirlo en lenguaje natural; la skill se activa sola:

> Arma una infografía con el valor entregado por tecnología este semestre

O invocarla directamente con `/btg-infografia`.

## Uso manual

```bash
# 1. Validar el insumo y ver los bloques detectados
python scripts/build_infografia.py revisar fuente.md

# 2. Construir PDF y PNG
python scripts/build_infografia.py construir fuente.md -o infografia.pdf --png

# 3. Ver los iconos disponibles
python scripts/build_infografia.py iconos
```

Opciones útiles de `construir`:

| Opción | Efecto |
|---|---|
| `--png [ruta]` | Exporta también imagen |
| `--html ruta` | Conserva el HTML intermedio |
| `--ancho 210` | Cambia el ancho del lienzo (por defecto 264 mm) |
| `--alto 640` | Fuerza el alto en lugar de medirlo |
| `--logo`, `--css` | Sustituyen los assets |
| `--navegador msedge` | Fuerza el canal de navegador |

## Documentación

- `references/formato-markdown.md` — formato del insumo, bloques y opciones
- `references/sistema-diseno.md` — paleta, tipografía y componentes
- `examples/valor-tecnologia.md` — ejemplo completo y funcional
