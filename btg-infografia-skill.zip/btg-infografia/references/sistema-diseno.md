# Sistema de diseño

Todo vive en `assets/theme.css`; se puede sustituir con `--css` sin tocar los
scripts. Comparte paleta con `btg-report-pdf`, pero con un tratamiento distinto:
en el informe el color se usa con moderación, aquí se usa como estructura.

## Paleta

| Variable | Hex | Uso |
|---|---|---|
| `--navy` | `#05132A` | Fondo del hero y del roadmap, cifras grandes |
| `--navy-soft` | `#0B2547` | Punto medio del degradado del hero |
| `--blue` | `#195AB4` | Acento principal: barras, bordes, etiquetas de sección |
| `--blue-light` | `#6FA0E0` | Texto de acento sobre fondo navy |
| `--blue-pale` | `#EEF3F9` | Fondo de tarjetas claras |
| `--blue-track` | `#D9E4F1` | Canal de las barras de avance |
| `--red` | `#B3261E` | Clasificación y riesgo reputacional |
| `--green` | `#1E7B34` | Estados positivos |
| `--amber` | `#C79A1E` | Riesgo de crédito |
| `--teal` | `#0E7C74` | Riesgo de mercado |
| `--purple` | `#5B4B93` | Cumplimiento |

El color de las etiquetas es semántico: cada tipo de riesgo tiene el suyo y se
mantiene igual en toda la pieza, para que el lector pueda confiar en que el color
significa algo. Los grupos de `tarjetas` usan una monocromía azul de claro a
oscuro, para no competir con las etiquetas.

## Tipografía

Segoe UI en Windows, con Liberation Sans y Arial como respaldo. La jerarquía es
más agresiva que en el informe, porque una infografía se lee de un vistazo:

| Elemento | Tamaño | Peso |
|---|---|---|
| Cifra del hero | 52 pt | 800 |
| Título | 27 pt | 800 |
| Porcentaje de `mix` | 24 pt | 800 |
| Cifra de `cifras` | 16.5 pt | 800 |
| Etiqueta de sección | 8 pt versalitas | 700 |
| Cuerpo de tarjeta | 8.4 pt | normal |

## Lienzo

Ancho fijo de 264 mm y alto variable: la infografía es una sola página larga, no
un documento paginado. Con Playwright el alto se mide del contenido real; con el
respaldo por subproceso se estima.

Márgenes laterales de 16 mm en todas las secciones, para que el eje vertical de
lectura quede alineado de arriba abajo.

## Componentes

| Clase | Aspecto |
|---|---|
| `.hero` | Franja navy con degradado diagonal y halo azul |
| `.badge-clasificacion` | Etiqueta roja de clasificación |
| `.hero-stat-main` | Cifra gigante con su etiqueta al lado |
| `.mix-card` | Tarjeta clara con porcentaje, icono y barra de avance |
| `.figure-card` | Tarjeta blanca con filo azul superior |
| `.impact-row` | Etiqueta a la derecha, barra, valor |
| `.init-card` | Tarjeta de iniciativa con filo lateral del color del grupo |
| `.tag` | Píldora de riesgo, coloreada por nombre |
| `.roadmap-chip` | Tarjeta translúcida sobre fondo navy |
| `.highlight` | Recuadro azul claro de mensaje clave |

## Iconos

Iconos de línea sobre `viewBox 0 0 24 24`, sin relleno y con el trazo heredado
del contenedor, así que el mismo icono sirve sobre fondo claro y sobre navy.
Viven en `scripts/icons.py` y se referencian por nombre desde el Markdown.

Hay alias en lenguaje natural (`ahorro` → `moneda`, `cumplimiento` →
`escudo-check`), y un nombre desconocido cae en un punto en lugar de romper el
render. `python scripts/build_infografia.py iconos` lista todo.

## Por qué no hay librería de gráficas

Las barras y los porcentajes son `div` con un ancho en porcentaje. Esto evita
matplotlib por completo, hace que la pieza sea vectorial y nítida a cualquier
zoom, y permite que el estilo de las gráficas se controle desde el mismo CSS que
el resto. La contrapartida es que no hay gráficas de dispersión, líneas ni
anillos: si el dato las necesita, el insumo probablemente sea un informe y no una
infografía.
