# Formato del Markdown fuente

El insumo es Markdown normal más dos convenciones: un frontmatter y una directiva
antes de cada tabla. No hace falta PyYAML: el frontmatter se parsea a mano.

## Frontmatter

```yaml
---
titulo: Valor generado por Tecnología
kicker: Vertical SC · FD · RG · IT Product 2026
subtitulo: Resumen ejecutivo del valor y las cifras de las 11 iniciativas...
clasificacion: INTERNO
hero_stat: 11 | iniciativas entregadas en 8 meses
hero_mini:
  - 3 | verticales impactadas · SC · FD · RG
  - Ene–Ago | período del análisis · 2026
nota_cierre: Cifras tomadas exclusivamente de la presentación fuente...
pie_derecha: Documento de negocio · Uso interno · Vigente
---
```

| Clave | Obligatoria | Efecto |
|---|---|---|
| `titulo` | sí | Título grande del encabezado |
| `kicker` | no | Línea azul pequeña junto al logo |
| `subtitulo` | no | Párrafo de contexto bajo el título |
| `clasificacion` | no | Etiqueta roja de la esquina (INTERNO, CONFIDENCIAL) |
| `hero_stat` | recomendada | Cifra gigante. Formato `valor \| descripción` |
| `hero_mini` | no | Hasta 3 cifras secundarias, mismo formato |
| `nota_cierre` | no | Nota al pie, a la izquierda |
| `pie_derecha` | no | Metadatos al pie, a la derecha |

En `hero_stat` y `hero_mini`, la barra vertical separa la cifra de su etiqueta.
En `hero_mini`, el primer ` · ` de la etiqueta se convierte en salto de línea.

## Bloques

Cada tabla va precedida de su directiva. Sin directiva, la skill deduce el tipo
por la forma de la tabla, pero conviene ser explícito.

### mix — reparto porcentual

```markdown
## Mezcla del portafolio

En qué se concentró el esfuerzo.

<!-- bloque: mix -->

| Porcentaje | Concepto | Icono |
|---|---|---|
| 50% | Resuelve obligaciones regulatorias | escudo |
| 40% | Automatiza procesos manuales diarios | engranaje |
```

El número del porcentaje define el ancho de la barra. Los porcentajes no tienen
que sumar 100: son proporciones de un total, no una partición.

### cifras — indicadores destacados

```markdown
<!-- bloque: cifras -->

| Cifra | Descripción | Icono |
|---|---|---|
| COP 75 MM/año | ~1.500 h operativas liberadas | moneda |
```

La cifra se muestra tal cual se escriba, así que las unidades y los símbolos van
en la celda. Convención colombiana: punto para miles, coma para decimales.

### barras — ranking comparable

```markdown
<!-- bloque: barras -->

| Foco de valor | Iniciativas | Ejemplos |
|---|---|---|
| Cumplimiento regulatorio | 5 | MURIC, FATCA, Dec. 1533 |
```

La barra más larga corresponde al valor máximo. La columna de valor se detecta
por su contenido numérico, no por el nombre del encabezado, porque títulos como
"Foco de valor" contienen la palabra "valor" pero son la etiqueta.

La columna de ejemplos es opcional y se muestra en gris bajo la barra; las comas
se convierten en separadores `·`.

Los valores se leen con convención colombiana: el punto separa miles y la coma
decimales, así que `1.640` vale mil seiscientos cuarenta y no 1,64. Se pueden
escribir con unidades (`1.640 tickets`, `99,4%`): se extrae el número y se
muestra la celda completa junto a la barra.

### tarjetas — catálogo agrupado

```markdown
<!-- bloque: tarjetas, agrupar: Vertical -->

| Iniciativa | Vertical | Beneficio | Etiquetas |
|---|---|---|---|
| NUAM Exchange | SC · Comisionista | Acceso al mercado regional. | Mercado · Operativo |
```

Los grupos se convierten en columnas, en el orden en que aparecen, y cada uno
recibe un color de la paleta. Las etiquetas se separan por `·`, `,` o `;`, y se
colorean por nombre (ver abajo); las que no estén en la lista salen en azul y
aparecen igual en la leyenda.

Colores de etiqueta reconocidos: `Operativo`, `Mercado`, `Crédito`,
`Cumplimiento`, `Reputacional`, `Tecnológico`, `Liquidez`.

### roadmap — franja de valor futuro

```markdown
<!-- bloque: roadmap -->

| Título | Descripción | Icono |
|---|---|---|
| Open Banking | API de Saldo como primer servicio | nodos |
```

Se dibuja sobre fondo navy y cierra la infografía, así que conviene ponerlo al
final del documento.

### destacado — mensaje clave

```markdown
> [!CLAVE] 11 iniciativas en 8 meses: el 50% resuelve obligaciones regulatorias.
```

Cualquier etiqueta funciona (`[!CLAVE]`, `[!NOTA]`); se usa como título del
recuadro.

## Opciones de los bloques

Se escriben después del nombre, separadas por comas:

```markdown
<!-- bloque: tarjetas, agrupar: Área, columnas: 4 -->
<!-- bloque: cifras, columnas: 4 -->
```

| Opción | Aplica a | Efecto |
|---|---|---|
| `columnas` | mix, cifras, roadmap, tarjetas | Fuerza el número de columnas |
| `agrupar` | tarjetas | Nombre de la columna por la que se agrupa |

## Encabezados y párrafos

El `##` de la sección se convierte en la etiqueta azul pequeña, y el párrafo que
le sigue en el subtítulo gris. Ambos son opcionales.

## Errores frecuentes

- **Celdas largas.** Un beneficio de tres renglones descuadra la columna.
  Resuma a una frase.
- **Demasiadas filas en `mix` o `roadmap`.** Más de 5 y las tarjetas quedan
  ilegibles; el comando `revisar` lo advierte.
- **Barras con unidades mezcladas.** Comparar montos con conteos en el mismo
  bloque produce una gráfica sin sentido; sepárelos en dos bloques.
- **Olvidar la directiva.** La skill deduce el tipo, pero no siempre acierta.
