---
titulo: Valor generado por Tecnología
kicker: Vertical SC · FD · RG · IT Product 2026
subtitulo: Resumen ejecutivo del valor, el beneficio a negocio y las cifras de las 11 iniciativas entregadas entre enero y agosto de 2026 en Comisionista, Fiduciaria y Regulatorios.
clasificacion: INTERNO
hero_stat: 11 | iniciativas entregadas en 8 meses
hero_mini:
  - 3 | verticales impactadas · SC · FD · RG
  - Ene–Ago | período del análisis · 2026
nota_cierre: Cifras tomadas exclusivamente de la presentación fuente (SC_FD_RG 2026); los rubros sin monto se reportan como habilitadores sin valoración monetaria.
pie_derecha: Documento de negocio · Uso interno · Vigente
---

## Mezcla del portafolio

En qué se concentró el esfuerzo de las 11 iniciativas.

<!-- bloque: mix -->

| Porcentaje | Concepto | Icono |
|---|---|---|
| 50% | Resuelve obligaciones regulatorias de cumplimiento obligatorio | escudo |
| 40% | Automatiza procesos manuales diarios | engranaje |
| 30% | Habilita crecimiento futuro — NUAM, Open Banking, APIs Brasil | tendencia |

## Cifras clave del período

<!-- bloque: cifras -->

| Cifra | Descripción | Icono |
|---|---|---|
| COP 75 MM/año | ~1.500 h operativas liberadas — Notificaciones automáticas | moneda |
| ~2 h × 22 días | Liberadas a diario en cargue de cuentas DCV-DVL-CRCC | reloj |
| 3 verticales | SC · FD · RG impactadas por las 11 iniciativas | barras |

## Concentración del impacto

Número de iniciativas por foco de valor (una iniciativa puede aportar a más de un foco).

<!-- bloque: barras -->

| Foco de valor | Iniciativas | Ejemplos |
|---|---|---|
| Cumplimiento regulatorio | 5 | MURIC, FATCA, Dec. 1533, Dec. 1358, Límites |
| Automatización operativa | 4 | Cuentas DCV, Notificaciones, Certificados, MURIC |
| Mitigación de riesgo | 4 | Límites 3 soc., P&G AML, Vinculados, FATCA |
| Nuevas capacidades | 3 | NUAM Exchange, API Saldo, Control Límites |
| Experiencia de cliente | 2 | Notificaciones, Certificados Tributarios |

## Beneficio a negocio por iniciativa

Las 11 iniciativas, agrupadas por vertical, con el riesgo que mitigan.

<!-- bloque: tarjetas, agrupar: Vertical -->

| Iniciativa | Vertical | Beneficio | Etiquetas |
|---|---|---|---|
| NUAM Exchange SAE/OYD | SC · Comisionista | Habilitación de ingresos: acceso al volumen del mercado regional latinoamericano. | Mercado · Operativo |
| Cargue cuentas DCV-DVL-CRCC | SC · Comisionista | ~2 h diarias × 22 días liberadas; error de posiciones eliminado. | Operativo |
| API de consulta de saldo | SC · Comisionista | Habilitador estratégico: primera pieza de Open Banking. | Operativo · Mercado |
| APIs Compliance Brasil | SC · Comisionista | Rastreo completo de compliance de órdenes; fin del intercambio manual. | Operativo · Cumplimiento |
| Control P&G clientes | FD · Fiduciaria | Riesgo AML mitigado; exposición reputacional reducida. | Operativo · Cumplimiento |
| Certificados tributarios FVP | FD · Fiduciaria | Tiempo liberado; sanción tributaria (DIAN) evitada. | Operativo · Reputacional |
| Notificaciones automáticas | FD · Fiduciaria | ~1.500 h operativas/año liberadas · COP 75 MM de eficiencia estimada. | Operativo · Cumplimiento |
| MURIC – Reporte cartera SFC | RG · Regulatorios | Sanción regulatoria y reputacional evitada. | Operativo |
| Decretos 1533 y 1358 | RG · Regulatorios | Sanciones evitadas en 2 decretos de cumplimiento obligatorio. | Operativo · Crédito |
| Control de límites 3 soc. | RG · Regulatorios | Capacidad preventiva: evita pérdidas por exposición excesiva. | Crédito · Mercado |
| FATCA/CRS – Estabilización | RG · Regulatorios | Penalidades internacionales (IRS) evitadas en 3 sociedades. | Operativo |

## Valor futuro habilitado

<!-- bloque: roadmap -->

| Título | Descripción | Icono |
|---|---|---|
| Open Banking | API de Saldo como primer servicio expuesto | nodos |
| NUAM Fase 2 | Préstamo de valores y NUBO | api |
| OMS electrónico | Nuevo sistema de órdenes para clientes (SERO) | pantalla |
| Alertamiento preventivo | Desde los simuladores de riesgo | campana |
| Arquitectura Ozono | Nueva arquitectura escalable | capas |
