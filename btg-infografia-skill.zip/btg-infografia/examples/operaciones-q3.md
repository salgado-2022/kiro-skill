---
titulo: Resultados de Operaciones y Servicio
kicker: Mesa de Servicio · Infraestructura · Q3 2026
subtitulo: Estado de la atención, disponibilidad de plataformas y avance del plan de modernización durante el tercer trimestre.
clasificacion: CONFIDENCIAL
hero_stat: 4.812 | solicitudes atendidas en el trimestre
hero_mini:
  - 99,4% | disponibilidad · promedio ponderado
  - 6 | plataformas · bajo monitoreo
nota_cierre: Datos extraídos de la herramienta de tickets y del tablero de monitoreo; el trimestre cierra el 30 de septiembre y las cifras son preliminares.
pie_derecha: Uso interno · Preliminar
---

> [!CLAVE] La atención automatizada ya cubre un tercio del volumen y el tiempo medio de resolución bajó de 14 a 9 horas. El pendiente sigue siendo la deuda de infraestructura heredada.

## Distribución de la atención

<!-- bloque: mix, columnas: 4 -->

| Porcentaje | Concepto | Icono |
|---|---|---|
| 34% | Resuelto por automatización sin intervención humana | robot |
| 41% | Atendido en primer nivel dentro del acuerdo de servicio | usuarios |
| 18% | Escalado a especialistas de plataforma | servidor |
| 7% | Requirió intervención de proveedor externo | globo |

## Indicadores del trimestre

<!-- bloque: cifras, columnas: 4 -->

| Cifra | Descripción | Icono |
|---|---|---|
| 9 h | Tiempo medio de resolución, frente a 14 h en el trimestre anterior | reloj |
| 99,4% | Disponibilidad promedio de las plataformas críticas | tendencia |
| 12 | Incidentes mayores, ninguno con impacto a cliente final | alerta |
| COP 210 MM | Ahorro estimado por retiro de infraestructura ociosa | ahorro |

## Volumen por plataforma

Solicitudes recibidas en el trimestre, por sistema de origen.

<!-- bloque: barras -->

| Plataforma | Solicitudes | Detalle |
|---|---|---|
| Portal transaccional | 1.640 | Autenticación, saldos, certificados |
| Core de custodia | 1.120 | Conciliación, posiciones |
| Herramientas internas | 890 | Reportería, tableros |
| Canales móviles | 720 | App, notificaciones |
| Integraciones externas | 442 | Proveedores, entes de control |

## Iniciativas del plan de modernización

<!-- bloque: tarjetas, agrupar: Frente -->

| Iniciativa | Frente | Beneficio | Etiquetas |
|---|---|---|---|
| Retiro de servidores heredados | Infraestructura | Reducción de costo fijo y de superficie de ataque. | Operativo · Tecnológico |
| Migración de respaldos a nube | Infraestructura | Recuperación en horas en lugar de días. | Operativo |
| Monitoreo unificado | Observabilidad | Detección antes de que el usuario reporte. | Operativo · Tecnológico |
| Tableros de disponibilidad | Observabilidad | Visibilidad directa para las áreas de negocio. | Operativo |
| Autoservicio de contraseñas | Automatización | Elimina el motivo de ticket más frecuente. | Operativo |
| Enrutamiento asistido de tickets | Automatización | Menos reasignaciones; llega al especialista correcto. | Operativo |

## Frentes del próximo trimestre

<!-- bloque: roadmap, columnas: 4 -->

| Título | Descripción | Icono |
|---|---|---|
| Recuperación ante desastres | Prueba completa de continuidad | escudo |
| Catálogo de servicios | Solicitudes estandarizadas de punta a punta | documento |
| Gestión de capacidad | Dimensionamiento con datos de consumo real | barras |
| Base de conocimiento | Resolución asistida en primer contacto | llave |
