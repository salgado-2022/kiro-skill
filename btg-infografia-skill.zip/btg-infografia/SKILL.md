---
name: btg-infografia
description: Genera infografías corporativas BTG Pactual en PDF o PNG a partir de un archivo Markdown. Úsela cuando se pida una infografía, un one-pager visual, un resumen ejecutivo gráfico, un póster de resultados o un tablero de valor entregado, o cuando haya que convertir datos de una presentación, un Excel o unas notas en una pieza visual de una sola página con la identidad de BTG. No la use para informes de varias páginas con secciones de texto corrido: para eso está btg-report-pdf.
---

# Infografías corporativas BTG Pactual

Convierte un Markdown en una infografía de una sola página, de ancho fijo y alto
variable, con la identidad visual de BTG Pactual. No usa librerías de gráficas:
todos los elementos (barras, porcentajes, tarjetas, iconos) son HTML y CSS, y el
PDF lo produce Chromium.

## Cuándo usar esta skill

Úsela cuando el resultado esperado sea **una pieza visual de una sola página**
para presentar o compartir: valor entregado, resultados de un período, portafolio
de iniciativas, indicadores clave, roadmap.

Si el pedido es un documento de varias páginas con texto corrido, secciones
numeradas y análisis, use `btg-report-pdf` en su lugar.

## Flujo de trabajo

### Paso 1 — Conseguir la sábana de datos en Markdown

La skill **solo lee Markdown**. Si el insumo es otra cosa (una presentación, un
Excel, un correo, unas notas sueltas), primero conviértalo a un `.md` con el
formato de `references/formato-markdown.md`, y **muéstreselo al usuario para que
lo valide antes de renderizar**. Ahí es donde se decide qué entra y qué no.

Al construir la sábana:

- **Resuma con dureza.** Una infografía no es un informe. Los beneficios van en
  una frase, no en un párrafo. Si una celda no cabe en dos renglones, sobra.
- **Extraiga las cifras.** Busque en la fuente los números concretos (montos,
  horas, porcentajes, conteos) y llévelos a `hero_stat` y al bloque `cifras`.
  Una infografía sin cifras grandes no funciona.
- **No invente datos.** Si la fuente no cuantifica algo, déjelo como habilitador
  sin monto y dígalo en `nota_cierre`.
- **Agrupe.** Si hay más de 8 elementos en una lista, busque el eje natural de
  agrupación (vertical, área, trimestre) y úselo en `<!-- bloque: tarjetas -->`.

### Paso 2 — Revisar

```bash
python scripts/build_infografia.py revisar fuente.md
```

Muestra los bloques detectados, cuántas filas tiene cada uno, el alto estimado y
los avisos (columnas que quedarán muy angostas, bloques sin directiva, etc.).
Corrija los avisos antes de construir.

### Paso 3 — Construir

```bash
python scripts/build_infografia.py construir fuente.md -o infografia.pdf --png
```

`--png` exporta además una imagen, útil para pegar en Teams, en un correo o en
una diapositiva.

### Paso 4 — Revisar el resultado antes de entregar

Convierta el PDF a imagen y **mírelo** antes de darlo por bueno. Los defectos
típicos (texto que se desborda, una columna vacía, una barra sin datos) solo se
ven mirando.

```bash
python -c "from pdf2image import convert_from_path; convert_from_path('infografia.pdf', dpi=100)[0].save('preview.png')"
```

Si `pdf2image` no está disponible, use el PNG que genera `--png`.

## Bloques disponibles

Cada tabla del Markdown va precedida de una directiva que define cómo se dibuja:

| Directiva | Para qué sirve | Columnas esperadas |
|---|---|---|
| `<!-- bloque: mix -->` | Reparto porcentual del portafolio | Porcentaje, Concepto, Icono |
| `<!-- bloque: cifras -->` | Indicadores destacados | Cifra, Descripción, Icono |
| `<!-- bloque: barras -->` | Ranking o conteo comparable | Etiqueta, Valor, Ejemplos |
| `<!-- bloque: tarjetas -->` | Catálogo de iniciativas agrupadas | Iniciativa, Grupo, Beneficio, Etiquetas |
| `<!-- bloque: roadmap -->` | Franja oscura de valor futuro | Título, Descripción, Icono |
| `> [!CLAVE] texto` | Mensaje destacado | — |

Opciones tras el nombre: `columnas: 4`, `agrupar: Vertical`.

Detalle completo en `references/formato-markdown.md`.

## Criterios de composición

- **Un bloque `mix` y un bloque `cifras` por infografía.** Repetirlos diluye la
  jerarquía; el lector deja de saber qué es lo importante.
- **Entre 3 y 5 columnas.** Con más de 5, el texto se vuelve ilegible; el CLI
  avisa cuando esto pasa.
- **`barras` solo con valores comparables.** Cinco filas de la misma unidad se
  leen bien; mezclar montos con conteos no.
- **El bloque `roadmap` va al final**, porque cierra la pieza con la franja
  oscura y da un remate visual.
- **Máximo 12 tarjetas.** Por encima de eso conviene resumir o pasar a informe.

## Motor de renderizado

Chromium, en cascada, sin dependencias de sistema:

1. **Playwright** con el chromium descargado, o con el canal `msedge` / `chrome`
   ya instalado. Mide el alto real del contenido, así que la página queda
   exactamente a la medida. Es el único camino que exporta PNG con calidad.
2. **Subproceso** a Chrome o Edge con `--headless --print-to-pdf`, sin ningún
   paquete de Python. No puede medir, así que usa el alto estimado; si sobra o
   falta espacio al final, ajústelo con `--alto 640`.

Si no hay navegador, el CLI falla con instrucciones en lugar de producir un
archivo roto.

## Personalización

- **Logo**: ponga `assets/btg-logo.png`. Si no existe, se dibuja un respaldo
  tipográfico y la infografía sale igual.
- **Colores y tipografía**: `assets/theme.css`; se puede sustituir con `--css`.
- **Iconos**: `python scripts/build_infografia.py iconos` lista los nombres y
  alias disponibles. Un nombre inexistente no rompe el render.
- **Ancho**: `--ancho 264` (por defecto). 210 para A4 vertical.

Detalle del sistema visual en `references/sistema-diseno.md`.
