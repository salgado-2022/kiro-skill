"""
Renderizado de la infografía a PDF y PNG usando Chromium.

Una infografía es una sola página de altura variable, así que el paso crítico
es medir el alto real del contenido antes de imprimir. Estrategia en cascada,
pensada para entornos corporativos con restricciones de instalación:

  1. Playwright con el navegador disponible:
       - chromium descargado por Playwright
       - canal 'msedge'  (Edge viene preinstalado en Windows corporativo)
       - canal 'chrome'
     Mide el alto exacto del contenido y produce una única página a medida.
     También permite exportar PNG.

  2. Subproceso directo a Chrome/Edge con --headless --print-to-pdf.
     No requiere ningún paquete de Python. No puede medir el contenido, así
     que usa el alto estimado (o el que se pase con --alto) y puede dejar
     espacio en blanco al final.

Instalación mínima:
    pip install playwright
    playwright install chromium      # opcional si ya hay Edge/Chrome
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile

PX_POR_MM = 96.0 / 25.4

# Colchón sobre el alto medido. Absorbe el redondeo de Chromium al convertir
# píxeles a milímetros; sin él, el contenido se parte en dos hojas.
MARGEN_SEGURIDAD_MM = 2.0


_PAGE_BLOCK = re.compile(
    r"/\* BTG-PAGE-START \*/.*?/\* BTG-PAGE-END \*/", re.DOTALL)


def _reescribir_page(html_path, regla):
    """
    Sustituye el bloque @page del HTML y devuelve la ruta de un archivo temporal.

    Es imprescindible: cuando @page trae un 'size', Chromium lo respeta por
    encima del alto que se pasa a page.pdf(), y la infografía se parte en dos
    hojas por más que se agrande el lienzo. En el camino de Playwright se deja
    sin 'size' para poder medir; en el de subproceso se fija al alto estimado,
    que es la única forma de controlarlo sin API.
    """
    with open(html_path, "r", encoding="utf-8") as fh:
        contenido = fh.read()
    nuevo = _PAGE_BLOCK.sub(regla, contenido)
    destino = os.path.join(tempfile.mkdtemp(prefix="btg-html-"), "infografia.html")
    with open(destino, "w", encoding="utf-8") as fh:
        fh.write(nuevo)
    return destino


def _contar_paginas(pdf_path):
    """Cuenta las páginas del PDF. Devuelve None si no se puede determinar."""
    try:
        with open(pdf_path, "rb") as fh:
            datos = fh.read()
    except OSError:
        return None
    n = datos.count(b"/Type /Page\n") + datos.count(b"/Type/Page/") \
        + datos.count(b"/Type /Page/") + datos.count(b"/Type/Page\n")
    return n or None

BROWSER_CANDIDATES = [
    # Windows
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    # macOS
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
]

BROWSER_COMMANDS = ["chromium", "chromium-browser", "google-chrome",
                    "google-chrome-stable", "microsoft-edge", "msedge"]


def find_browser():
    """Localiza un binario de Chromium/Chrome/Edge en el sistema."""
    for cmd in BROWSER_COMMANDS:
        path = shutil.which(cmd)
        if path:
            return path
    for path in BROWSER_CANDIDATES:
        if os.path.exists(path):
            return path
    return None


# ------------------------------------------------------------------
# Estimación de altura (respaldo cuando no se puede medir)
# ------------------------------------------------------------------

def estimar_alto_mm(secciones, meta):
    """
    Aproxima el alto en mm sumando el costo de cada bloque.

    Solo se usa en el camino de respaldo; con Playwright el alto se mide de
    verdad. Los coeficientes están calibrados contra medidas reales del
    navegador, y se redondea ligeramente hacia arriba: sobrar unos milímetros
    deja una franja blanca al final, pero quedarse corto parte la infografía
    en dos hojas, que es mucho peor.
    """
    # Hero: base, más el subtítulo y la fila de cifras si existen.
    alto = 60.0
    if meta.get("subtitulo"):
        alto += 18.0
    if meta.get("hero_stat") or meta.get("hero_mini"):
        alto += 26.0

    for sec in secciones:
        if sec.get("titulo") and sec.get("subtitulo"):
            cabecera = 14.0
        elif sec.get("titulo") or sec.get("subtitulo"):
            cabecera = 10.0
        else:
            cabecera = 4.0

        bloque = sec.get("bloque", "auto")
        filas = len(sec.get("filas") or [])

        if bloque == "mix":
            alto += cabecera + 57.0
        elif bloque == "cifras":
            alto += cabecera + 43.0
        elif bloque == "barras":
            alto += cabecera + filas * 19.5
        elif bloque == "tarjetas":
            grupos = {}
            for f in sec["filas"]:
                g = f[1] if len(f) > 1 else ""
                grupos[g] = grupos.get(g, 0) + 1
            mayor = max(grupos.values()) if grupos else filas
            alto += cabecera + 13.0 + mayor * 36.5 + 18.0
        elif bloque == "roadmap":
            alto += cabecera + 66.0
        elif bloque == "destacado":
            alto += 30.0
        else:
            alto += cabecera + filas * 12.0

    if meta.get("nota_cierre") or meta.get("pie_derecha"):
        alto += 25.0
    return round(alto + 6.0, 1)


# ------------------------------------------------------------------
# Camino 1: Playwright
# ------------------------------------------------------------------

def _render_playwright(html_path, pdf_path, ancho_mm, alto_mm=None,
                       png_path=None, channel=None, escala_png=2):
    """Devuelve el alto usado en mm, o None si Playwright no está disponible."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return None

    intentos = [channel] if channel else [None, "msedge", "chrome"]
    # Sin 'size' en @page: así el alto que se pasa a page.pdf() manda.
    html_libre = _reescribir_page(html_path, "@page { margin: 0; }")
    url = "file://" + os.path.abspath(html_libre)

    with sync_playwright() as p:
        ultimo_error = None
        for ch in intentos:
            try:
                kwargs = {"channel": ch} if ch else {}
                browser = p.chromium.launch(**kwargs)
            except Exception as exc:          # navegador no disponible
                ultimo_error = exc
                continue

            try:
                ancho_px = int(round(ancho_mm * PX_POR_MM))
                page = browser.new_page(viewport={"width": ancho_px, "height": 1200})
                page.goto(url, wait_until="networkidle")

                if alto_mm is None:
                    # El layout de impresión de Chromium no coincide con el de
                    # pantalla (tipografía y saltos cambian), así que se mide
                    # con la media 'print' emulada: si no, el contenido se
                    # desborda a una segunda página por unos milímetros.
                    page.emulate_media(media="print")
                    page.wait_for_timeout(120)
                    medido = page.evaluate(
                        "() => { const el = document.querySelector('.page') || document.body;"
                        "  return Math.ceil(el.getBoundingClientRect().height); }"
                    )
                    alto_final = round(medido / PX_POR_MM, 1) + MARGEN_SEGURIDAD_MM
                    page.emulate_media(media="screen")
                else:
                    alto_final = alto_mm

                page.pdf(path=pdf_path,
                         width="%smm" % ancho_mm,
                         height="%smm" % alto_final,
                         print_background=True,
                         prefer_css_page_size=False,
                         margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})

                # Red de seguridad: si aun así quedaron dos hojas, agranda el
                # lienzo en pasos pequeños hasta que entre en una sola.
                if alto_mm is None:
                    for _ in range(4):
                        if (_contar_paginas(pdf_path) or 1) <= 1:
                            break
                        alto_final = round(alto_final + 10.0, 1)
                        page.pdf(path=pdf_path,
                                 width="%smm" % ancho_mm,
                                 height="%smm" % alto_final,
                                 print_background=True,
                                 prefer_css_page_size=False,
                                 margin={"top": "0", "bottom": "0",
                                         "left": "0", "right": "0"})

                if png_path:
                    page.set_viewport_size({
                        "width": ancho_px,
                        "height": int(round(alto_final * PX_POR_MM)),
                    })
                    page.screenshot(path=png_path, full_page=True, scale="device")

                browser.close()
                return alto_final
            except Exception:
                browser.close()
                raise

        if ultimo_error:
            print("  Playwright no encontró un navegador utilizable (%s)" % ultimo_error,
                  file=sys.stderr)
        return None


# ------------------------------------------------------------------
# Camino 2: subproceso a Chrome/Edge
# ------------------------------------------------------------------

def _render_subproceso(html_path, pdf_path, png_path=None, ancho_mm=264, alto_mm=600):
    browser = find_browser()
    if not browser:
        return False

    perfil = tempfile.mkdtemp(prefix="btg-infografia-")
    # Sin API para pasar dimensiones, el @page es el único control del lienzo.
    html_fijo = _reescribir_page(
        html_path, "@page { size: %smm %smm; margin: 0; }" % (ancho_mm, alto_mm))
    url = "file://" + os.path.abspath(html_fijo)
    base = [browser, "--headless=new", "--disable-gpu", "--no-sandbox",
            "--user-data-dir=%s" % perfil, "--virtual-time-budget=8000"]
    try:
        subprocess.run(base + ["--no-pdf-header-footer",
                               "--print-to-pdf=%s" % os.path.abspath(pdf_path), url],
                       check=True, capture_output=True, timeout=180)
        if png_path:
            ancho_px = int(round(ancho_mm * PX_POR_MM))
            alto_px = int(round(alto_mm * PX_POR_MM))
            subprocess.run(base + ["--window-size=%d,%d" % (ancho_px, alto_px),
                                   "--screenshot=%s" % os.path.abspath(png_path), url],
                           check=True, capture_output=True, timeout=180)
        return True
    except subprocess.CalledProcessError as exc:
        print("  El navegador devolvió un error: %s"
              % (exc.stderr or b"").decode("utf-8", "ignore")[:300], file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print("  El navegador excedió el tiempo de espera.", file=sys.stderr)
        return False
    finally:
        shutil.rmtree(perfil, ignore_errors=True)


# ------------------------------------------------------------------
# API pública
# ------------------------------------------------------------------

def render(html_path, pdf_path, ancho_mm=264, alto_mm=None, png_path=None,
           channel=None, alto_estimado=600):
    """
    Renderiza la infografía. Devuelve (motor, alto_mm_usado).
    Lanza RuntimeError si no hay ningún navegador disponible.
    """
    try:
        alto = _render_playwright(html_path, pdf_path, ancho_mm, alto_mm,
                                  png_path, channel)
        if alto is not None:
            return "playwright", alto
    except Exception as exc:
        print("  Playwright falló (%s); intento con el navegador del sistema."
              % exc, file=sys.stderr)

    alto = alto_mm or alto_estimado
    if _render_subproceso(html_path, pdf_path, png_path, ancho_mm, alto):
        return "subproceso", alto

    raise RuntimeError(
        "No se encontró un navegador para renderizar.\n"
        "  Instale Playwright:  pip install playwright && playwright install chromium\n"
        "  O asegúrese de tener Microsoft Edge o Google Chrome instalado."
    )
