#!/usr/bin/env python3
"""
Generador de infografías corporativas BTG Pactual a partir de Markdown.

Uso:
    python build_infografia.py revisar   fuente.md
    python build_infografia.py construir fuente.md -o infografia.pdf
    python build_infografia.py construir fuente.md -o infografia.pdf --png
    python build_infografia.py construir fuente.md --html salida.html
    python build_infografia.py iconos
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import html_builder
import icons
import md_parser
import render

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")

BLOQUES_VALIDOS = ("mix", "cifras", "barras", "tarjetas", "roadmap", "destacado")


# ------------------------------------------------------------------
# revisar
# ------------------------------------------------------------------

def cmd_revisar(args):
    meta, secciones = md_parser.load(args.entrada)

    print("Título:  %s" % meta.get("titulo", "(sin definir)"))
    print("Fuente:  %s" % args.entrada)
    print("Bloques: %d\n" % len(secciones))

    avisos = []
    if not meta.get("titulo"):
        avisos.append("Falta 'titulo' en el frontmatter.")
    if not meta.get("hero_stat"):
        avisos.append("Falta 'hero_stat'; la cifra grande del encabezado quedará vacía.")

    for i, sec in enumerate(secciones, 1):
        bloque = sec.get("bloque", "auto")
        auto = ""
        if bloque == "auto":
            bloque = html_builder._auto(sec)
            auto = "  (deducido: falta la directiva <!-- bloque: ... -->)"
        titulo = sec.get("titulo") or "(sin título)"
        n = len(sec.get("filas") or sec.get("items") or [])
        print("  %2d. %-11s %-38s %2d filas%s" % (i, bloque, titulo[:38], n, auto))

        if bloque not in BLOQUES_VALIDOS:
            avisos.append("Bloque %d: tipo '%s' desconocido." % (i, bloque))
        if bloque == "tarjetas" and n > 15:
            avisos.append("Bloque %d: %d tarjetas es mucho para una infografía; "
                          "considere agrupar o resumir." % (i, n))
        if bloque in ("mix", "cifras", "roadmap") and n > 5:
            avisos.append("Bloque %d: %d columnas quedarán muy angostas; "
                          "use 'columnas:' o reduzca las filas." % (i, n))

    alto = render.estimar_alto_mm(secciones, meta)
    print("\nAlto estimado: %.0f mm (con Playwright se mide exacto)." % alto)

    if avisos:
        print("\nAvisos:")
        for a in avisos:
            print("  - %s" % a)
    else:
        print("\nSin avisos: el documento está listo para construir.")
    return 0


# ------------------------------------------------------------------
# construir
# ------------------------------------------------------------------

def cmd_construir(args):
    meta, secciones = md_parser.load(args.entrada)
    if not secciones:
        print("No se encontró ningún bloque en %s." % args.entrada, file=sys.stderr)
        return 1

    salida = args.salida or os.path.splitext(args.entrada)[0] + ".pdf"
    documento = html_builder.build_document(
        meta, secciones,
        logo_path=args.logo,
        css_path=args.css,
        ancho_mm=args.ancho,
    )

    html_path = args.html or os.path.splitext(salida)[0] + ".html"
    with open(html_path, "w", encoding="utf-8") as fh:
        fh.write(documento)

    png_path = None
    if args.png:
        png_path = args.png if isinstance(args.png, str) else \
            os.path.splitext(salida)[0] + ".png"

    estimado = render.estimar_alto_mm(secciones, meta)
    motor, alto = render.render(
        html_path, salida,
        ancho_mm=args.ancho,
        alto_mm=args.alto,
        png_path=png_path,
        channel=args.navegador,
        alto_estimado=estimado,
    )

    print("Infografía generada: %s" % salida)
    print("  Motor: %s   Lienzo: %s × %s mm" % (motor, args.ancho, alto))
    if png_path:
        print("  PNG:   %s" % png_path)
    if motor == "subproceso" and args.alto is None:
        print("  Aviso: sin Playwright el alto es estimado; si sobra o falta espacio,"
              " ajústelo con --alto.")
    if not args.html:
        try:
            os.remove(html_path)
        except OSError:
            pass
    else:
        print("  HTML:  %s" % html_path)
    return 0


# ------------------------------------------------------------------
# iconos
# ------------------------------------------------------------------

def cmd_iconos(args):
    print("Iconos disponibles:\n")
    nombres = icons.disponibles()
    for i in range(0, len(nombres), 4):
        print("  " + "".join("%-18s" % n for n in nombres[i:i + 4]))
    print("\nAlias en lenguaje natural:\n")
    al = icons.alias()
    claves = sorted(al)
    for i in range(0, len(claves), 3):
        print("  " + "".join("%-24s" % ("%s → %s" % (k, al[k])) for k in claves[i:i + 3]))
    return 0


# ------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Genera infografías corporativas BTG Pactual desde Markdown.")
    sub = ap.add_subparsers(dest="comando", required=True)

    p1 = sub.add_parser("revisar", help="Valida el Markdown y muestra los bloques detectados.")
    p1.add_argument("entrada")
    p1.set_defaults(func=cmd_revisar)

    p2 = sub.add_parser("construir", help="Genera el PDF (y opcionalmente el PNG).")
    p2.add_argument("entrada")
    p2.add_argument("-o", "--salida", help="Ruta del PDF de salida.")
    p2.add_argument("--png", nargs="?", const=True, default=False,
                    help="También exporta PNG (opcionalmente con ruta).")
    p2.add_argument("--html", help="Conserva el HTML intermedio en esta ruta.")
    p2.add_argument("--logo", help="Logo alterno (PNG o SVG).")
    p2.add_argument("--css", help="Hoja de estilos alterna.")
    p2.add_argument("--ancho", type=float, default=264,
                    help="Ancho del lienzo en mm (por defecto 264).")
    p2.add_argument("--alto", type=float, default=None,
                    help="Fuerza el alto en mm en lugar de medirlo.")
    p2.add_argument("--navegador", choices=["msedge", "chrome"], default=None,
                    help="Fuerza el canal de navegador de Playwright.")
    p2.set_defaults(func=cmd_construir)

    p3 = sub.add_parser("iconos", help="Lista los iconos disponibles.")
    p3.set_defaults(func=cmd_iconos)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
