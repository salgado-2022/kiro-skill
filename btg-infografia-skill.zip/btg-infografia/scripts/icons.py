"""
Iconografía de línea para las infografías BTG.

Todos los iconos son SVG inline sobre un viewBox 0 0 24 24, con trazo y sin
relleno: el color lo hereda del contenedor (`svg.icon { stroke: ... }`), así que
el mismo icono funciona sobre fondo claro y sobre fondo navy.

Se referencian por nombre desde el Markdown, en la columna `Icono`.
Si el nombre no existe, se usa `punto` y no se rompe el render.
"""

_PATHS = {
    # --- Riesgo, control y cumplimiento ---
    "escudo":       '<path d="M12 3l7 3v6c0 5-3.5 8-7 9-3.5-1-7-4-7-9V6l7-3z"/>',
    "escudo-check": '<path d="M12 3l7 3v6c0 5-3.5 8-7 9-3.5-1-7-4-7-9V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
    "candado":      '<rect x="5" y="10" width="14" height="10" rx="1.6"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/>',
    "balanza":      '<path d="M12 4v16M7 20h10M4 8h16M4 8l-2 5a3 3 0 0 0 6 0L6 8M20 8l-2 5a3 3 0 0 0 6 0l-2-5"/>',
    "alerta":       '<path d="M12 4l9 16H3l9-16z"/><path d="M12 10v4M12 17.2v.1"/>',
    "campana":      '<path d="M12 3a5 5 0 0 0-5 5v3.5L5 15h14l-2-3.5V8a5 5 0 0 0-5-5z"/><path d="M10 18a2 2 0 0 0 4 0"/>',
    "ojo":          '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6z"/><circle cx="12" cy="12" r="2.6"/>',

    # --- Eficiencia y automatización ---
    "engranaje":    '<circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    "rayo":         '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
    "reloj":        '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
    "refrescar":    '<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v4h-4"/>',
    "robot":        '<rect x="4" y="8" width="16" height="11" rx="2"/><circle cx="9" cy="13.5" r="1.2"/><circle cx="15" cy="13.5" r="1.2"/><path d="M12 4v4M8 19v2M16 19v2"/>',

    # --- Crecimiento y negocio ---
    "tendencia":    '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 6h6v6"/>',
    "barras":       '<rect x="3" y="10" width="4.5" height="10"/><rect x="9.75" y="6" width="4.5" height="14"/><rect x="16.5" y="13" width="4.5" height="7"/>',
    "moneda":       '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.3c0-1.3 1.1-2 2.5-2s2.5.8 2.5 2-1.1 1.7-2.5 1.7-2.5.5-2.5 1.8 1.1 2 2.5 2 2.5-.7 2.5-2"/>',
    "diana":        '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.6"/><circle cx="12" cy="12" r="1"/>',
    "cohete":       '<path d="M12 3c3.5 2 5.5 5.5 5.5 9.5L14 16h-4l-3.5-3.5C6.5 8.5 8.5 5 12 3z"/><circle cx="12" cy="10" r="1.6"/><path d="M9 17l-2 4 4-2M15 17l2 4-4-2"/>',
    "globo":        '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 2.6 15 0 18M12 3c-2.6 2.6-2.6 15 0 18"/>',
    "maletin":      '<rect x="3" y="7.5" width="18" height="12" rx="1.6"/><path d="M9 7.5V5.6A1.6 1.6 0 0 1 10.6 4h2.8A1.6 1.6 0 0 1 15 5.6v1.9M3 12.5h18"/>',
    "usuarios":     '<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c0-3.2 2.7-5.2 6-5.2s6 2 6 5.2"/><path d="M16 5.6a3.2 3.2 0 0 1 0 5.9M17.5 14.6c2 .7 3.5 2.4 3.5 4.9"/>',

    # --- Tecnología y arquitectura ---
    "nodos":        '<circle cx="12" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M12 7v4M12 11L6 17M12 11l6 6"/>',
    "capas":        '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
    "api":          '<path d="M9 15l6-6"/><path d="M8 16.5l-1.5 1.5a3.2 3.2 0 0 1-4.5-4.5L6 9.5a3.2 3.2 0 0 1 4.5 0"/><path d="M16 7.5l1.5-1.5a3.2 3.2 0 0 1 4.5 4.5L18 14.5a3.2 3.2 0 0 1-4.5 0"/>',
    "pantalla":     '<rect x="3" y="4" width="18" height="12" rx="1.2"/><path d="M8 20h8M12 16v4"/>',
    "servidor":     '<rect x="3" y="4" width="18" height="6" rx="1.2"/><rect x="3" y="14" width="18" height="6" rx="1.2"/><path d="M7 7h.1M7 17h.1"/>',
    "nube":         '<path d="M7 18h10a4 4 0 0 0 .6-8 5.5 5.5 0 0 0-10.6 1.4A3.4 3.4 0 0 0 7 18z"/>',
    "base-datos":   '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',

    # --- Documentos ---
    "documento":    '<path d="M14 3H7a1.6 1.6 0 0 0-1.6 1.6v14.8A1.6 1.6 0 0 0 7 21h10a1.6 1.6 0 0 0 1.6-1.6V7.6L14 3z"/><path d="M14 3v5h4.6M8.5 13h7M8.5 16.5h5"/>',
    "check-doc":    '<path d="M14 3H7a1.6 1.6 0 0 0-1.6 1.6v14.8A1.6 1.6 0 0 0 7 21h10a1.6 1.6 0 0 0 1.6-1.6V7.6L14 3z"/><path d="M14 3v5h4.6M9 14.5l2 2 4-4"/>',
    "calendario":   '<rect x="3.5" y="5" width="17" height="16" rx="1.6"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',

    # --- Genéricos ---
    "punto":        '<circle cx="12" cy="12" r="4"/>',
    "estrella":     '<path d="M12 3.5l2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 10l6.1-.9L12 3.5z"/>',
    "bandera":      '<path d="M5 21V4M5 5h11l-1.8 3.5L16 12H5"/>',
    "llave":        '<circle cx="7.5" cy="15.5" r="3.5"/><path d="M10 13L20 3M17.5 5.5l2.5 2.5M15 8l2.5 2.5"/>',
}

# Alias en lenguaje natural, para que el Markdown no obligue a memorizar nombres.
_ALIAS = {
    "regulatorio": "escudo", "cumplimiento": "escudo-check", "seguridad": "candado",
    "riesgo": "alerta", "legal": "balanza", "notificacion": "campana",
    "notificaciones": "campana", "monitoreo": "ojo", "control": "ojo",
    "automatizacion": "engranaje", "proceso": "engranaje", "eficiencia": "rayo",
    "tiempo": "reloj", "horas": "reloj", "ciclo": "refrescar",
    "crecimiento": "tendencia", "ingresos": "tendencia", "datos": "barras",
    "metrica": "barras", "dinero": "moneda", "cop": "moneda", "ahorro": "moneda",
    "objetivo": "diana", "meta": "diana", "lanzamiento": "cohete",
    "mercado": "globo", "internacional": "globo", "regional": "globo",
    "negocio": "maletin", "cliente": "usuarios", "clientes": "usuarios",
    "integracion": "nodos", "arquitectura": "capas", "plataforma": "capas",
    "servicio": "api", "sistema": "pantalla", "aplicacion": "pantalla",
    "infraestructura": "servidor", "reporte": "documento", "informe": "documento",
    "certificado": "check-doc", "periodo": "calendario", "fecha": "calendario",
}


def svg(name, cls="icon"):
    """Devuelve el SVG inline del icono. Nunca falla: cae en 'punto'."""
    key = (name or "").strip().lower().replace(" ", "-").replace("_", "-")
    key = _ALIAS.get(key, key)
    body = _PATHS.get(key) or _PATHS["punto"]
    return ('<svg class="%s" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">'
            '%s</svg>' % (cls, body))


def badge(name, extra_class=""):
    """Icono dentro del círculo estándar."""
    cls = "icon-badge" + ((" " + extra_class) if extra_class else "")
    return '<div class="%s">%s</div>' % (cls, svg(name))


def disponibles():
    """Nombres de icono válidos, para la ayuda del CLI."""
    return sorted(_PATHS.keys())


def alias():
    return dict(_ALIAS)
