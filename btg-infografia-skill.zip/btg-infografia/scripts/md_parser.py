"""
Lectura del Markdown fuente de una infografía.

El formato es Markdown normal más dos convenciones:

  1. Frontmatter YAML sencillo (clave: valor, y listas con guiones) delimitado
     por '---'. No usa PyYAML: se parsea a mano para no añadir dependencias.

  2. Una directiva HTML antes de cada tabla, que indica cómo dibujarla:

         <!-- bloque: mix -->
         <!-- bloque: tarjetas, agrupar: Vertical, columnas: 3 -->

     Los parámetros extra van separados por comas, como 'clave: valor'.

La salida es una lista de secciones:

    {"titulo": str, "subtitulo": str|None, "bloque": str, "opciones": dict,
     "headers": [...], "filas": [[...], ...]}
"""

import re

_DIRECTIVA = re.compile(r"<!--\s*(?:bloque|block)\s*:\s*(.+?)\s*-->", re.IGNORECASE)
_CALLOUT = re.compile(r"^>\s*\[!([A-ZÁÉÍÓÚÑ ]+)\]\s*(.*)$", re.IGNORECASE)


# ------------------------------------------------------------------
# Frontmatter
# ------------------------------------------------------------------

def _parse_frontmatter(lines):
    """Frontmatter YAML mínimo: escalares, y listas con '-' indentado."""
    meta, key = {}, None
    for raw in lines:
        line = raw.rstrip()
        if not line.strip() or line.strip().startswith("#"):
            continue
        stripped = line.strip()

        if stripped.startswith("- ") and key:
            meta.setdefault(key, [])
            if isinstance(meta[key], list):
                meta[key].append(stripped[2:].strip())
            continue

        if ":" in stripped:
            k, _, v = stripped.partition(":")
            key = k.strip()
            v = v.strip()
            # Quita comillas envolventes si las hay
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                v = v[1:-1]
            meta[key] = v if v else []
    return meta


def split_frontmatter(text):
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return _parse_frontmatter(lines[1:i]), "\n".join(lines[i + 1:])
    return {}, text


# ------------------------------------------------------------------
# Directivas y tablas
# ------------------------------------------------------------------

def _parse_directiva(texto):
    """'tarjetas, agrupar: Vertical' -> ('tarjetas', {'agrupar': 'Vertical'})"""
    partes = [p.strip() for p in texto.split(",") if p.strip()]
    if not partes:
        return "auto", {}
    nombre = partes[0].lower()
    opciones = {}
    for p in partes[1:]:
        if ":" in p:
            k, _, v = p.partition(":")
            opciones[k.strip().lower()] = v.strip()
    return nombre, opciones


def _es_separador(celdas):
    """Fila de guiones de una tabla Markdown, tolerante a ':---:' y celdas raras."""
    if not celdas:
        return False
    for c in celdas:
        limpio = c.strip().replace(":", "").replace(" ", "")
        if not limpio or set(limpio) != {"-"}:
            return False
    return True


def _celdas(linea):
    fila = linea.strip()
    if fila.startswith("|"):
        fila = fila[1:]
    if fila.endswith("|"):
        fila = fila[:-1]
    return [c.strip() for c in fila.split("|")]


# ------------------------------------------------------------------
# Documento
# ------------------------------------------------------------------

def parse(text):
    """Devuelve (meta, secciones)."""
    meta, cuerpo = split_frontmatter(text)
    lineas = cuerpo.splitlines()

    secciones = []
    actual = None
    directiva_pendiente = None
    parrafos_pendientes = []
    i = 0

    def cerrar():
        if actual and (actual.get("filas") or actual.get("items")):
            secciones.append(actual)

    while i < len(lineas):
        linea = lineas[i]
        stripped = linea.strip()

        # --- Encabezado de sección ---
        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            cerrar()
            actual = {"titulo": m.group(2).strip(), "subtitulo": None,
                      "bloque": "auto", "opciones": {}, "headers": [], "filas": [],
                      "items": []}
            parrafos_pendientes = []
            directiva_pendiente = None
            i += 1
            continue

        # --- Directiva de bloque ---
        d = _DIRECTIVA.search(stripped)
        if d:
            directiva_pendiente = _parse_directiva(d.group(1))
            i += 1
            continue

        # --- Callout tipo > [!CLAVE] texto ---
        c = _CALLOUT.match(stripped)
        if c:
            etiqueta = c.group(1).strip().upper()
            texto = [c.group(2).strip()]
            j = i + 1
            while j < len(lineas) and lineas[j].strip().startswith(">"):
                texto.append(lineas[j].strip().lstrip(">").strip())
                j += 1
            secciones.append({
                "titulo": None, "subtitulo": None, "bloque": "destacado",
                "opciones": {"etiqueta": etiqueta},
                "headers": [], "filas": [],
                "items": [" ".join(t for t in texto if t)],
            })
            i = j
            continue

        # --- Tabla ---
        if stripped.startswith("|") and i + 1 < len(lineas) and \
                _es_separador(_celdas(lineas[i + 1])):
            headers = _celdas(linea)
            filas = []
            j = i + 2
            while j < len(lineas) and lineas[j].strip().startswith("|"):
                filas.append(_celdas(lineas[j]))
                j += 1

            if actual is None:
                actual = {"titulo": None, "subtitulo": None, "bloque": "auto",
                          "opciones": {}, "headers": [], "filas": [], "items": []}

            nombre, opciones = directiva_pendiente or ("auto", {})
            actual["bloque"] = nombre
            actual["opciones"] = opciones
            actual["headers"] = headers
            actual["filas"] = [f for f in filas if any(x.strip() for x in f)]
            if parrafos_pendientes:
                actual["subtitulo"] = parrafos_pendientes[0]
            directiva_pendiente = None
            i = j
            continue

        # --- Párrafo suelto: se usa como subtítulo de la sección ---
        if stripped and not stripped.startswith("<!--"):
            parrafos_pendientes.append(stripped)
            if actual is not None and actual["subtitulo"] is None:
                actual["subtitulo"] = stripped

        i += 1

    cerrar()
    return meta, secciones


def load(path):
    with open(path, "r", encoding="utf-8") as fh:
        return parse(fh.read())
