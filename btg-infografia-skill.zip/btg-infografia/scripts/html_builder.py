"""
Traduce las secciones parseadas a los componentes visuales de la infografía.

Cada tipo de bloque consume una tabla con una forma esperada; si la tabla no
encaja, el bloque cae a una representación segura en lugar de romperse.

Tipos soportados
----------------
  mix        | Porcentaje | Concepto | Icono? |
  cifras     | Cifra | Descripción | Icono? |
  barras     | Etiqueta | Valor | Ejemplos? |
  tarjetas   | Iniciativa | Grupo | Beneficio | Etiquetas? |
  roadmap    | Título | Descripción | Icono? |
  destacado  (generado por el callout > [!CLAVE] ...)
"""

import base64
import html
import os
import re

import icons

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")

# Colores de etiqueta por nombre, alineados con las variables del tema.
_TAG_COLORES = {
    "operativo": "var(--tag-operativo)",
    "mercado": "var(--tag-mercado)",
    "credito": "var(--tag-credito)",
    "crédito": "var(--tag-credito)",
    "cumplimiento": "var(--tag-cumplimiento)",
    "reputacional": "var(--tag-reputacional)",
    "tecnologico": "var(--tag-tecnologico)",
    "tecnológico": "var(--tag-tecnologico)",
    "liquidez": "var(--tag-liquidez)",
}

# Paleta de las columnas de agrupación (monocromía azul, de claro a oscuro).
_GRUPO_COLORES = ["var(--blue)", "#0E3D73", "var(--navy)", "var(--teal)", "var(--purple)"]


def esc(t):
    return html.escape(t or "", quote=False)


def inline(t):
    """Markdown mínimo dentro de celdas: **negrita**, *cursiva*, `código`."""
    t = esc(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", t)
    t = re.sub(r"`(.+?)`", r"<code>\1</code>", t)
    return t


def _col(headers, *nombres):
    """Índice de la primera columna cuyo encabezado contenga alguno de los nombres."""
    bajos = [h.strip().lower() for h in headers]
    for nombre in nombres:
        n = nombre.lower()
        for i, h in enumerate(bajos):
            if n in h:
                return i
    return None


def _celda(fila, idx, defecto=""):
    if idx is None or idx >= len(fila):
        return defecto
    return fila[idx].strip()


def _col_numerica(filas, excluir=(), desde=0):
    """
    Primera columna cuyas celdas sean mayoritariamente numéricas.

    Hace falta porque buscar por nombre es ambiguo: un encabezado como
    'Foco de valor' contiene la palabra 'valor' pero es la etiqueta, no la
    cifra. El contenido desempata mejor que el título.
    """
    if not filas:
        return None
    ancho = max(len(f) for f in filas)
    for i in range(desde, ancho):
        if i in excluir:
            continue
        celdas = [f[i] for f in filas if i < len(f) and f[i].strip()]
        if not celdas:
            continue
        numericas = sum(1 for c in celdas if _numero(c) is not None)
        if numericas >= max(1, int(len(celdas) * 0.7)):
            return i
    return None


_MILES = re.compile(r"^\d{1,3}(\.\d{3})+$")


def _numero(texto):
    """
    Extrae el primer número de una celda ('5', '~2 h', '50%', '1.640').

    Interpreta la convención colombiana: el punto separa miles y la coma
    decimales. Sin esto, '1.640' se leería como 1,64 y las barras saldrían al
    revés, con los valores más grandes dibujados más cortos.
    """
    m = re.search(r"-?\d[\d.,]*", texto or "")
    if not m:
        return None
    crudo = m.group(0).rstrip(".,")
    negativo = crudo.startswith("-")
    cuerpo = crudo.lstrip("-")

    if "," in cuerpo:
        # La coma es siempre decimal: los puntos que la acompañan son miles.
        cuerpo = cuerpo.replace(".", "").replace(",", ".")
    elif _MILES.match(cuerpo):
        # 1.640 / 1.234.567 -> separadores de miles, no decimales.
        cuerpo = cuerpo.replace(".", "")

    try:
        valor = float(cuerpo)
    except ValueError:
        return None
    return -valor if negativo else valor


def _tag_color(nombre):
    return _TAG_COLORES.get(nombre.strip().lower(), "var(--blue)")


# ------------------------------------------------------------------
# Cabecera de sección
# ------------------------------------------------------------------

def _head(sec):
    out = []
    if sec.get("titulo"):
        out.append('<div class="section-head"><span class="section-eyebrow">%s</span></div>'
                   % inline(sec["titulo"]))
    if sec.get("subtitulo"):
        out.append('<p class="section-sub">%s</p>' % inline(sec["subtitulo"]))
    return "".join(out)


# ------------------------------------------------------------------
# Bloques
# ------------------------------------------------------------------

def _bloque_mix(sec):
    h = sec["headers"]
    i_pct = _col(h, "porcentaje", "%", "peso") or 0
    i_txt = _col(h, "concepto", "descripcion", "descripción", "label", "texto")
    i_ico = _col(h, "icono", "icon")
    if i_txt is None:
        i_txt = 1 if len(h) > 1 else 0

    cols = int(sec["opciones"].get("columnas", 0)) or min(len(sec["filas"]), 4) or 1

    tarjetas = []
    for fila in sec["filas"]:
        pct_txt = _celda(fila, i_pct)
        pct = _numero(pct_txt)
        ancho = max(0, min(100, pct if pct is not None else 0))
        tarjetas.append(
            '<div class="mix-card">'
            '<div class="mix-top">%s<div class="mix-pct">%s</div></div>'
            '<div class="mix-label">%s</div>'
            '<div class="mix-bar-track"><div class="mix-bar-fill" style="width:%s%%"></div></div>'
            '</div>' % (icons.badge(_celda(fila, i_ico, "punto")),
                        inline(pct_txt), inline(_celda(fila, i_txt)), ancho)
        )

    return ('<div class="section tight">%s<div class="grid" '
            'style="grid-template-columns:repeat(%d,1fr)">%s</div></div>'
            % (_head(sec), cols, "".join(tarjetas)))


def _bloque_cifras(sec):
    h = sec["headers"]
    i_num = _col(h, "cifra", "valor", "indicador", "dato") or 0
    i_txt = _col(h, "descripcion", "descripción", "detalle", "concepto")
    i_ico = _col(h, "icono", "icon")
    if i_txt is None:
        i_txt = 1 if len(h) > 1 else 0

    cols = int(sec["opciones"].get("columnas", 0)) or min(len(sec["filas"]), 4) or 1

    tarjetas = []
    for fila in sec["filas"]:
        tarjetas.append(
            '<div class="figure-card">%s<div>'
            '<div class="figure-num">%s</div>'
            '<div class="figure-label">%s</div></div></div>'
            % (icons.badge(_celda(fila, i_ico, "punto")),
               inline(_celda(fila, i_num)), inline(_celda(fila, i_txt)))
        )

    return ('<div class="section tight">%s<div class="grid" '
            'style="grid-template-columns:repeat(%d,1fr)">%s</div></div>'
            % (_head(sec), cols, "".join(tarjetas)))


def _bloque_barras(sec):
    h = sec["headers"]
    i_lbl = _col(h, "foco", "etiqueta", "categoria", "categoría", "concepto") or 0
    i_ej = _col(h, "ejemplo", "detalle", "nota")
    # El contenido manda sobre el nombre: 'Foco de valor' es etiqueta, no cifra.
    i_val = _col_numerica(sec["filas"], excluir=(i_lbl, i_ej))
    if i_val is None:
        i_val = _col(h, "cantidad", "iniciativas", "total", "valor")
    if i_val is None or i_val == i_lbl:
        i_val = 1 if len(h) > 1 else 0

    valores = [_numero(_celda(f, i_val)) or 0 for f in sec["filas"]]
    maximo = max(valores) if valores else 1
    if maximo <= 0:
        maximo = 1

    filas_html = []
    for fila, val in zip(sec["filas"], valores):
        ancho = max(2.0, (val / maximo) * 100.0)
        filas_html.append(
            '<div class="impact-row">'
            '<div class="impact-label">%s</div>'
            '<div class="impact-track"><div class="impact-fill" style="width:%.1f%%"></div></div>'
            '<div class="impact-value">%s</div></div>'
            % (inline(_celda(fila, i_lbl)), ancho, inline(_celda(fila, i_val)))
        )
        ejemplos = _celda(fila, i_ej)
        if ejemplos:
            filas_html.append('<div class="impact-examples">%s</div>'
                              % inline(ejemplos.replace(",", " ·")))

    return ('<div class="section tight">%s<div class="impact-chart">%s</div></div>'
            % (_head(sec), "".join(filas_html)))


def _bloque_tarjetas(sec):
    h = sec["headers"]
    i_nom = _col(h, "iniciativa", "nombre", "titulo", "título", "proyecto") or 0
    i_grp = _col(h, sec["opciones"].get("agrupar", "vertical"), "grupo", "area", "área")
    i_ben = _col(h, "beneficio", "descripcion", "descripción", "valor", "detalle")
    i_tag = _col(h, "etiqueta", "riesgo", "tags", "categoria", "categoría")

    if i_ben is None:
        i_ben = 1 if len(h) > 1 else None

    # Agrupa preservando el orden de aparición.
    grupos, orden = {}, []
    for fila in sec["filas"]:
        g = _celda(fila, i_grp) if i_grp is not None else ""
        if g not in grupos:
            grupos[g] = []
            orden.append(g)
        grupos[g].append(fila)

    cols_op = sec["opciones"].get("columnas")
    cols = int(cols_op) if cols_op else max(1, min(len(orden), 4))

    etiquetas_vistas = []
    columnas_html = []
    for idx, g in enumerate(orden):
        color = _GRUPO_COLORES[idx % len(_GRUPO_COLORES)]
        cabecera = ""
        if g:
            cabecera = ('<div class="vert-head"><span class="name">%s</span>'
                        '<span class="count">%d</span></div>'
                        % (inline(g), len(grupos[g])))

        tarjetas = []
        for fila in grupos[g]:
            tags_html = ""
            crudo = _celda(fila, i_tag)
            if crudo:
                partes = [p.strip() for p in re.split(r"[·,;/]| - ", crudo) if p.strip()]
                chips = []
                for p in partes:
                    if p not in etiquetas_vistas:
                        etiquetas_vistas.append(p)
                    chips.append('<span class="tag" style="background:%s">%s</span>'
                                 % (_tag_color(p), inline(p)))
                tags_html = '<div class="tag-row">%s</div>' % "".join(chips)

            beneficio = _celda(fila, i_ben)
            tarjetas.append(
                '<div class="init-card"><div class="init-name">%s</div>%s%s</div>'
                % (inline(_celda(fila, i_nom)),
                   ('<div class="init-benefit">%s</div>' % inline(beneficio)) if beneficio else "",
                   tags_html)
            )

        columnas_html.append('<div class="vert-col" style="--vc:%s">%s%s</div>'
                             % (color, cabecera, "".join(tarjetas)))

    leyenda = ""
    if etiquetas_vistas:
        items = "".join('<div class="legend-item">'
                        '<span class="legend-dot" style="background:%s"></span>%s</div>'
                        % (_tag_color(e), inline(e)) for e in etiquetas_vistas)
        leyenda = '<div class="legend-row">%s</div>' % items

    return ('<div class="section tight">%s<div class="vert-grid" '
            'style="grid-template-columns:repeat(%d,1fr)">%s</div>%s</div>'
            % (_head(sec), cols, "".join(columnas_html), leyenda))


def _bloque_roadmap(sec):
    h = sec["headers"]
    i_tit = _col(h, "titulo", "título", "iniciativa", "nombre", "capacidad") or 0
    i_des = _col(h, "descripcion", "descripción", "detalle", "nota")
    i_ico = _col(h, "icono", "icon")
    if i_des is None:
        i_des = 1 if len(h) > 1 else None

    cols = int(sec["opciones"].get("columnas", 0)) or max(1, min(len(sec["filas"]), 5))

    chips = []
    for fila in sec["filas"]:
        desc = _celda(fila, i_des)
        chips.append('<div class="roadmap-chip">%s<div class="t">%s</div>%s</div>'
                     % (icons.badge(_celda(fila, i_ico, "punto")),
                        inline(_celda(fila, i_tit)),
                        ('<div class="d">%s</div>' % inline(desc)) if desc else ""))

    return ('<div class="roadmap">%s<div class="grid" '
            'style="grid-template-columns:repeat(%d,1fr)">%s</div></div>'
            % (_head(sec), cols, "".join(chips)))


def _bloque_destacado(sec):
    etiqueta = sec["opciones"].get("etiqueta", "CLAVE")
    texto = " ".join(sec.get("items") or [])
    icono = "estrella" if etiqueta.upper() in ("CLAVE", "DESTACADO") else "punto"
    return ('<div class="highlight">%s<div>'
            '<div class="h-title">%s</div><div class="h-text">%s</div></div></div>'
            % (icons.badge(icono), inline(etiqueta.title()), inline(texto)))


_BLOQUES = {
    "mix": _bloque_mix,
    "cifras": _bloque_cifras,
    "barras": _bloque_barras,
    "tarjetas": _bloque_tarjetas,
    "roadmap": _bloque_roadmap,
    "destacado": _bloque_destacado,
}


def _auto(sec):
    """Heurística cuando no hay directiva: elige el bloque por la forma de la tabla."""
    h = [x.lower() for x in sec["headers"]]
    unido = " ".join(h)
    if any("%" in _celda(f, 0) for f in sec["filas"][:3]):
        return "mix"
    if _col(h, "beneficio") is not None or len(h) >= 4:
        return "tarjetas"
    if "ejemplo" in unido or len(h) == 3:
        return "barras"
    if len(h) == 2:
        return "cifras"
    return "cifras"


# ------------------------------------------------------------------
# Hero, pie y documento
# ------------------------------------------------------------------

def _logo_html(logo_path):
    if logo_path and os.path.exists(logo_path):
        with open(logo_path, "rb") as fh:
            b64 = base64.b64encode(fh.read()).decode("ascii")
        ext = os.path.splitext(logo_path)[1].lstrip(".").lower() or "png"
        mime = "svg+xml" if ext == "svg" else ext
        return '<img class="hero-logo" src="data:image/%s;base64,%s" alt="BTG Pactual">' % (mime, b64)
    return '<span class="logo-fallback">btg pactual</span>'


def _split_par(texto):
    """'11 | iniciativas entregadas' -> ('11', 'iniciativas entregadas')"""
    if "|" in texto:
        a, _, b = texto.partition("|")
        return a.strip(), b.strip()
    return texto.strip(), ""


def build_hero(meta, logo_path):
    partes = ['<div class="hero"><div class="hero-top"><div class="hero-brand">']
    partes.append(_logo_html(logo_path))
    if meta.get("kicker"):
        partes.append('<span class="kicker">%s</span>' % inline(meta["kicker"]))
    partes.append("</div>")
    if meta.get("clasificacion"):
        partes.append('<span class="badge-clasificacion">%s</span>' % inline(meta["clasificacion"]))
    partes.append("</div>")

    partes.append('<h1 class="hero-title">%s</h1>' % inline(meta.get("titulo", "Infografía")))
    if meta.get("subtitulo"):
        partes.append('<p class="hero-subtitle">%s</p>' % inline(meta["subtitulo"]))

    stat = meta.get("hero_stat")
    minis = meta.get("hero_mini") or []
    if isinstance(minis, str):
        minis = [minis]

    if stat or minis:
        partes.append('<div class="hero-stat-row">')
        if stat:
            num, lbl = _split_par(stat)
            partes.append('<div class="hero-stat-main"><span class="num">%s</span>'
                          '<span class="lbl">%s</span></div>' % (inline(num), inline(lbl)))
        if minis:
            partes.append('<div class="hero-mini-stats">')
            for m in minis:
                num, lbl = _split_par(m)
                # El salto se inserta después de escapar; al revés se vería
                # literalmente el texto "<br>" en la infografía.
                etiqueta = inline(lbl).replace(" · ", "<br>", 1)
                partes.append('<div class="hero-mini"><span class="n">%s</span>'
                              '<span class="l">%s</span></div>'
                              % (inline(num), etiqueta))
            partes.append("</div>")
        partes.append("</div>")

    partes.append("</div>")
    return "".join(partes)


def build_footer(meta):
    nota = meta.get("nota_cierre", "")
    derecha = meta.get("pie_derecha", "BTG Pactual Colombia")
    if not nota and not derecha:
        return ""
    return ('<div class="footer"><div class="footer-note">%s</div>'
            '<div class="footer-meta">%s</div></div>'
            % (inline(nota), inline(derecha).replace(" · ", " · ")))


def build_document(meta, secciones, logo_path=None, css_path=None, ancho_mm=264):
    css_path = css_path or os.path.join(ASSETS, "theme.css")
    if logo_path is None:
        for cand in ("btg-logo.png", "btg-logo.svg"):
            p = os.path.join(ASSETS, cand)
            if os.path.exists(p):
                logo_path = p
                break

    with open(css_path, "r", encoding="utf-8") as fh:
        css = fh.read()

    cuerpo = [build_hero(meta, logo_path)]
    for sec in secciones:
        nombre = sec.get("bloque", "auto")
        if nombre == "auto":
            nombre = _auto(sec)
        fn = _BLOQUES.get(nombre)
        if fn is None:
            fn = _BLOQUES["cifras"]
        cuerpo.append(fn(sec))
    cuerpo.append(build_footer(meta))

    return """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>%s</title>
<style>
:root { --ancho: %dmm; }
/* BTG-PAGE-START */
@page { size: %dmm 600mm; margin: 0; }
/* BTG-PAGE-END */
%s
</style>
</head>
<body>
<div class="page">
%s
</div>
</body>
</html>
""" % (esc(meta.get("titulo", "Infografía BTG Pactual")), ancho_mm, ancho_mm,
       css, "\n".join(cuerpo))
