# btg-report-pdf

Skill de Kiro que convierte un documento Markdown en un reporte PDF con la identidad
visual de BTG Pactual, incluyendo gráficas elegidas automáticamente según los datos.

## Instalación

Copie la carpeta `btg-report-pdf/` a una de estas ubicaciones:

- `.kiro/skills/btg-report-pdf/` — alcance de proyecto (recomendado, versionable)
- `~/.kiro/skills/btg-report-pdf/` — alcance global

Luego instale las dependencias:

```bash
pip install -r requirements.txt
playwright install chromium     # opcional
```

En entornos corporativos con descargas restringidas, omita `playwright install` y use
`--navegador msedge`: Playwright reutiliza el Microsoft Edge ya instalado.

## Uso

Desde Kiro, basta con pedirlo en lenguaje natural; la skill se activa sola:

> Genera el PDF con formato BTG del informe reglas-negocio.md

O invocarla directamente con `/btg-report-pdf`.

## Uso manual

```bash
# 1. Ver qué datos son graficables y por qué
python scripts/build_report.py analizar informe.md --json graficas.json

# 2. Revisar y editar graficas.json (enabled, chart, title, caption)

# 3. Generar el PDF
python scripts/build_report.py construir informe.md -o informe.pdf --graficas graficas.json
```

## Documentación

- `references/metadatos-portada.md` — cómo se deducen los campos de portada
- `references/formato-insumo.md` — qué entiende el parser de Markdown
- `references/guia-graficas.md` — criterios de selección de tipo de gráfica
- `references/sistema-diseno.md` — paleta, componentes y motor de renderizado

## Ejemplo

`examples/reglas-negocio.md` es un documento completo de muestra:

```bash
python scripts/build_report.py construir examples/reglas-negocio.md -o ejemplo.pdf
```
