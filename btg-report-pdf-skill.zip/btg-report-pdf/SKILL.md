---
name: btg-report-pdf
description: Genera reportes PDF corporativos de BTG Pactual a partir de un archivo Markdown, con portada de marca, paleta institucional, tablas con badges de estado y gráficas elegidas automáticamente según los datos. Úsala cuando pidan convertir un informe, reporte, análisis o documento Markdown a un PDF con formato BTG Pactual, o cuando pidan graficar los datos de un informe para presentarlo a un equipo interno.
license: Uso interno BTG Pactual
compatibility: Requiere Python 3.8+, matplotlib y un navegador Chromium (Playwright, Edge o Chrome). Sin dependencias de sistema adicionales.
metadata:
  version: "1.0"
  categoria: reporteria
---

# Reportería corporativa BTG Pactual

Convierte un documento Markdown en un PDF con la identidad visual de BTG Pactual:
portada de marca, secciones numeradas, tablas con badges de estado, cajas destacadas
y gráficas generadas a partir de los datos del propio documento.

## Flujo de trabajo

Ejecuta siempre estos tres pasos en orden. No saltes el paso 2.

### 1. Preparar el insumo

Verifica que el Markdown tenga frontmatter con los metadatos de portada. Si no lo tiene,
**agrégalo tú** a partir del contenido del documento y confirma los campos con la persona
antes de continuar (sobre todo `autor`, `destinatario` y `clasificacion`).

```yaml
---
titulo: Título principal del informe
kicker: Línea superior corta (ej. "Documento de negocio · AtlasCore V2")
subtitulo: Una o dos frases que resumen el alcance del documento.
clasificacion: CONFIDENCIAL
clasificacion_larga: Documento de negocio / información sensible
estado: Vigente
autor: Nombre — Cargo, BTG Pactual Colombia
destinatario: Equipo destinatario
fecha_evento: 2026-08-26
fecha_emision: 2026-08-31
encabezado: Texto corto para el encabezado de las páginas interiores
---
```

El formato completo del cuerpo está en `references/formato-insumo.md`. Léelo si el
documento usa cajas destacadas, evidencia con imágenes o marcadores de gráfica.

### 2. Analizar qué datos vale la pena graficar

```bash
python scripts/build_report.py analizar informe.md --json graficas.json
```

Esto imprime cada propuesta con su tipo de gráfica, nivel de confianza y la razón por
la que se eligió. **Revisa las propuestas antes de construir**:

- Descarta las que no aporten al mensaje del documento poniendo `"enabled": false`.
  Una gráfica que solo repite una tabla de tres filas resta, no suma.
- Corrige `chart` si el tipo elegido no cuenta bien la historia. Los criterios están en
  `references/guia-graficas.md`.
- Reescribe `title` y agrega `caption` en lenguaje de negocio. El pie automático es
  descriptivo; uno bueno señala la implicación.

Presenta el resumen del análisis a la persona y confirma qué gráficas entran antes de
generar el PDF final.

### 3. Construir el PDF

```bash
python scripts/build_report.py construir informe.md -o informe.pdf --graficas graficas.json
```

Opciones útiles:

| Opción | Para qué |
|---|---|
| `--sin-graficas` | Solo el documento formateado |
| `--html salida.html` | Guarda el HTML intermedio para depurar el diseño |
| `--navegador msedge` | Fuerza el Edge del sistema en vez de descargar Chromium |
| `--graficas-al-final` | No ancla cada gráfica junto a su tabla |
| `--titulo`, `--autor`, etc. | Sobrescribe metadatos sin tocar el Markdown |

Al terminar, **abre el PDF y revísalo página por página** antes de entregarlo. Verifica
que ninguna tabla quede partida, que las gráficas sean legibles y que la portada no
tenga campos vacíos.

## Reglas de contenido

- **Documentos de negocio, no técnicos.** Si el insumo menciona rutas de archivos,
  nombres de clases, commits o detalles de implementación, tradúcelos a lenguaje de
  negocio antes de generar el PDF, salvo que la persona pida explícitamente el detalle
  técnico. Pregunta si tienes duda.
- **Datos personales.** Si el documento incluye nombres, documentos de identidad o
  capturas con PII, confirma con la persona si deben ir completos o minimizados. Para
  marcar una imagen que contiene PII, antepón `[PII]` al pie: `![[PII] Consulta a la
  tabla X](captura.png)`.
- **No inventes cifras.** Las gráficas se construyen solo con datos presentes en las
  tablas del insumo. Si un dato falta, dilo en el documento; no lo estimes.

## Instalación

```bash
pip install -r requirements.txt
playwright install chromium     # opcional si ya hay Edge o Chrome instalado
```

En entornos con restricción de descargas, omite `playwright install` y usa
`--navegador msedge`, que reutiliza el Edge ya instalado en la máquina. Si Playwright
no está disponible, la skill invoca automáticamente el navegador del sistema; en ese
modo el PDF sale sin numeración de páginas.

Detalle de la identidad visual y los componentes disponibles en
`references/sistema-diseno.md`.
