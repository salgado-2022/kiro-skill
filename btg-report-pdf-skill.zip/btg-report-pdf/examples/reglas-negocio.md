---
titulo: Reglas de negocio y validaciones de retiros — Productos FIC y FVP
kicker: Documento de negocio · AtlasCore V2
subtitulo: Catálogo de controles de prevención de fraude aplicados a retiros hacia cuentas de terceros: qué controles existen, cuáles están activos hoy y qué cambió frente al diseño original.
clasificacion: CONFIDENCIAL
clasificacion_larga: Documento de negocio / información sensible
estado: Vigente
autor: Juan Salgado González — Analista de TI, BTG Pactual Colombia
destinatario: Equipo de Negocio / Equipo de Fraude
fecha_evento: 2026-08-26
fecha_emision: 2026-08-31
encabezado: Reglas de negocio y validaciones · AtlasCore V2
---

---

## 1. ¿Qué hace este proceso, en términos simples?

AtlasCore V2 es un proceso automático (worker) que revisa transacciones de **retiro** de clientes en los productos FIC y FVP, las somete a una serie de controles de negocio (antifraude / prevención de riesgo operativo) y decide, para cada transacción, si:

- Puede seguir su curso normal (**confirmación automática**), o
- Debe pasar por una **confirmación humana** (una llamada de verificación al cliente) antes de ejecutarse.

El resultado de cada validación queda registrado y se exporta a un archivo CSV que alimenta al equipo de operaciones / call center.

---

## 2. Alcance de las transacciones evaluadas (filtro de entrada)

Antes de aplicar cualquier regla de negocio, el sistema descarta automáticamente las transacciones que no son relevantes para el control de riesgo. Solo entran al proceso de validación las transacciones que cumplen:

### FIC
- El tipo de operación debe ser **RETIRO** (se ignoran consignaciones u otros movimientos).
- **Excepción sin más chequeos**: si la operación es "Sin sellos" y el producto destino es "CHEQUE", se considera válida automáticamente sin revisar identificación del beneficiario.
- En el resto de los casos, se exige que exista el número de identificación del cliente y del beneficiario, y que **no sean la misma persona** (es decir, se enfoca en retiros hacia terceros, no hacia el mismo titular).

### FVP
- El tipo de operación debe ser **RETIRO**.
- Se exige número de identificación del cliente y del beneficiario, y que **no sean la misma persona**.

En otras palabras: el control de negocio está diseñado para **retiros hacia cuentas de terceros**, que es el escenario de mayor riesgo de fraude (suplantación, ingeniería social, desvío de fondos).

---

## 3. Catálogo de reglas de validación (qué existe en el sistema)

Estas son todas las reglas de negocio que están **construidas y disponibles** en el código, independientemente de si hoy están encendidas o apagadas. Aplican igual para FIC y FVP salvo que se indique lo contrario.

| # | Regla de negocio | Qué pregunta responde | Consecuencia si falla |
|---|---|---|---|
| 1 | **Validación de Login / Identidad digital** | ¿El correo electrónico con el que el cliente inició sesión (Cognito) coincide con el correo de notificaciones o el correo del tercero autorizado registrado en el core? | Marca la operación para confirmación (vía SMS en la lógica interna, pero termina escalando a revisión humana) |
| 2 | **Cuentas registradas del beneficiario** | ¿La cuenta bancaria destino del retiro está previamente registrada a nombre del beneficiario indicado? | Si la cuenta destino **no** está registrada para ese beneficiario, se marca para **confirmación humana obligatoria** (llamada) |
| 3 | **Fecha de registro / antigüedad del usuario** | ¿El usuario digital fue recién modificado (por ejemplo, cambio reciente de datos de contacto) en lugar de ser una cuenta antigua y estable? Se compara fecha de creación vs. fecha de última modificación en Cognito. | Si la fecha de creación es igual a la de modificación (es decir, nunca se ha modificado, lo cual paradójicamente en esta regla se interpreta como señal a validar) se marca para confirmación |
| 4 | **Promedio histórico de transacciones (monto atípico)** | ¿El valor de la transacción supera el 130% del promedio histórico de transacciones del cliente? | Si supera el umbral, se marca la operación como sospechosa por monto atípico y requiere confirmación |
| 5 | **Horario y día hábil de la transacción** | ¿La transacción se realizó dentro del horario permitido (7:00 a.m. – 6:00 p.m.) y en un día hábil colombiano (no fin de semana ni festivo)? | Si es fuera de horario o en día no hábil, se marca para confirmación humana (llamada) |

### Detalle de negocio de cada regla

**1. Login / Identidad digital**
Compara el correo electrónico usado para autenticarse en el aplicativo (Cognito) contra los correos de contacto que el core bancario tiene registrados para ese cliente (correo de notificaciones o correo de un tercero autorizado). Busca detectar sesiones iniciadas con credenciales/correos que no corresponden al titular real de la cuenta, lo cual es un indicador de posible toma de control de cuenta (account takeover).

**2. Cuentas registradas del beneficiario**
Es el control central de prevención de fraude en retiros a terceros. Antes de permitir el giro de dinero a una cuenta bancaria de un tercero, valida que esa cuenta ya esté registrada/asociada al beneficiario declarado. Si el número de cuenta destino no aparece vinculado a ese beneficiario en la base de cuentas bancarias, la operación no puede fluir automáticamente: requiere que alguien del banco llame al cliente para confirmar que en efecto autorizó ese giro a esa cuenta específica.

**3. Fecha de registro / antigüedad del usuario**
Es un control anti-fraude basado en el comportamiento del usuario digital. Cuando alguien compromete una cuenta (por ejemplo mediante ingeniería social o suplantación), es común que primero modifique datos de contacto (correo, teléfono) para luego intentar mover dinero. Esta regla compara la fecha de creación del usuario en el sistema de identidad (Cognito) contra la fecha de la última modificación, para identificar patrones de cambios recientes de datos previos a una transacción de riesgo. Solo aplica cuando existe información suficiente del usuario y, para personas jurídicas, además intenta emparejar el nombre del participante/representante con fuzzy matching (comparación aproximada de texto) contra los datos de Cognito.

**4. Promedio histórico de transacciones**
Detecta montos "fuera de lo normal" para ese cliente en particular. Se calcula cuánto ha transado históricamente el cliente en promedio y, si la transacción actual excede el 130% de ese promedio, se enciende una alerta de monto atípico. Es un control de comportamiento (no un tope fijo en pesos), pensado para atrapar retiros inusualmente grandes respecto al patrón habitual del cliente, sin penalizar a clientes que naturalmente manejan montos altos.

**5. Horario y día hábil**
Filtra operaciones ejecutadas en horarios o días donde normalmente no hay atención humana ni actividad legítima esperada (de noche, madrugada, fines de semana o festivos colombianos, calculados dinámicamente incluyendo Semana Santa y festivos trasladables por la ley colombiana). Operar fuera de esas franjas es un indicador adicional de comportamiento anómalo o de intento de aprovechar ventanas sin supervisión.

---

## 4. Estado actual: qué reglas están activas HOY (26/08/2026)

Desde el commit `feat: ajusta DI y validación de cuentas registradas` (04/08/2026), el sistema **desactivó de forma deliberada** la mayoría de las reglas descritas arriba, dejando únicamente un control de negocio activo:

| Regla de negocio | Estado actual |
|---|✅ / ❌|
| Login / Identidad digital | ❌ **Desactivada** |
| **Cuentas registradas del beneficiario** | ✅ **Activa** (es la única regla de validación en ejecución) |
| Fecha de registro / antigüedad del usuario | ❌ **Desactivada** |
| Promedio histórico de transacciones (monto atípico) | ❌ **Desactivada** |
| Horario y día hábil | ❌ **Desactivada** |

Esto significa que, en la operación diaria actual, el único filtro de riesgo que efectivamente detiene o escala una transacción es: **¿la cuenta destino del retiro está registrada a nombre del beneficiario?** Todas las demás señales de riesgo (identidad digital, comportamiento del usuario, monto atípico, horario) están construidas en el código pero no se evalúan ni afectan el resultado de ninguna transacción real.

### Regla de decisión de confirmación (humana vs. automática)

Independientemente de qué validaciones estén activas, el sistema decide si una transacción requiere llamada humana con esta lógica de prioridad (de mayor a menor):

1. **Regla combinada "Cuenta registrada + Fecha de registro" (prioridad más alta)** — ❌ **Desactivada actualmente**. Cuando estaba activa, exigía que ambas validaciones (cuenta registrada y fecha de registro) se hubieran evaluado con información suficiente y que alguna hubiera fallado, para forzar confirmación humana.
2. **Regla "hay una alerta tipo llamada" (prioridad media)** — ✅ Activa. Si cualquier validación activa devuelve una alerta de tipo "Llamada" (como la de cuentas registradas), se exige **confirmación humana**.
3. **Regla por defecto (prioridad más baja)** — ✅ Activa. Si ninguna de las anteriores aplica, la transacción se resuelve como **confirmación automática** (no se requiere llamada).

En la práctica actual, dado que la única validación activa (cuentas registradas) genera una alerta tipo "Llamada" cuando falla, el flujo de decisión real es: *si la cuenta destino no está registrada a nombre del beneficiario → confirmación humana; si está registrada → confirmación automática.*

---

## 5. Estado histórico: qué reglas estuvieron activas antes

En la versión inicial del sistema (commit `New version AtlasCoreV2`, previo al ajuste del 04/08/2026), **todas las reglas de negocio del catálogo (sección 3) estaban activas simultáneamente** para ambos productos (FIC y FVP), incluyendo:

- Validación de login / identidad digital.
- Validación de cuentas registradas del beneficiario.
- Validación de fecha de registro / antigüedad del usuario.
- Validación de promedio histórico de transacciones (monto atípico) — esta solo aplicaba al producto FIC.
- Validación de horario y día hábil.

Además, la regla de decisión de confirmación combinada ("cuenta registrada + fecha de registro fallidas simultáneamente") también estaba activa, lo que daba un criterio adicional y más estricto para escalar a confirmación humana, independiente de la regla general de "cualquier alerta tipo llamada".

Es decir: el diseño original contemplaba un control de riesgo en capas (identidad, comportamiento del usuario, monto, horario, cuenta destino), y el ajuste posterior redujo deliberadamente el proceso a un único control operativo (cuenta destino registrada), dejando el resto del catálogo implementado pero inactivo, probablemente en espera de recalibración, reducción de falsos positivos, o un rediseño del criterio de riesgo.

---

## 6. Resumen ejecutivo

| Aspecto | Detalle |
|---|---|
| Objetivo del proceso | Prevenir fraude/riesgo operativo en retiros de FIC y FVP hacia cuentas de terceros |
| Transacciones evaluadas | Solo retiros, con beneficiario distinto al titular (salvo excepción de cheque sin sello) |
| Reglas de negocio construidas | 5 (login, cuenta registrada, fecha de registro, monto atípico, horario/día hábil) |
| Reglas de negocio activas hoy | 1 (cuenta registrada del beneficiario) |
| Reglas de negocio activas originalmente | 5 de 5 |
| Consecuencia de una alerta | Confirmación humana (llamada) en lugar de confirmación automática |
| Producto con regla adicional histórica | FIC (validación de promedio de transacciones no existía para FVP) |

---

## 7. Notas y limitaciones de este análisis

- Este documento describe el comportamiento tal como está **configurado en el código fuente** (registro de dependencias), que es la fuente de verdad de qué se ejecuta en producción. No se validó contra logs de ejecución real ni configuración externa en base de datos/variables de entorno que pudiera sobrescribir este comportamiento en tiempo de ejecución.
- Los umbrales de negocio (130% del promedio, franja horaria 7:00–18:00, tolerancia de coincidencia de nombres) están fijos en el código; cualquier cambio de política de negocio implicaría un cambio de código y despliegue, no una configuración editable en caliente.
- No se encontraron reglas de validación adicionales fuera de las cinco descritas en la sección 3 dentro de `v2/src`.

