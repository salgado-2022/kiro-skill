---
titulo: Prueba de tipos de gráfica
kicker: Validación técnica
clasificacion: INTERNO
estado: Borrador
autor: Equipo de datos
---

## Serie temporal

| Mes | Retiros | Alertas |
|---|---|---|
| 2026-01 | 1.240 | 86 |
| 2026-02 | 1.310 | 94 |
| 2026-03 | 1.520 | 131 |
| 2026-04 | 1.410 | 118 |
| 2026-05 | 1.680 | 152 |
| 2026-06 | 1.905 | 173 |

## Comparación por categoría

| Fondo | Monto retirado |
|---|---|
| FDO-LIQUIDEZ | 2.340.000.000 |
| FDO-RENTA FIJA | 1.120.000.000 |
| FDO-ACCIONES | 780.000.000 |
| FDO-BALANCEADO | 410.000.000 |

## Participación sobre el total

| Canal | Participación |
|---|---|
| App móvil | 54% |
| Portal web | 31% |
| Oficina | 15% |

## Estados antes y después

| Regla | Estado original | Estado actual |
|---|---|---|
| Login | Activa | Desactivada |
| Cuenta registrada | Activa | Activa |
| Fecha de registro | Activa | Desactivada |
| Monto atípico | Activa | Desactivada |
| Horario | Activa | Desactivada |

## Series múltiples

| Producto | Aprobadas | Escaladas |
|---|---|---|
| FIC | 820 | 143 |
| FVP | 460 | 87 |
