# Sistema de diseño

Identidad visual del reporte. Todo vive en `assets/theme.css`; se puede sustituir con
`--css` sin tocar los scripts.

## Paleta

| Variable | Hex | Uso |
|---|---|---|
| `--btg-navy` | `#05132A` | Encabezados de tabla, caja de hallazgo, títulos |
| `--btg-blue` | `#195AB4` | Color de acento: numeración, bordes, barras |
| `--btg-blue-light` | `#6FA0E0` | Etiquetas sobre fondo navy |
| `--btg-blue-pale` | `#EEF3F9` | Fondo de cajas informativas y etiquetas de ficha |
| `--btg-blue-row` | `#F4F7FB` | Filas alternadas |
| `--btg-red` | `#B3261E` | Clasificación, estados negativos, marca de PII |
| `--btg-green` | `#1E7B34` | Estados positivos |
| `--btg-amber` | `#C79A1E` | Advertencias y salvedades |

El azul se usa con moderación: fondo blanco, acentos azules. Evita bloques grandes de
color salvo la caja de hallazgo y los encabezados de tabla.

## Tipografía

Segoe UI en Windows, con Liberation Sans y Arial como respaldo. Cuerpo a 10 pt,
interlineado 1,5. Títulos de sección a 13,5 pt; subsecciones a 10,5 pt.

## Página

Tamaño Carta. Márgenes de 22 mm arriba, 17 mm a los lados y 18 mm abajo. La portada
va a sangre completa, sin márgenes ni encabezado.

Encabezado de páginas interiores: el campo `encabezado` del frontmatter, centrado.
Pie: "BTG Pactual — Confidencial" a la izquierda y "Página X de Y" a la derecha.
La portada no se numera, siguiendo la convención habitual de documentos corporativos.

## Componentes

| Clase | Aspecto |
|---|---|
| `.cover` | Portada: logo, clasificación, título, ficha de metadatos |
| `h1.section-title` | Título con número azul y subrayado azul |
| `table.data-table` | Ficha de dos columnas con etiquetas grises |
| `table.matrix-table` | Tabla de catálogo con filas alternadas |
| `table.compare-table` | Tres columnas con fondo verde/rojo suave |
| `.status-badge` | Píldora de estado en verde, rojo, azul o ámbar |
| `.rootcause-box` | Caja navy para el hallazgo principal |
| `.note-box` | Caja azul de contexto |
| `.caveat-box` | Caja ámbar de salvedad |
| `ol.timeline` | Lista con círculos azules conectados |
| `ol.actions` | Lista con círculos de contorno, sin conector |
| `.evidence-block` | Imagen enmarcada con pie y etiqueta opcional de PII |
| `.chart-block` | Gráfica enmarcada con título y pie |
| `.pii-tag` | Etiqueta roja "CONTIENE DATOS PERSONALES" |

Todos los bloques llevan `break-inside: avoid`, así que una tabla, una gráfica o una
caja nunca se parte entre dos páginas.

## Logo

`assets/btg-logo.png`, incrustado como data-URI para que el PDF sea autocontenido.
Se puede reemplazar con `--logo`. Si el archivo no existe, se dibuja un respaldo
tipográfico "btg pactual".

## Motor de renderizado

Chromium, en cascada:

1. **Playwright** con chromium descargado, o con el canal `msedge` / `chrome` del
   sistema. Da encabezado y pie nativos con numeración de páginas.
2. **Subproceso** a Chrome o Edge con `--headless --print-to-pdf`. No requiere ningún
   paquete de Python; el PDF sale sin numeración.

Cuando hay encabezado, el documento se renderiza en dos pasadas (portada y cuerpo) y
se unen con `pypdf`, para que la portada quede limpia. Si `pypdf` no está instalado,
se hace una sola pasada y el encabezado aparece también sobre la portada.
