# Formato del insumo Markdown

Todo lo que el generador entiende. Lo que no esté aquí se trata como párrafo normal.

## Frontmatter

Bloque `clave: valor` entre `---` al inicio del archivo. Todos los campos son
opcionales salvo `titulo`.

| Campo | Uso |
|---|---|
| `titulo` | Título grande de la portada |
| `kicker` | Línea azul en mayúsculas sobre el título |
| `subtitulo` | Párrafo de alcance bajo el título |
| `clasificacion` | Etiqueta roja de la portada (ej. `CONFIDENCIAL`, `INTERNO`) |
| `clasificacion_larga` | Texto de la fila "Clasificación" en la ficha |
| `estado` | Ej. `Definitivo`, `Vigente`, `Borrador` |
| `autor` | Nombre y cargo |
| `destinatario` | Equipo o área receptora |
| `fecha_evento` | Fecha del hecho analizado |
| `fecha_emision` | Fecha de emisión del documento |
| `encabezado` | Texto del encabezado de páginas interiores |
| `nota_portada` | Texto legal al pie de la portada |
| `nota_cierre` | Texto legal al final del documento |

## Estructura

```markdown
## Sección          → sección numerada automáticamente (1., 2., 3.)
### Subsección      → subsección numerada (1.1, 1.2)
```

La numeración es automática. Si escribes `## 4. Estado actual`, el `4.` manual se
elimina y se renumera solo. El `#` de nivel 1 se ignora: el título va en el frontmatter.

## Cajas destacadas

```markdown
> [!CLAVE] El hallazgo principal del documento.
> [!ALERTA] Una advertencia o salvedad sobre el alcance del análisis.
> [!NOTA] Una aclaración de contexto.
> Una cita sin etiqueta se trata como NOTA.
```

- `CLAVE` (o `HALLAZGO`) → caja navy con título "Hallazgo clave". Úsala una sola vez
  por documento, para el mensaje que la persona debe recordar.
- `ALERTA` → caja ámbar. Para salvedades, limitaciones y supuestos por confirmar.
- `NOTA` → caja azul. Para contexto secundario.

## Tablas

Tablas GFM estándar. El tipo visual se elige solo:

- **Dos columnas** con encabezado `Campo`, `Aspecto`, `Concepto` o vacío → ficha con
  etiquetas en la columna izquierda.
- **Tres columnas** cuyos encabezados incluyan *esperado/observado*, *antes/después* u
  *original/actual* → tabla comparativa con fondo verde y rojo suaves.
- **Resto** → tabla matriz con filas alternadas.

Para forzar un tipo, pon el comentario justo antes de la tabla:

```markdown
<!-- tabla: data -->
<!-- tabla: compare -->
<!-- tabla: matrix -->
```

### Badges de estado

Las celdas cuyo contenido sea `Activa`, `Desactivada`, `Vigente`, `Pendiente`, `Sí`,
`No`, `✅`, `❌` y similares se convierten en badges de color. Un paréntesis después
del estado se conserva como aclaración en gris:

```markdown
| Cuenta registrada | ✅ Activa (única regla en ejecución) |
```

## Listas

```markdown
- Viñeta simple

1. Paso numerado    → línea de tiempo con círculos azules

<!-- lista: acciones -->
1. Acción propuesta → círculos con contorno, sin línea conectora
```

## Imágenes y evidencia

```markdown
![Pie explicativo de la captura](ruta/captura.png)
![[PII] Consulta que expone datos del cliente](ruta/captura.png)
```

La imagen se enmarca y el pie va debajo con una barra lateral. El prefijo `[PII]`
agrega la etiqueta roja "CONTIENE DATOS PERSONALES" sobre la imagen.

Las rutas se resuelven relativas al archivo Markdown. Las imágenes se incrustan en el
PDF, así que el archivo final es autocontenido.

## Marcadores de control

```markdown
<!-- salto-pagina -->        → fuerza el inicio de una página nueva
<!-- grafica: g2_estados -->  → coloca aquí la gráfica con ese id
```

Por defecto cada gráfica se ancla justo después de la tabla que la originó. Usa
`<!-- grafica: id -->` solo si quieres moverla a otro punto del documento; en ese caso
combínalo con `"after_block": null` en el JSON de gráficas.

## Formato en línea

`**negrita**`, `*cursiva*`, `` `código` ``, `[enlace](url)`. Las flechas `->` se
convierten en `→`.
