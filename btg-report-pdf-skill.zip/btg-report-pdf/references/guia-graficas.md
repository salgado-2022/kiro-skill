# Guía de gráficas

Cómo el analizador elige, y cómo decidir si tenía razón.

## Cómo clasifica las columnas

Cada columna se clasifica antes de decidir nada:

| Clase | Cómo se detecta |
|---|---|
| **temporal** | `2026-01`, `2026-06-04`, `04/06/2026`, `2026`, `Q1`, `Ene`, `Mes 3` |
| **numérica** | Números con formato colombiano (`1.234.567,89`), `%`, `COP`, `$` |
| **estado** | `Activa`, `Desactivada`, `Vigente`, `Pendiente`, `Sí`, `No`, `✅`, `❌` |
| **índice** | Encabezado `#`, `id`, `no.` o secuencia consecutiva 1,2,3… |
| **texto** | Todo lo demás |

Las columnas **índice se excluyen** como medida: numerar reglas del 1 al 5 no es un
dato graficable. Este es el error más común al graficar tablas automáticamente.

## Árbol de decisión

```
¿Hay columna temporal + numérica?
├── sí, ≥4 puntos      → LÍNEA          (la tendencia es el mensaje)
├── sí, <4 puntos      → BARRAS         (con 3 puntos una línea sugiere una tendencia que no existe)
└── no
    ├── ¿Columnas de estado?
    │   ├── 2 o más    → COMPARATIVO    (antes vs. después, con verde/rojo semántico)
    │   └── 1          → ANILLO         (proporción del estado actual)
    └── ¿Categoría + numérica?
        ├── suma ≈100% o encabezado dice "participación" → ANILLO
        ├── 2+ series numéricas, ≤8 filas                → BARRAS AGRUPADAS
        ├── >10 filas o etiquetas largas (>22 car.)      → BARRAS HORIZONTALES
        └── resto                                         → BARRAS VERTICALES
```

## Cuándo descartar la gráfica propuesta

El analizador propone; el criterio es tuyo. Pon `"enabled": false` cuando:

- **La tabla tiene 2 o 3 filas.** Se lee más rápido en la tabla. Una gráfica de dos
  barras ocupa media página para decir lo que dice una frase.
- **La gráfica solo repite la tabla contigua** sin agregar una comparación, una
  proporción o una tendencia. Duplicar información cansa al lector.
- **Los valores no son comparables entre sí** (mezclan unidades, o son categorías que
  no compiten por un mismo total).
- **El documento ya tiene 3 o 4 gráficas.** Más de eso diluye el mensaje en un informe
  ejecutivo de pocas páginas.

Regla práctica: una gráfica se gana su espacio si el lector entiende algo **de un
vistazo** que la tabla le tomaría treinta segundos.

## Cuándo cambiar el tipo

- **Anillo → barras horizontales** si hay más de 6 categorías. Los sectores pequeños
  se vuelven indistinguibles.
- **Barras → línea** solo si el eje es realmente continuo. Categorías sin orden natural
  (fondos, canales, productos) nunca van en línea.
- **Barras agrupadas → dos gráficas separadas** si las series tienen escalas muy
  distintas (ej. 2.000 millones vs. 15 alertas): la serie pequeña desaparece.
- **Comparativo de estados → anillo** si solo interesa la foto actual y no el cambio.

## Paleta

Las gráficas usan la paleta institucional automáticamente:

| Uso | Color |
|---|---|
| Serie principal | Azul `#195AB4` |
| Serie secundaria | Navy `#05132A` |
| Serie terciaria | Azul claro `#6FA0E0` |
| Estado activo / positivo | Verde `#1E7B34` |
| Estado inactivo / negativo | Rojo `#B3261E` |
| Advertencia | Ámbar `#C79A1E` |

Verde y rojo se aplican **solo** a estados, nunca como colores de serie arbitrarios,
para que el lector pueda confiar en que el color significa algo.

## Estructura del JSON de propuestas

```json
{
  "id": "g2_estados",
  "chart": "status_bar",
  "title": "Comparativo de estado original y estado actual",
  "caption": "Escríbelo tú, en lenguaje de negocio.",
  "table_index": 2,
  "label_col": 0,
  "value_cols": [1, 2],
  "after_block": 24,
  "confidence": 0.85,
  "rationale": "Explicación de por qué se eligió este tipo.",
  "enabled": true
}
```

Campos editables sin riesgo: `chart`, `title`, `caption`, `enabled`.
`table_index`, `label_col` y `value_cols` apuntan a la tabla y sus columnas; cámbialos
solo si quieres graficar otras columnas de la misma tabla.

Tipos válidos en `chart`: `line`, `bar`, `barh`, `grouped_bar`, `donut`, `status_bar`.

## Formato numérico

Las etiquetas siguen convención colombiana: punto para miles, coma para decimales.
Los montos grandes se abrevian: `780 M` (millones), `2,34 MM` (miles de millones).
