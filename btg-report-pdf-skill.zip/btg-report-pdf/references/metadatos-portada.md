# Metadatos de portada

El frontmatter es opcional. Cuando falta, cada campo se resuelve por esta cadena:

**frontmatter → argumento de línea de comandos → deducción del documento → valor por
defecto → se omite de la portada**

La portada solo muestra las filas que tienen valor, así que un documento sin autor ni
destinatario produce una ficha de cuatro campos, no una con huecos.

## Qué se deduce y de dónde

| Campo | Cómo se deduce | Si no se encuentra |
|---|---|---|
| `titulo` | Primer `#` del documento; si no hay, el nombre del archivo | Nombre del archivo |
| `subtitulo` | Texto anterior a la primera `##` (preámbulo), recortado a ~280 caracteres en fin de oración | Se omite |
| `kicker` | Tipo de documento detectado + código encontrado (ej. `INC-2026-06-04`, `AtlasCore V2`) | `Documento interno` |
| `estado` | Línea `Estado: ...` si el valor es uno conocido | `Definitivo` |
| `clasificacion` | `INTERNO` si el texto dice "uso interno" | `CONFIDENCIAL` |
| `clasificacion_larga` | Línea `Clasificación: ...` | `<tipo de documento> / información sensible` |
| `fecha_evento` | Línea `Fecha del evento / del incidente / de corte`, o la primera fecha del texto | Se omite |
| `fecha_emision` | — | Fecha de hoy |
| `encabezado` | Título recortado, con el código adelante si no está ya en el título | Título recortado |
| `autor` | Línea `Elaborado por / Autor / Preparado por / Responsable` | **Se omite** |
| `destinatario` | Línea `Destinatario / Dirigido a` | **Se omite** |

El preámbulo usado como subtítulo se **consume**: no vuelve a aparecer en el cuerpo, así
que no hay texto duplicado entre la portada y la primera página.

## Campos que nunca se inventan

`autor` y `destinatario` son datos de gestión, no de contenido. Poner un nombre
equivocado en un documento que va a circular es peor que dejar el campo vacío, así que
la skill los omite y los reporta como faltantes.

Complételos sin tocar el Markdown:

```bash
python scripts/build_report.py construir informe.md -o informe.pdf \
  --autor "Juan Salgado González — Analista de TI, BTG Pactual Colombia" \
  --destinatario "Equipo de Fraude / Seguridad"
```

## Detección del tipo de documento

Se elige por puntaje: cada patrón suma puntos según cuántas veces aparece, y las
coincidencias en el título pesan el triple que las del cuerpo.

| Tipo | Se activa con |
|---|---|
| Informe de incidente | incidente, siniestro, reportado como fraude, caso de fraude |
| Informe de auditoría | auditoría, hallazgo de control, papel de trabajo |
| Análisis de causa raíz | causa raíz, postmortem |
| Documento de negocio | reglas de negocio, catálogo de reglas, validaciones de negocio, lógica de decisión |
| Documento de análisis | análisis, diagnóstico, evaluación de |
| Documento de propuesta | propuesta, recomendación, plan de acción |
| Documento de procedimiento | procedimiento, instructivo, manual de |

Los patrones son deliberadamente estrictos. Mencionar "antifraude" no convierte un
catálogo de reglas en un informe de incidente: hace falta hablar de un incidente
concreto.

## Códigos detectados

Se busca, en este orden, el primero que aparezca:

1. `INC-2026-06-04` — prefijo de 2 a 5 letras mayúsculas + fecha
2. `TCK-12345` — prefijo + número
3. `AtlasCore V2` — nombre en CamelCase + versión

El código encontrado se usa en el kicker y en el encabezado de las páginas interiores.

## Revisión obligatoria

Ejecute siempre `analizar` antes de `construir` y lea el informe de metadatos. Marca el
origen de cada campo:

```
  [decl]     titulo               Reglas de negocio y validaciones — AtlasCore V2
  [inferido] kicker               Documento de negocio · AtlasCore V2
  [defecto]  clasificacion        CONFIDENCIAL

  Sin dato (se omiten de la portada): autor, destinatario
```

Un campo `[inferido]` es una suposición razonable, no un hecho verificado. Confírmelos
con la persona antes de entregar el documento.
