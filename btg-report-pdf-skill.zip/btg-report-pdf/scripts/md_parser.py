"""
Parser de Markdown → bloques estructurados para reportería BTG Pactual.

Sin dependencias externas: solo biblioteca estándar de Python.

Soporta:
  - Frontmatter simple (clave: valor) delimitado por ---
  - ## Sección          → sección numerada automáticamente
  - ### Subsección      → subsección numerada (X.Y)
  - Tablas GFM          → data-table / matrix-table / compare-table
  - Listas - y 1.       → lista simple / línea de tiempo
  - > [!CLAVE] ...      → caja de hallazgo (navy)
  - > [!ALERTA] ...     → caja de advertencia (ámbar)
  - > [!NOTA] ... o >   → caja informativa (azul)
  - ![pie](ruta.png)    → bloque de evidencia con pie de foto
  - <!-- grafica: id --> → marcador de posición de gráfica
  - <!-- salto-pagina -->→ salto de página forzado
  - Inline: **negrita**, *cursiva*, `código`
"""

import html
import os
import re

# --------------------------------------------------------------------------
# Frontmatter
# --------------------------------------------------------------------------

def parse_frontmatter(text):
    """Extrae el frontmatter (clave: valor) y devuelve (meta, cuerpo)."""
    meta = {}
    if not text.startswith("---"):
        return meta, text

    lines = text.split("\n")
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() in ("---", "..."):
            end = i
            break
    if end is None:
        return meta, text

    for raw in lines[1:end]:
        raw = raw.strip()
        if not raw or raw.startswith("#") or ":" not in raw:
            continue
        key, _, value = raw.partition(":")
        value = value.strip().strip('"').strip("'")
        meta[key.strip().lower()] = value

    return meta, "\n".join(lines[end + 1:])


# --------------------------------------------------------------------------
# Formato inline
# --------------------------------------------------------------------------

_STATUS_VOCAB = {
    "activa": "active", "activo": "active", "sí": "active", "si": "active",
    "vigente": "active", "ok": "active", "cumple": "active", "aprobado": "active",
    "desactivada": "inactive", "desactivado": "inactive", "inactiva": "inactive",
    "inactivo": "inactive", "no": "inactive", "falla": "inactive",
    "fallido": "inactive", "rechazado": "inactive", "no cumple": "inactive",
    "pendiente": "warning", "parcial": "warning", "en revisión": "warning",
    "en revision": "warning", "advertencia": "warning",
}


def inline(text):
    """Convierte formato inline de Markdown a HTML, escapando lo demás."""
    if text is None:
        return ""

    # Proteger `código` antes de escapar
    codes = []

    def _stash_code(m):
        codes.append(m.group(1))
        return "\x00CODE%d\x00" % (len(codes) - 1)

    text = re.sub(r"`([^`]+)`", _stash_code, text)
    text = html.escape(text, quote=False)

    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"(?<!\*)\*([^*]+?)\*(?!\*)", r"<em>\1</em>", text)

    # Enlaces [texto](url)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)

    for i, c in enumerate(codes):
        text = text.replace(
            "\x00CODE%d\x00" % i, "<code>%s</code>" % html.escape(c, quote=False)
        )

    # Flechas tipográficas
    text = text.replace("-&gt;", "→").replace("--&gt;", "→")

    # Emojis de estado seguidos de su etiqueta → badge corporativo
    text = re.sub(
        r"[✅✓]\s*(<strong>)?\s*(Activ[ao]s?|Vigente|Sí|Si)(</strong>)?",
        r'<span class="status-badge active">\2</span>', text, flags=re.IGNORECASE)
    text = re.sub(
        r"[❌✗]\s*(<strong>)?\s*(Desactivad[ao]s?|Inactiv[ao]s?|No)(</strong>)?",
        r'<span class="status-badge inactive">\2</span>', text, flags=re.IGNORECASE)
    # Emojis sueltos sin etiqueta
    text = re.sub(r"[✅✓](?!\w)", '<span class="status-badge active">Sí</span>', text)
    text = re.sub(r"[❌✗](?!\w)", '<span class="status-badge inactive">No</span>', text)
    return text


def status_class(value):
    """Devuelve la clase de badge si el valor corresponde a un estado conocido."""
    clean = re.sub(r"[*_`✅❌⚠️✓✗]", "", str(value)).strip().lower()
    clean = re.sub(r"\s*\(.*?\)\s*", "", clean).strip()
    if "✅" in str(value) or "✓" in str(value):
        return "active", clean.upper() or "ACTIVA"
    if "❌" in str(value) or "✗" in str(value):
        return "inactive", clean.upper() or "DESACTIVADA"
    if clean in _STATUS_VOCAB:
        return _STATUS_VOCAB[clean], clean.upper()
    return None, None


# --------------------------------------------------------------------------
# Tablas
# --------------------------------------------------------------------------

def _split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def _is_separator(line):
    """Fila separadora de encabezado. Tolera celdas decorativas (ej. |---|✅ / ❌|)."""
    if "|" not in line or "--" not in line:
        return False
    cells = _split_row(line)
    if not cells:
        return False
    # Al menos una celda debe ser puramente guiones/dos puntos
    return any(re.fullmatch(r"\s*:?-{2,}:?\s*", c) for c in cells)


# --------------------------------------------------------------------------
# Parser principal
# --------------------------------------------------------------------------

def parse(text, base_dir="."):
    """Convierte el Markdown en una lista de bloques estructurados."""
    meta, body = parse_frontmatter(text)
    lines = body.split("\n")
    blocks = []
    i = 0
    hint = None  # pista del comentario HTML previo

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # --- líneas vacías ---
        if not stripped:
            i += 1
            continue

        # --- comentarios de control ---
        m = re.match(r"^<!--\s*(.*?)\s*-->$", stripped)
        if m:
            directive = m.group(1).strip()
            low = directive.lower()
            if low in ("salto-pagina", "salto-página", "page-break"):
                blocks.append({"type": "page_break"})
            elif low.startswith("grafica:") or low.startswith("gráfica:") or low.startswith("chart:"):
                blocks.append({"type": "chart_ref", "id": directive.split(":", 1)[1].strip()})
            elif low.startswith("tabla:") or low.startswith("table:"):
                hint = directive.split(":", 1)[1].strip().lower()
            elif low.startswith("lista:") or low.startswith("list:"):
                hint = directive.split(":", 1)[1].strip().lower()
            elif low.startswith("titulo-grafica:"):
                hint = "chart_title=" + directive.split(":", 1)[1].strip()
            i += 1
            continue

        # --- separador horizontal ---
        if re.match(r"^\s*(\*\s*){3,}$|^\s*(-\s*){3,}$|^\s*(_\s*){3,}$", line):
            i += 1
            continue

        # --- encabezados ---
        if stripped.startswith("#"):
            level = len(stripped) - len(stripped.lstrip("#"))
            title = stripped.lstrip("#").strip()
            title = re.sub(r"^\d+(\.\d+)*[\.\)]?\s+", "", title)  # quitar numeración manual
            if level == 1:
                blocks.append({"type": "doc_title", "text": title})
            elif level == 2:
                blocks.append({"type": "section", "text": title})
            else:
                blocks.append({"type": "subsection", "text": title})
            i += 1
            continue

        # --- citas / cajas ---
        if stripped.startswith(">"):
            quote_lines = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote_lines.append(re.sub(r"^\s*>\s?", "", lines[i]))
                i += 1
            content = " ".join(l.strip() for l in quote_lines if l.strip())

            kind = "note"
            m = re.match(r"^\[!(\w+)\]\s*(.*)$", content, re.IGNORECASE | re.DOTALL)
            label = None
            if m:
                tag = m.group(1).upper()
                content = m.group(2).strip()
                if tag in ("CLAVE", "KEY", "HALLAZGO", "IMPORTANT"):
                    kind = "key"
                    label = "Hallazgo clave"
                elif tag in ("ALERTA", "WARNING", "CAUTION", "ADVERTENCIA"):
                    kind = "caveat"
                elif tag in ("NOTA", "NOTE", "INFO"):
                    kind = "note"
            blocks.append({"type": "callout", "kind": kind, "text": content, "label": label})
            continue

        # --- tablas ---
        if "|" in stripped and i + 1 < len(lines) and _is_separator(lines[i + 1]):
            headers = _split_row(lines[i])
            i += 2
            rows = []
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(_split_row(lines[i]))
                i += 1
            width = len(headers)
            rows = [r + [""] * (width - len(r)) if len(r) < width else r[:width] for r in rows]
            blocks.append({
                "type": "table",
                "headers": headers,
                "rows": rows,
                "hint": hint if hint in ("data", "matrix", "compare", "plain") else None,
            })
            hint = None
            continue

        # --- imágenes ---
        m = re.match(r"^!\[(.*?)\]\((.+?)\)\s*$", stripped)
        if m:
            caption, path = m.group(1), m.group(2).strip()
            pii = False
            if caption.upper().startswith("[PII]"):
                pii = True
                caption = caption[5:].strip()
            blocks.append({
                "type": "image",
                "caption": caption,
                "path": path,
                "abs_path": os.path.join(base_dir, path) if not os.path.isabs(path) else path,
                "pii": pii,
            })
            i += 1
            continue

        # --- listas ordenadas ---
        if re.match(r"^\s*\d+[\.\)]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+[\.\)]\s+", lines[i]):
                items.append(re.sub(r"^\s*\d+[\.\)]\s+", "", lines[i]).strip())
                i += 1
                # continuación indentada
                while i < len(lines) and lines[i].startswith(("   ", "\t")) and lines[i].strip():
                    items[-1] += " " + lines[i].strip()
                    i += 1
            style = "actions" if hint == "acciones" else "timeline"
            blocks.append({"type": "ordered_list", "items": items, "style": style})
            hint = None
            continue

        # --- listas simples ---
        if re.match(r"^\s*[-*+]\s+", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-*+]\s+", lines[i]):
                items.append(re.sub(r"^\s*[-*+]\s+", "", lines[i]).strip())
                i += 1
                while i < len(lines) and lines[i].startswith(("   ", "\t")) and lines[i].strip():
                    items[-1] += " " + lines[i].strip()
                    i += 1
            blocks.append({"type": "list", "items": items})
            continue

        # --- párrafo ---
        para = []
        while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith(
            ("#", ">", "-", "*", "!", "<!--")
        ) and not re.match(r"^\s*\d+[\.\)]\s+", lines[i]) and "|" not in lines[i]:
            para.append(lines[i].strip())
            i += 1
        if para:
            blocks.append({"type": "paragraph", "text": " ".join(para)})
        else:
            i += 1

    return meta, blocks


def load(path):
    """Carga y parsea un archivo Markdown."""
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    return parse(text, base_dir=os.path.dirname(os.path.abspath(path)))
