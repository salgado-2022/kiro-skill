"""
Renderizado de HTML a PDF usando Chromium.

Estrategia en cascada, pensada para entornos corporativos restringidos:

  1. Playwright con el navegador que esté disponible:
       - chromium descargado por Playwright
       - canal 'msedge' (Edge ya viene instalado en Windows corporativo)
       - canal 'chrome'
     Da encabezado y pie nativos con numeración "Página X de Y".

  2. Subproceso directo a Chrome/Edge con --headless --print-to-pdf.
     No requiere ningún paquete de Python; se apoya en el navegador ya
     instalado en la máquina. Sin numeración de páginas.

Instalación mínima:
    pip install playwright
    playwright install chromium      # opcional si ya hay Edge/Chrome
"""

import os
import shutil
import subprocess
import sys
import tempfile

HEADER_TEMPLATE = """
<div style="width:100%; font-size:7.5pt; color:#7C8895;
            font-family:'Segoe UI',Arial,sans-serif; padding:0 17mm;
            -webkit-print-color-adjust:exact;">
  <div style="text-align:center;">__TITLE__</div>
</div>
"""

FOOTER_TEMPLATE = """
<div style="width:100%; font-size:7.5pt; color:#7C8895;
            font-family:'Segoe UI',Arial,sans-serif; padding:0 17mm;
            -webkit-print-color-adjust:exact;">
  <span style="float:left;">__FOOTER_LEFT__</span>
  <span style="float:right;">Página <span class="pageNumber"></span>
        de <span class="totalPages"></span></span>
</div>
"""

BROWSER_CANDIDATES = [
    # Windows
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    # macOS
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
]

BROWSER_COMMANDS = ["chromium", "chromium-browser", "google-chrome",
                    "google-chrome-stable", "microsoft-edge", "msedge"]


def find_browser():
    """Localiza un binario de Chromium/Chrome/Edge en el sistema."""
    for cmd in BROWSER_COMMANDS:
        path = shutil.which(cmd)
        if path:
            return path
    for path in BROWSER_CANDIDATES:
        if os.path.exists(path):
            return path
    return None


def render_with_playwright(html_path, pdf_path, header_title="", footer_left="",
                           headers=True, channel=None):
    """Renderiza con Playwright. Devuelve True si tuvo éxito."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return False, "playwright no está instalado"

    channels = [channel] if channel else [None, "msedge", "chrome"]
    last_error = None

    for ch in channels:
        try:
            with sync_playwright() as p:
                launch_args = {"args": ["--no-sandbox", "--disable-dev-shm-usage"]}
                if ch:
                    launch_args["channel"] = ch
                browser = p.chromium.launch(**launch_args)
                page = browser.new_page()
                page.goto("file://" + os.path.abspath(html_path),
                          wait_until="networkidle")
                page.emulate_media(media="print")

                options = {
                    "path": pdf_path,
                    "format": "Letter",
                    "print_background": True,
                    "prefer_css_page_size": True,
                }
                if headers:
                    options.update({
                        "display_header_footer": True,
                        "header_template": HEADER_TEMPLATE.replace("__TITLE__", header_title),
                        "footer_template": FOOTER_TEMPLATE.replace("__FOOTER_LEFT__", footer_left),
                    })
                page.pdf(**options)
                browser.close()
                return True, "playwright" + (":" + ch if ch else ":chromium")
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc).split("\n")[0]
            continue

    return False, last_error or "no se pudo iniciar ningún navegador"


def render_with_subprocess(html_path, pdf_path, browser=None):
    """Renderiza invocando Chrome/Edge directamente. Sin numeración de páginas."""
    browser = browser or find_browser()
    if not browser:
        return False, "no se encontró Chrome/Edge/Chromium en el sistema"

    profile = tempfile.mkdtemp(prefix="btg-report-")
    cmd = [
        browser,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--no-pdf-header-footer",
        "--user-data-dir=" + profile,
        "--print-to-pdf=" + os.path.abspath(pdf_path),
        "file://" + os.path.abspath(html_path),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=120)
        if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 1000:
            return True, "subproceso:" + os.path.basename(browser)
        return False, (proc.stderr.decode("utf-8", "ignore")[:200] or "el navegador no generó el PDF")
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
    finally:
        shutil.rmtree(profile, ignore_errors=True)


def _merge_cover(cover_pdf, body_pdf, out_pdf):
    """Une portada (sin encabezado) y cuerpo (con encabezado) en un solo PDF."""
    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        return False

    writer = PdfWriter()
    cover = PdfReader(cover_pdf)
    if not cover.pages:
        return False
    writer.add_page(cover.pages[0])
    for page in PdfReader(body_pdf).pages:
        writer.add_page(page)
    with open(out_pdf, "wb") as fh:
        writer.write(fh)
    return True


def _split_html(html_content):
    """Separa el HTML en (portada sola, cuerpo sin portada)."""
    start = html_content.find('<section class="cover"')
    if start == -1:
        return None, None
    end = html_content.find("</section>", start)
    if end == -1:
        return None, None
    end += len("</section>")

    cover_section = html_content[start:end]
    head = html_content[:start]
    tail = html_content[end:]

    cover_html = head + cover_section + "\n</body>\n</html>\n"
    body_html = head + tail
    return cover_html, body_html


def render(html_content, pdf_path, header_title="", footer_left="BTG Pactual — Confidencial",
           headers=True, channel=None, keep_html=None):
    """Escribe el HTML y lo convierte a PDF con el mejor motor disponible.

    Cuando hay encabezado/pie, se renderiza en dos pasadas (portada y cuerpo)
    para que la portada quede limpia, y se unen con pypdf. Si pypdf no está
    disponible, se hace una sola pasada.
    """
    tmp_dir = tempfile.mkdtemp(prefix="btg-html-")
    try:
        if keep_html:
            with open(keep_html, "w", encoding="utf-8") as fh:
                fh.write(html_content)

        html_path = os.path.join(tmp_dir, "report.html")
        with open(html_path, "w", encoding="utf-8") as fh:
            fh.write(html_content)

        # --- Dos pasadas: portada limpia + cuerpo con encabezado ---
        if headers:
            cover_html, body_html = _split_html(html_content)
            if cover_html and body_html:
                cover_path = os.path.join(tmp_dir, "cover.html")
                body_path = os.path.join(tmp_dir, "body.html")
                cover_pdf = os.path.join(tmp_dir, "cover.pdf")
                body_pdf = os.path.join(tmp_dir, "body.pdf")
                with open(cover_path, "w", encoding="utf-8") as fh:
                    fh.write(cover_html)
                with open(body_path, "w", encoding="utf-8") as fh:
                    fh.write(body_html)

                ok_c, eng = render_with_playwright(
                    cover_path, cover_pdf, headers=False, channel=channel)
                ok_b, eng = render_with_playwright(
                    body_path, body_pdf, header_title, footer_left, True, channel)
                if ok_c and ok_b and _merge_cover(cover_pdf, body_pdf, pdf_path):
                    return eng + "+portada-separada"

        # --- Una sola pasada ---
        ok, engine = render_with_playwright(
            html_path, pdf_path, header_title, footer_left, headers, channel)
        if ok:
            return engine

        print("  · Playwright no disponible (%s); intentando con el navegador del sistema"
              % engine, file=sys.stderr)

        ok, engine = render_with_subprocess(html_path, pdf_path)
        if ok:
            return engine

        raise RuntimeError(
            "No se pudo generar el PDF: %s.\n"
            "Instale Playwright con 'pip install playwright' y luego\n"
            "'playwright install chromium', o asegúrese de tener Edge/Chrome instalado."
            % engine
        )
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
