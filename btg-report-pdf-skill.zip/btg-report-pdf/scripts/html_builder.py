"""
Construcción del HTML del reporte con el sistema de diseño BTG Pactual.
Sin dependencias externas.
"""

import base64
import html
import mimetypes
import os
import re

from md_parser import inline, status_class

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")


def _data_uri(path):
    """Incrusta un archivo como data-URI para que el PDF sea autocontenido."""
    if not path or not os.path.exists(path):
        return None
    mime, _ = mimetypes.guess_type(path)
    mime = mime or "image/png"
    with open(path, "rb") as fh:
        return "data:%s;base64,%s" % (mime, base64.b64encode(fh.read()).decode("ascii"))


# --------------------------------------------------------------------------
# Portada
# --------------------------------------------------------------------------

def build_cover(meta, logo_path):
    logo = _data_uri(logo_path)
    logo_html = ('<img class="cover-logo" src="%s" alt="BTG Pactual">' % logo
                 if logo else '<div style="font-size:18pt;font-weight:700;color:#05132A;">'
                              'btg<span style="font-weight:400;">pactual</span></div>')

    rows = []
    pairs = [
        ("Estado", meta.get("estado")),
        ("Fecha del evento", meta.get("fecha_evento")),
        ("Clasificación", meta.get("clasificacion_larga") or meta.get("clasificacion")),
        ("Fecha de emisión", meta.get("fecha_emision")),
        ("Elaborado por", meta.get("autor")),
        ("Destinatario", meta.get("destinatario")),
    ]
    pairs = [(k, v) for k, v in pairs if v]
    for i in range(0, len(pairs), 2):
        chunk = pairs[i:i + 2]
        cells = ""
        for label, value in chunk:
            cells += '<td class="label">%s</td><td>%s</td>' % (
                html.escape(label), inline(value))
        if len(chunk) == 1:
            cells += "<td></td><td></td>"
        rows.append("<tr>%s</tr>" % cells)

    meta_table = ('<table class="cover-meta-table">%s</table>' % "".join(rows)) if rows else ""

    classification = meta.get("clasificacion", "CONFIDENCIAL")
    kicker = meta.get("kicker", "")
    subtitle = meta.get("subtitulo", "")
    note = meta.get("nota_portada",
                    "Este documento contiene información sensible. Su distribución debe "
                    "limitarse al personal autorizado.")

    return """
<section class="cover">
  <div class="cover-accent-ring"></div>
  <div class="cover-topbar"></div>
  <div class="cover-bottombar"></div>
  <div class="cover-brand-row">%s</div>
  %s
  <div class="cover-divider"></div>
  <div class="cover-title-block">
    %s
    <div class="cover-title">%s</div>
    %s
  </div>
  <div class="cover-meta">%s</div>
  <div class="cover-footer-note">%s</div>
</section>
""" % (
        logo_html,
        ('<div class="cover-classification">%s</div>' % html.escape(classification)
         if classification else ""),
        ('<div class="cover-kicker">%s</div>' % inline(kicker)) if kicker else "",
        inline(meta.get("titulo", "Informe")),
        ('<div class="cover-subtitle">%s</div>' % inline(subtitle)) if subtitle else "",
        meta_table,
        inline(note),
    )


# --------------------------------------------------------------------------
# Tablas
# --------------------------------------------------------------------------

def _looks_like_field_table(headers, rows):
    """Tabla de dos columnas tipo ficha (Campo | Valor)."""
    if len(headers) != 2:
        return False
    h0 = (headers[0] or "").strip().lower()
    return h0 in ("campo", "aspecto", "concepto", "detalle", "ítem", "item", "")


def _cell_html(value, allow_badge=True):
    text = str(value or "").strip()
    if allow_badge:
        cls, label = status_class(text)
        if cls and label:
            extra = re.search(r"\((.*?)\)", text)
            suffix = (' <span style="font-size:7.6pt;color:#5A6472;">(%s)</span>'
                      % html.escape(extra.group(1))) if extra else ""
            return '<span class="status-badge %s">%s</span>%s' % (cls, html.escape(label), suffix)
    return inline(text)


def build_table(block):
    headers = block["headers"]
    rows = block["rows"]
    hint = block.get("hint")
    n_cols = len(headers)

    has_header = any((h or "").strip() for h in headers)

    # Tabla ficha: dos columnas, sin encabezado significativo
    if hint == "data" or (hint is None and _looks_like_field_table(headers, rows)):
        body = ""
        for r in rows:
            body += '<tr><td class="field-label">%s</td><td>%s</td></tr>' % (
                inline(r[0]), _cell_html(r[1]))
        head = ""
        if has_header and headers[0].strip().lower() not in ("campo", ""):
            head = "<thead><tr>%s</tr></thead>" % "".join(
                "<th>%s</th>" % inline(h) for h in headers)
        return '<table class="data-table">%s<tbody>%s</tbody></table>' % (head, body)

    # Tabla comparativa: 3 columnas con semántica esperado/observado
    joined = " ".join((h or "").lower() for h in headers)
    is_compare = hint == "compare" or (
        n_cols == 3 and re.search(r"esperado|observado|antes|después|despues|original|actual", joined)
    )

    css_class = "compare-table" if is_compare else "matrix-table"

    head = "<thead><tr>%s</tr></thead>" % "".join(
        "<th>%s</th>" % inline(h) for h in headers) if has_header else ""

    body = ""
    for r in rows:
        cells = ""
        for ci, cell in enumerate(r):
            classes = []
            if is_compare and ci == 1:
                classes.append("expected")
            elif is_compare and ci == 2:
                classes.append("observed")
            if not is_compare and ci == 0 and re.fullmatch(r"\d+", str(cell).strip()):
                classes.append("rule-num")
            elif not is_compare and ci in (0, 1) and len(r) > 2 and ci == (
                    1 if re.fullmatch(r"\d+", str(r[0]).strip()) else 0):
                classes.append("rule-name")
            attr = ' class="%s"' % " ".join(classes) if classes else ""
            cells += "<td%s>%s</td>" % (attr, _cell_html(cell))
        body += "<tr>%s</tr>" % cells

    return '<table class="%s">%s<tbody>%s</tbody></table>' % (css_class, head, body)


# --------------------------------------------------------------------------
# Documento completo
# --------------------------------------------------------------------------

def build_body(blocks, charts_by_block=None, charts_by_id=None):
    charts_by_block = charts_by_block or {}
    charts_by_id = charts_by_id or {}
    out = []
    section_no = 0
    sub_no = 0
    open_section = False

    def close():
        if open_section:
            out.append("</div>")

    for pos, block in enumerate(blocks):
        kind = block["type"]

        if kind == "doc_title":
            continue

        if kind == "section":
            close()
            open_section = True
            section_no += 1
            sub_no = 0
            title = block["text"]
            extra = ""
            m = re.match(r"^(.*?)\s*\((.*?)\)\s*$", title)
            if m and len(m.group(2)) > 12:
                title, extra = m.group(1), ' <span class="subtle">(%s)</span>' % inline(m.group(2))
            out.append('<div class="section-block">')
            out.append('<h1 class="section-title"><span class="num">%d.</span>%s%s</h1>'
                       % (section_no, inline(title), extra))

        elif kind == "subsection":
            sub_no += 1
            out.append('<h2 class="subsection-title">%d.%d %s</h2>'
                       % (section_no, sub_no, inline(block["text"])))

        elif kind == "paragraph":
            out.append("<p>%s</p>" % inline(block["text"]))

        elif kind == "list":
            items = "".join("<li>%s</li>" % inline(i) for i in block["items"])
            out.append('<ul class="plain-list">%s</ul>' % items)

        elif kind == "ordered_list":
            items = "".join("<li>%s</li>" % inline(i) for i in block["items"])
            out.append('<ol class="%s">%s</ol>' % (block.get("style", "timeline"), items))

        elif kind == "callout":
            k = block["kind"]
            text = inline(block["text"])
            if k == "key":
                label = block.get("label") or "Hallazgo clave"
                out.append('<div class="rootcause-box"><span class="rc-label">%s</span>'
                           "<p>%s</p></div>" % (html.escape(label), text))
            elif k == "caveat":
                out.append('<div class="caveat-box">%s</div>' % text)
            else:
                out.append('<div class="note-box">%s</div>' % text)

        elif kind == "table":
            out.append(build_table(block))

        elif kind == "image":
            uri = _data_uri(block.get("abs_path"))
            if uri:
                pii = ('<span class="pii-tag">CONTIENE DATOS PERSONALES</span>'
                       if block.get("pii") else "")
                caption = ('<div class="evidence-caption">%s</div>' % inline(block["caption"])
                           if block.get("caption") else "")
                out.append('<div class="evidence-block">%s'
                           '<div class="evidence-img-frame"><img src="%s"></div>%s</div>'
                           % (pii, uri, caption))

        elif kind == "chart_ref":
            chart = charts_by_id.get(block["id"])
            if chart:
                out.append(_chart_html(chart))

        elif kind == "page_break":
            close()
            open_section = False
            out.append('<div class="page-break"></div>')
            continue

        # Gráficas ancladas después de este bloque
        for chart in charts_by_block.get(pos, []):
            out.append(_chart_html(chart))

    close()
    return "\n".join(out)


def _chart_html(chart):
    caption = ('<div class="chart-caption">%s</div>' % inline(chart["caption"])
               if chart.get("caption") else "")
    title = ('<div class="chart-title">%s</div>' % inline(chart["title"])
             if chart.get("title") else "")
    return ('<div class="chart-block">%s<div class="chart-frame">'
            '<img src="%s"></div>%s</div>' % (title, chart["image"], caption))


def build_document(meta, blocks, charts_by_block=None, charts_by_id=None,
                   logo_path=None, css_path=None, fallback_footer=False):
    css_path = css_path or os.path.join(ASSETS, "theme.css")
    logo_path = logo_path or os.path.join(ASSETS, "btg-logo.png")

    with open(css_path, "r", encoding="utf-8") as fh:
        css = fh.read()

    cover = build_cover(meta, logo_path)
    body = build_body(blocks, charts_by_block, charts_by_id)

    closing = meta.get("nota_cierre",
                       "BTG Pactual Colombia — Documento de uso interno. La reproducción o "
                       "distribución fuera del equipo destinatario requiere autorización previa.")
    body += '<div class="closing-note">%s</div>' % inline(closing)

    footer = ""
    if fallback_footer:
        footer = ('<div class="fallback-footer">BTG Pactual — Confidencial'
                  '<span class="right">%s</span></div>' % inline(meta.get("titulo", "")))

    return """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>%s</title>
<style>
%s
</style>
</head>
<body>
%s
%s
%s
</body>
</html>
""" % (html.escape(meta.get("titulo", "Informe BTG Pactual")), css, cover, footer, body)
