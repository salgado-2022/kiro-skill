"""
Inferencia de metadatos de portada cuando el insumo no trae frontmatter.

Criterio: lo que se puede deducir del documento se deduce; lo que es dato de
gestión (autor, destinatario) NO se inventa — se omite de la portada y se
reporta como faltante para que la persona lo confirme.

Sin dependencias externas.
"""

import datetime
import os
import re

# Campos que siempre tienen un valor por defecto seguro
DEFAULTS = {
    "clasificacion": "CONFIDENCIAL",
    "estado": "Definitivo",
    "nota_portada": ("Este documento contiene información sensible. Su distribución "
                     "debe limitarse al personal autorizado."),
    "nota_cierre": ("BTG Pactual Colombia — Documento de uso interno. La reproducción "
                    "o distribución fuera del equipo destinatario requiere "
                    "autorización previa."),
}

# Campos que jamás se inventan: si no están, no aparecen en la portada
NEVER_GUESS = ("autor", "destinatario")

# Tipos de documento. Cada patrón suma puntos; los del título pesan el triple.
# Los patrones son deliberadamente estrictos: mencionar "fraude" no convierte un
# documento de reglas en un informe de incidente.
DOC_TYPES = [
    ("Informe de incidente",
     r"\bincidente\b|\bsiniestro\b|reportad[oa] como fraude|"
     r"caso de fraude|l[íi]nea de tiempo del evento"),
    ("Informe de auditoría",
     r"\bauditor[íi]a\b|hallazgo de control|papel de trabajo"),
    ("Análisis de causa raíz",
     r"causa ra[íi]z|postmortem|post\s?mortem"),
    ("Documento de negocio",
     r"reglas? de negocio|cat[áa]logo de reglas|validacion(es)? de negocio|"
     r"control(es)? de negocio|l[óo]gica de decisi[óo]n"),
    ("Documento de análisis",
     r"\ban[áa]lisis\b|diagn[óo]stico|evaluaci[óo]n de"),
    ("Documento de propuesta",
     r"propuesta|recomendaci[óo]n|plan de acci[óo]n"),
    ("Documento de procedimiento",
     r"procedimiento|instructivo|manual de"),
]


def _detect_doc_type(title, body):
    """Elige el tipo de documento por puntaje, priorizando el título."""
    best, best_score = "Documento interno", 0
    for label, pattern in DOC_TYPES:
        score = 3 * len(re.findall(pattern, title, re.IGNORECASE))
        score += len(re.findall(pattern, body, re.IGNORECASE))
        if score > best_score:
            best, best_score = label, score
    return best


def _clean(text):
    """Quita marcas de Markdown de un valor extraído."""
    text = re.sub(r"\*\*|__|`|\*|#", "", str(text or ""))
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    return re.sub(r"\s+", " ", text).strip(" .;:")


def _truncate(text, limit=280):
    """Corta en el límite, respetando el final de una oración."""
    text = _clean(text)
    if len(text) <= limit:
        return text
    cut = text[:limit]
    for sep in (". ", "; "):
        idx = cut.rfind(sep)
        if idx > limit * 0.5:
            return cut[:idx + 1].strip()
    cut = cut.rsplit(" ", 1)[0]
    # No dejar un paréntesis abierto sin cerrar
    if cut.count("(") > cut.count(")"):
        cut = cut[:cut.rfind("(")]
    return cut.rstrip(" ,;:") + "…"


def _title_from_filename(path):
    name = os.path.splitext(os.path.basename(path))[0]
    name = re.sub(r"[-_]+", " ", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name[:1].upper() + name[1:] if name else "Informe"


def _find_code(text):
    """Busca un identificador del documento o del sistema analizado."""
    patterns = [
        r"\b([A-Z]{2,5}-\d{4}-\d{2}-\d{2})\b",            # INC-2026-06-04
        r"\b([A-Z]{2,5}-\d{3,6})\b",                       # TCK-12345
        r"\b([A-Z][a-z]+[A-Z][a-zA-Z]*\s+V\d+(?:\.\d+)?)", # AtlasCore V2
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if m:
            return m.group(1).strip()
    return None


def _find_labeled(text, labels):
    """Busca 'Etiqueta: valor' en el documento."""
    for label in labels:
        m = re.search(r"(?im)^\W{0,4}\*{0,2}%s\*{0,2}\s*:\s*\*{0,2}(.+)$" % label, text)
        if m:
            value = _clean(m.group(1))
            if value and len(value) < 160:
                return value
    return None


def _find_date(text):
    m = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", text)
    if m:
        return m.group(1)
    m = re.search(r"\b(\d{1,2}/\d{1,2}/\d{4})\b", text)
    if m:
        day, month, year = m.group(1).split("/")
        return "%s-%02d-%02d" % (year, int(month), int(day))
    return None


def _extract_preamble(blocks):
    """Toma el texto anterior a la primera sección y lo consume del cuerpo.

    Ese preámbulo suele ser el resumen del documento, así que sirve de
    subtítulo de portada sin duplicar contenido.
    """
    preamble, rest, seen_section = [], [], False
    for block in blocks:
        if block["type"] == "section":
            seen_section = True
        if not seen_section and block["type"] in ("paragraph", "callout"):
            preamble.append(block["text"])
            continue
        rest.append(block)
    return " ".join(preamble).strip(), rest


def infer(meta, blocks, source_path, raw_text=""):
    """Completa los metadatos faltantes. Devuelve (meta, blocks, informe).

    El informe indica qué se dedujo, qué vino del frontmatter y qué falta.
    """
    meta = dict(meta or {})
    report = {"declarado": [], "inferido": [], "por_defecto": [], "faltante": []}
    for key in meta:
        report["declarado"].append(key)

    # --- Subtítulo: preámbulo del documento ---
    if not meta.get("subtitulo"):
        preamble, blocks = _extract_preamble(blocks)
        if preamble and len(preamble) > 40:
            meta["subtitulo"] = _truncate(preamble)
            report["inferido"].append("subtitulo")

    # --- Título ---
    if not meta.get("titulo"):
        titles = [b["text"] for b in blocks if b["type"] == "doc_title"]
        if titles:
            meta["titulo"] = _clean(titles[0])
            report["inferido"].append("titulo")
        else:
            meta["titulo"] = _title_from_filename(source_path)
            report["inferido"].append("titulo")

    search_text = raw_text or " ".join(
        b.get("text", "") for b in blocks if b.get("text"))
    haystack = (meta.get("titulo", "") + " " + search_text)[:4000]

    # --- Kicker: tipo de documento + código detectado ---
    if not meta.get("kicker"):
        doc_type = _detect_doc_type(meta.get("titulo", ""), search_text[:6000])
        code = _find_code(haystack)
        meta["kicker"] = "%s · %s" % (doc_type, code) if code else doc_type
        report["inferido"].append("kicker")

    # --- Estado ---
    if not meta.get("estado"):
        found = _find_labeled(search_text, ["estado"])
        if found and re.match(r"(?i)^(definitivo|vigente|borrador|preliminar|final|"
                              r"en revisi[óo]n)$", found):
            meta["estado"] = found.capitalize()
            report["inferido"].append("estado")

    # --- Clasificación ---
    if not meta.get("clasificacion"):
        if re.search(r"(?i)uso interno|clasificaci[óo]n:\s*interno", haystack):
            meta["clasificacion"] = "INTERNO"
            report["inferido"].append("clasificacion")
    if not meta.get("clasificacion_larga"):
        found = _find_labeled(search_text, ["clasificaci[óo]n"])
        if found and len(found) > 12:
            meta["clasificacion_larga"] = found
            report["inferido"].append("clasificacion_larga")
        else:
            # Evita repetir literalmente la etiqueta roja de la portada
            doc_type = _detect_doc_type(meta.get("titulo", ""), search_text[:6000])
            meta["clasificacion_larga"] = "%s / información sensible" % doc_type
            report["por_defecto"].append("clasificacion_larga")

    # --- Fechas ---
    if not meta.get("fecha_evento"):
        found = _find_labeled(search_text, ["fecha del evento", "fecha del incidente",
                                            "fecha de corte", "fecha del hecho"])
        found = found or _find_date(search_text)
        if found:
            meta["fecha_evento"] = found
            report["inferido"].append("fecha_evento")

    if not meta.get("fecha_emision"):
        meta["fecha_emision"] = datetime.date.today().isoformat()
        report["por_defecto"].append("fecha_emision")

    # --- Autor y destinatario: solo si están escritos, nunca inventados ---
    if not meta.get("autor"):
        found = _find_labeled(search_text, ["elaborado por", "autor", "preparado por",
                                            "responsable"])
        if found:
            meta["autor"] = found
            report["inferido"].append("autor")
        else:
            report["faltante"].append("autor")

    if not meta.get("destinatario"):
        found = _find_labeled(search_text, ["destinatario", "dirigido a", "para"])
        if found:
            meta["destinatario"] = found
            report["inferido"].append("destinatario")
        else:
            report["faltante"].append("destinatario")

    # --- Encabezado de páginas interiores ---
    if not meta.get("encabezado"):
        code = _find_code(meta.get("kicker", "")) or _find_code(haystack)
        short = _truncate(meta["titulo"], 78)
        # No anteponer el código si el título ya lo contiene
        if code and code.lower() not in short.lower():
            meta["encabezado"] = "%s · %s" % (code, short)
        else:
            meta["encabezado"] = short
        report["inferido"].append("encabezado")

    # --- Valores por defecto ---
    for key, value in DEFAULTS.items():
        if not meta.get(key):
            meta[key] = value
            report["por_defecto"].append(key)

    # Los campos que no se pudieron deducir se eliminan para que la portada
    # no muestre filas vacías.
    for key in NEVER_GUESS:
        if not meta.get(key):
            meta.pop(key, None)

    return meta, blocks, report


def format_report(meta, report):
    """Resumen legible del origen de cada campo de portada."""
    lines = ["Metadatos de portada", "-" * 60]

    def show(keys, etiqueta):
        for key in keys:
            if key in meta:
                value = str(meta[key])
                if len(value) > 68:
                    value = value[:65] + "…"
                lines.append("  %-9s %-20s %s" % (etiqueta, key, value))

    show(report["declarado"], "[decl]")
    show(report["inferido"], "[inferido]")
    show(report["por_defecto"], "[defecto]")

    if report["faltante"]:
        lines.append("")
        lines.append("  Sin dato (se omiten de la portada): %s"
                     % ", ".join(report["faltante"]))
        lines.append("  Confirme estos valores con la persona antes de entregar;")
        lines.append("  agréguelos con --autor / --destinatario o en el frontmatter.")

    return "\n".join(lines)
