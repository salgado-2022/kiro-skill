"""
Renderizado de gráficas con identidad BTG Pactual.

Usa matplotlib (instalable con pip, sin dependencias de sistema) y devuelve
PNG en base64 para incrustar directamente en el HTML.
"""

import base64
import io
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from chart_advisor import clean_cell, parse_number

# Paleta corporativa
NAVY = "#05132A"
BLUE = "#195AB4"
BLUE_LIGHT = "#6FA0E0"
BLUE_PALE = "#B9D3F0"
GREEN = "#1E7B34"
RED = "#B3261E"
AMBER = "#C79A1E"
GRID = "#E3E7EC"
TEXT = "#1B1F24"
MUTED = "#5A6472"

SERIES_COLORS = [BLUE, NAVY, BLUE_LIGHT, AMBER, "#7A8B9E", BLUE_PALE]

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "axes.edgecolor": GRID,
    "axes.labelcolor": MUTED,
    "text.color": TEXT,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.linewidth": 0.8,
    "figure.dpi": 200,
})


def _style_axes(ax, horizontal_grid=True):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(GRID)
    ax.spines["bottom"].set_color(GRID)
    ax.set_axisbelow(True)
    if horizontal_grid:
        ax.grid(axis="y", linestyle="-", linewidth=0.8)
        ax.grid(axis="x", visible=False)
    else:
        ax.grid(axis="x", linestyle="-", linewidth=0.8)
        ax.grid(axis="y", visible=False)


def _co(value, decimals=0):
    """Formato colombiano: punto para miles, coma para decimales."""
    text = "{:,.{d}f}".format(value, d=decimals)
    return text.replace(",", "\x00").replace(".", ",").replace("\x00", ".")


def _fmt_number(value, _pos=None):
    """Etiqueta numérica compacta en convención colombiana."""
    a = abs(value)
    if a >= 1_000_000_000:
        return _co(value / 1_000_000_000, 2).rstrip("0").rstrip(",") + " MM"
    if a >= 1_000_000:
        return _co(value / 1_000_000, 1).rstrip("0").rstrip(",") + " M"
    if a >= 1000:
        return _co(value, 0)
    if value == int(value):
        return str(int(value))
    return _co(value, 1)


def _wrap(label, width=18):
    words = str(label).split()
    lines, current = [], ""
    for w in words:
        if len(current) + len(w) + 1 <= width:
            current = (current + " " + w).strip()
        else:
            if current:
                lines.append(current)
            current = w
    if current:
        lines.append(current)
    return "\n".join(lines[:3])


def _to_png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", transparent=False,
                facecolor="white", pad_inches=0.15)
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


# --------------------------------------------------------------------------
# Tipos de gráfica
# --------------------------------------------------------------------------

def _render_bar(labels, series, names, horizontal=False):
    n = len(labels)
    if horizontal:
        fig, ax = plt.subplots(figsize=(7.2, max(2.4, 0.45 * n + 1.0)))
    else:
        fig, ax = plt.subplots(figsize=(7.2, 3.4))

    if len(series) == 1:
        values = series[0]
        if horizontal:
            bars = ax.barh(range(n), values, color=BLUE, height=0.62)
            ax.set_yticks(range(n))
            ax.set_yticklabels([_wrap(l, 30) for l in labels], fontsize=8)
            ax.invert_yaxis()
            ax.xaxis.set_major_formatter(FuncFormatter(_fmt_number))
            _style_axes(ax, horizontal_grid=False)
            for b, v in zip(bars, values):
                ax.text(b.get_width() + max(values) * 0.015,
                        b.get_y() + b.get_height() / 2, _fmt_number(v),
                        va="center", fontsize=7.5, color=MUTED)
        else:
            bars = ax.bar(range(n), values, color=BLUE, width=0.6)
            ax.set_xticks(range(n))
            ax.set_xticklabels([_wrap(l) for l in labels], fontsize=8)
            ax.yaxis.set_major_formatter(FuncFormatter(_fmt_number))
            _style_axes(ax)
            for b, v in zip(bars, values):
                ax.text(b.get_x() + b.get_width() / 2,
                        b.get_height() + max(values) * 0.02, _fmt_number(v),
                        ha="center", fontsize=7.5, color=MUTED)
    else:
        width = 0.8 / len(series)
        for si, values in enumerate(series):
            offset = (si - (len(series) - 1) / 2) * width
            ax.bar([x + offset for x in range(n)], values, width=width,
                   color=SERIES_COLORS[si % len(SERIES_COLORS)],
                   label=names[si] if si < len(names) else None)
        ax.set_xticks(range(n))
        ax.set_xticklabels([_wrap(l) for l in labels], fontsize=8)
        ax.yaxis.set_major_formatter(FuncFormatter(_fmt_number))
        _style_axes(ax)
        ax.legend(frameon=False, fontsize=8, ncol=min(len(series), 4),
                  loc="upper center", bbox_to_anchor=(0.5, 1.15))

    return _to_png(fig)


def _render_line(labels, series, names):
    fig, ax = plt.subplots(figsize=(7.2, 3.4))
    for si, values in enumerate(series):
        color = SERIES_COLORS[si % len(SERIES_COLORS)]
        ax.plot(range(len(labels)), values, marker="o", markersize=4,
                linewidth=2, color=color,
                label=names[si] if si < len(names) else None)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels([_wrap(l, 12) for l in labels], fontsize=8)
    ax.yaxis.set_major_formatter(FuncFormatter(_fmt_number))
    _style_axes(ax)
    if len(series) > 1:
        ax.legend(frameon=False, fontsize=8, ncol=min(len(series), 4),
                  loc="upper center", bbox_to_anchor=(0.5, 1.15))
    return _to_png(fig)


def _render_donut(labels, values, semantic=False):
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    if semantic:
        from md_parser import status_class
        colors = []
        for i, l in enumerate(labels):
            cls, _ = status_class(l)
            colors.append({"active": GREEN, "inactive": RED,
                           "warning": AMBER}.get(cls, SERIES_COLORS[i % len(SERIES_COLORS)]))
    else:
        colors = [SERIES_COLORS[i % len(SERIES_COLORS)] for i in range(len(labels))]
    total = sum(values) or 1
    wedges, _ = ax.pie(values, colors=colors, startangle=90,
                       wedgeprops=dict(width=0.42, edgecolor="white", linewidth=2))
    ax.axis("equal")
    ax.grid(False)
    legend_labels = ["%s — %s (%.0f%%)" % (_wrap(l, 34), _fmt_number(v), v / total * 100)
                     for l, v in zip(labels, values)]
    ax.legend(wedges, legend_labels, frameon=False, fontsize=8.5,
              loc="center left", bbox_to_anchor=(0.95, 0.5))
    return _to_png(fig)


def _render_status_bar(labels, columns, column_names):
    """Compara conteos de estado entre varias columnas (ej. antes vs. ahora)."""
    from chart_advisor import is_status
    from md_parser import status_class

    categories = []
    counts = {}
    for name, col in zip(column_names, columns):
        tally = {}
        for cell in col:
            cls, text = status_class(cell)
            key = (text or clean_cell(cell) or "Sin dato").upper()
            tally[key] = tally.get(key, 0) + 1
            if key not in categories:
                categories.append(key)
        counts[name] = tally

    color_map = {}
    for cat in categories:
        cls, _ = status_class(cat)
        color_map[cat] = {"active": GREEN, "inactive": RED,
                          "warning": AMBER}.get(cls, BLUE)

    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    n_groups = len(column_names)
    width = 0.8 / max(len(categories), 1)
    for ci, cat in enumerate(categories):
        offset = (ci - (len(categories) - 1) / 2) * width
        values = [counts[name].get(cat, 0) for name in column_names]
        bars = ax.bar([x + offset for x in range(n_groups)], values, width=width,
                      color=color_map[cat], label=cat.capitalize())
        for b, v in zip(bars, values):
            if v:
                ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.06,
                        str(int(v)), ha="center", fontsize=8, color=MUTED)
    ax.set_xticks(range(n_groups))
    ax.set_xticklabels([_wrap(n, 22) for n in column_names], fontsize=8.5)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, p: str(int(v))))
    ax.set_ylabel("Cantidad", fontsize=8.5)
    _style_axes(ax)
    ax.legend(frameon=False, fontsize=8, ncol=len(categories), loc="upper center",
              bbox_to_anchor=(0.5, 1.16))
    return _to_png(fig)


# --------------------------------------------------------------------------
# Entrada principal
# --------------------------------------------------------------------------

def render(proposal, table_block):
    """Renderiza una propuesta de gráfica sobre su tabla.

    Devuelve (data-URI PNG, pie de gráfica sugerido) o (None, None).
    """
    headers = table_block["headers"]
    rows = table_block["rows"]
    chart = proposal["chart"]
    label_col = proposal.get("label_col", 0)

    labels = [clean_cell(r[label_col]) or "—" for r in rows]

    if chart == "status_bar":
        cols = [[r[i] for r in rows] for i in proposal["value_cols"]]
        names = [headers[i] for i in proposal["value_cols"]]
        return _render_status_bar(labels, cols, names), _caption_status_bar(cols, names)

    if chart == "donut" and proposal.get("value_cols"):
        idx = proposal["value_cols"][0]
        if _is_status_col(rows, idx):
            from md_parser import status_class
            tally = {}
            for r in rows:
                _, text = status_class(r[idx])
                key = (text or clean_cell(r[idx]) or "Sin dato").upper()
                tally[key] = tally.get(key, 0) + 1
            keys, vals = list(tally.keys()), list(tally.values())
            return _render_donut(keys, vals, semantic=True), _caption_donut(keys, vals)

    series, names = [], []
    for idx in proposal.get("value_cols", []):
        values = []
        for r in rows:
            v = parse_number(r[idx])
            values.append(v if v is not None else 0.0)
        series.append(values)
        names.append(headers[idx])

    if not series or not any(any(s) for s in series):
        return None, None

    if chart == "line":
        return _render_line(labels, series, names), _caption_extremes(labels, series[0], names[0])
    if chart == "donut":
        return _render_donut(labels, series[0]), _caption_donut(labels, series[0])
    if chart == "barh":
        return (_render_bar(labels, series, names, horizontal=True),
                _caption_extremes(labels, series[0], names[0]))
    return (_render_bar(labels, series, names, horizontal=False),
            _caption_extremes(labels, series[0], names[0]) if len(series) == 1 else None)


def _caption_donut(labels, values):
    total = sum(values) or 1
    top = max(range(len(values)), key=lambda i: values[i])
    return "%s concentra %.0f%% del total (%s de %s)." % (
        str(labels[top]).capitalize(), values[top] / total * 100,
        _fmt_number(values[top]), _fmt_number(total))


def _caption_extremes(labels, values, series_name):
    if not values:
        return None
    hi = max(range(len(values)), key=lambda i: values[i])
    lo = min(range(len(values)), key=lambda i: values[i])
    if hi == lo:
        return None
    return "Valor más alto en %s (%s); más bajo en %s (%s)." % (
        labels[hi], _fmt_number(values[hi]), labels[lo], _fmt_number(values[lo]))


def _caption_status_bar(cols, names):
    from md_parser import status_class
    parts = []
    for name, col in zip(names, cols):
        actives = sum(1 for c in col if status_class(c)[0] == "active")
        parts.append("%s: %d de %d activas" % (name, actives, len(col)))
    return "; ".join(parts) + "."


def _is_status_col(rows, idx):
    from chart_advisor import is_status
    vals = [r[idx] for r in rows]
    hits = sum(1 for v in vals if is_status(v))
    return vals and hits / len(vals) >= 0.7
