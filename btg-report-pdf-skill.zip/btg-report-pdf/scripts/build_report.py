#!/usr/bin/env python3
"""
Generador de reportes PDF corporativos BTG Pactual a partir de Markdown.

Uso:
    python build_report.py analizar  informe.md
    python build_report.py analizar  informe.md --json graficas.json
    python build_report.py construir informe.md -o informe.pdf
    python build_report.py construir informe.md -o informe.pdf --graficas graficas.json
    python build_report.py construir informe.md -o informe.pdf --sin-graficas
    python build_report.py construir informe.md -o informe.pdf --html salida.html
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import chart_advisor
import html_builder
import md_parser
import pdf_render

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")


def cmd_analizar(args):
    meta, blocks = md_parser.load(args.entrada)
    proposals = chart_advisor.analyze_document(blocks)

    print("Documento: %s" % meta.get("titulo", os.path.basename(args.entrada)))
    print("Bloques: %d   Tablas analizadas: %d   Propuestas: %d\n"
          % (len(blocks),
             sum(1 for b in blocks if b["type"] == "table"),
             len(proposals)))
    print(chart_advisor.describe(proposals))

    if args.json:
        payload = [{k: v for k, v in p.items() if k != "headers"} for p in proposals]
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        print("\nPropuestas guardadas en %s" % args.json)
        print("Edite 'enabled', 'chart', 'title' o 'caption' y páselas con --graficas.")
    return 0


def cmd_construir(args):
    meta, blocks = md_parser.load(args.entrada)

    # Metadatos por línea de comandos tienen prioridad
    for key in ("titulo", "subtitulo", "kicker", "clasificacion", "estado",
                "autor", "destinatario", "fecha_evento", "fecha_emision"):
        value = getattr(args, key, None)
        if value:
            meta[key] = value

    meta.setdefault("titulo", os.path.splitext(os.path.basename(args.entrada))[0])
    meta.setdefault("clasificacion", "CONFIDENCIAL")

    charts_by_block, charts_by_id = {}, {}

    if not args.sin_graficas:
        if args.graficas and os.path.exists(args.graficas):
            with open(args.graficas, "r", encoding="utf-8") as fh:
                proposals = json.load(fh)
            # Reconstruir encabezados desde el documento
            tables = [b for b in blocks if b["type"] == "table"]
            for p in proposals:
                idx = p.get("table_index", 0) - 1
                if 0 <= idx < len(tables):
                    p["headers"] = tables[idx]["headers"]
        else:
            proposals = chart_advisor.analyze_document(blocks)

        import chart_render
        tables = [b for b in blocks if b["type"] == "table"]

        for p in proposals:
            if not p.get("enabled", True):
                continue
            idx = p.get("table_index", 0) - 1
            if not (0 <= idx < len(tables)):
                continue
            try:
                image, auto_caption = chart_render.render(p, tables[idx])
            except Exception as exc:  # noqa: BLE001
                print("  · No se pudo generar la gráfica %s: %s" % (p.get("id"), exc),
                      file=sys.stderr)
                continue
            if not image:
                continue

            chart = {
                "image": image,
                "title": p.get("title"),
                "caption": p.get("caption") or auto_caption,
                "id": p.get("id"),
            }
            charts_by_id[p.get("id")] = chart
            if p.get("after_block") is not None and not args.graficas_al_final:
                charts_by_block.setdefault(p["after_block"], []).append(chart)

        n = len(charts_by_id)
        print("  · Gráficas generadas: %d" % n)

    html_content = html_builder.build_document(
        meta, blocks,
        charts_by_block=charts_by_block,
        charts_by_id=charts_by_id,
        logo_path=args.logo or os.path.join(ASSETS, "btg-logo.png"),
        css_path=args.css or os.path.join(ASSETS, "theme.css"),
        fallback_footer=args.sin_encabezados,
    )

    if args.html:
        with open(args.html, "w", encoding="utf-8") as fh:
            fh.write(html_content)
        print("  · HTML guardado en %s" % args.html)
        if args.solo_html:
            return 0

    header_title = meta.get("encabezado") or meta.get("titulo", "")
    engine = pdf_render.render(
        html_content,
        args.salida,
        header_title=header_title,
        footer_left="BTG Pactual — %s" % meta.get("clasificacion", "Confidencial").capitalize(),
        headers=not args.sin_encabezados,
        channel=args.navegador,
    )
    print("  · Motor: %s" % engine)
    print("PDF generado: %s" % args.salida)
    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Reportería corporativa BTG Pactual desde Markdown.")
    sub = parser.add_subparsers(dest="comando", required=True)

    p_an = sub.add_parser("analizar", help="Detecta qué datos son graficables")
    p_an.add_argument("entrada", help="Archivo Markdown de entrada")
    p_an.add_argument("--json", help="Guarda las propuestas en un archivo JSON editable")
    p_an.set_defaults(func=cmd_analizar)

    p_co = sub.add_parser("construir", help="Genera el PDF del reporte")
    p_co.add_argument("entrada", help="Archivo Markdown de entrada")
    p_co.add_argument("-o", "--salida", required=True, help="Ruta del PDF de salida")
    p_co.add_argument("--graficas", help="JSON de propuestas revisado")
    p_co.add_argument("--sin-graficas", action="store_true", help="No genera gráficas")
    p_co.add_argument("--graficas-al-final", action="store_true",
                      help="No ancla las gráficas junto a su tabla")
    p_co.add_argument("--html", help="También guarda el HTML intermedio")
    p_co.add_argument("--solo-html", action="store_true", help="No genera el PDF")
    p_co.add_argument("--logo", help="Ruta alterna del logo")
    p_co.add_argument("--css", help="Ruta alterna de la hoja de estilos")
    p_co.add_argument("--navegador", choices=["msedge", "chrome"],
                      help="Fuerza un canal de navegador específico")
    p_co.add_argument("--sin-encabezados", action="store_true",
                      help="Omite encabezado/pie nativos (modo de respaldo)")
    for key in ("titulo", "subtitulo", "kicker", "clasificacion", "estado",
                "autor", "destinatario", "fecha_evento", "fecha_emision"):
        p_co.add_argument("--" + key)
    p_co.set_defaults(func=cmd_construir)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
