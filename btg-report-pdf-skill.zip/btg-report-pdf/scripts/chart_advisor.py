"""
Analizador de datos graficables para reportería BTG Pactual.

Recorre las tablas del documento, clasifica cada columna y decide si vale la
pena graficar y con qué tipo de gráfica. Devuelve propuestas con justificación
y nivel de confianza, para que el agente pueda revisarlas antes de construir
el PDF.

Sin dependencias externas.
"""

import re

# --------------------------------------------------------------------------
# Clasificación de columnas
# --------------------------------------------------------------------------

_MONTHS = ("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")

_STATUS_TOKENS = {
    "activa", "activo", "desactivada", "desactivado", "inactiva", "inactivo",
    "sí", "si", "no", "vigente", "pendiente", "ok", "falla", "fallido",
    "cumple", "aprobado", "rechazado", "parcial",
}


def clean_cell(value):
    """Quita marcas de formato de una celda."""
    text = str(value or "")
    text = re.sub(r"\*\*|__|`|\*", "", text)
    text = re.sub(r"<[^>]+>", "", text)
    return text.strip()


def parse_number(value):
    """Intenta interpretar una celda como número. Devuelve None si no aplica."""
    text = clean_cell(value)
    if not text:
        return None

    # Descartar celdas que son claramente texto largo
    if len(text) > 40:
        return None

    is_pct = "%" in text
    # Quitar moneda y unidades
    text = re.sub(r"(?i)\b(cop|usd|eur|mm|m|k)\b", "", text)
    text = text.replace("$", "").replace("%", "").strip()

    # Solo dígitos, separadores y signo
    if not re.fullmatch(r"[-+]?[\d.,\s]+", text):
        return None
    if not re.search(r"\d", text):
        return None

    compact = text.replace(" ", "")

    # Formato colombiano: 1.234.567,89 → punto de miles, coma decimal
    if "," in compact and "." in compact:
        if compact.rfind(",") > compact.rfind("."):
            compact = compact.replace(".", "").replace(",", ".")
        else:
            compact = compact.replace(",", "")
    elif "," in compact:
        # Coma como decimal si hay 1-2 dígitos después
        parts = compact.split(",")
        if len(parts) == 2 and len(parts[1]) in (1, 2):
            compact = compact.replace(",", ".")
        else:
            compact = compact.replace(",", "")
    elif "." in compact:
        # Punto de miles si los grupos son de 3 dígitos
        parts = compact.split(".")
        if len(parts) > 2 or (len(parts) == 2 and len(parts[1]) == 3):
            compact = compact.replace(".", "")

    try:
        num = float(compact)
    except ValueError:
        return None
    return num * (1.0 if not is_pct else 1.0)


def is_temporal(value):
    """Detecta fechas, periodos o meses."""
    text = clean_cell(value).lower()
    if not text:
        return False
    if re.search(r"\d{4}-\d{2}(-\d{2})?", text):
        return True
    if re.search(r"\d{1,2}/\d{1,2}/\d{2,4}", text):
        return True
    if re.fullmatch(r"(19|20)\d{2}", text):
        return True
    if re.search(r"\bq[1-4]\b|\bt[1-4]\b", text):
        return True
    if any(text.startswith(m) for m in _MONTHS):
        return True
    if re.search(r"semana\s*\d+|mes\s*\d+|día\s*\d+", text):
        return True
    return False


def is_status(value):
    text = clean_cell(value).lower()
    if "✅" in str(value) or "❌" in str(value) or "✓" in str(value) or "✗" in str(value):
        return True
    text = re.sub(r"\s*\(.*?\)\s*", "", text).strip()
    return text in _STATUS_TOKENS


def is_index_column(header, cells):
    """Detecta columnas de numeración/identificador, que no son una medida."""
    h = clean_cell(header).lower().strip()
    if h in ("#", "no.", "nro", "núm", "num", "id", "ítem", "item", "orden"):
        return True
    values = [clean_cell(c) for c in cells if clean_cell(c)]
    if len(values) < 3:
        return False
    nums = [parse_number(v) for v in values]
    if any(n is None for n in nums):
        return False
    ints = [int(n) for n in nums if n == int(n)]
    if len(ints) != len(nums):
        return False
    # Secuencia consecutiva 1,2,3... o estrictamente creciente de paso 1
    return ints == list(range(ints[0], ints[0] + len(ints)))


def classify_column(cells):
    """Clasifica una columna: numeric | temporal | status | text."""
    values = [clean_cell(c) for c in cells]
    filled = [v for v in values if v]
    if not filled:
        return "empty", {}

    n = len(filled)
    numeric = [parse_number(v) for v in filled]
    n_numeric = sum(1 for v in numeric if v is not None)
    n_temporal = sum(1 for v in filled if is_temporal(v))
    n_status = sum(1 for v in filled if is_status(v))

    if n_temporal / n >= 0.7:
        return "temporal", {"values": filled}
    if n_status / n >= 0.7:
        return "status", {"values": filled}
    if n_numeric / n >= 0.7:
        return "numeric", {
            "values": [v for v in numeric if v is not None],
            "raw": filled,
            "is_pct": sum(1 for v in filled if "%" in v) / n >= 0.5,
        }

    uniq = len(set(filled))
    return "text", {"values": filled, "unique": uniq, "avg_len": sum(len(v) for v in filled) / n}


# --------------------------------------------------------------------------
# Decisión del tipo de gráfica
# --------------------------------------------------------------------------

def analyze_table(headers, rows, table_index, section=None):
    """Analiza una tabla y devuelve una lista de propuestas de gráfica."""
    if not rows or not headers:
        return []

    cols = list(zip(*rows)) if rows else []
    if len(cols) != len(headers):
        return []

    kinds = []
    for c in cols:
        kind, info = classify_column(c)
        kinds.append((kind, info))

    index_idx = [i for i in range(len(headers)) if is_index_column(headers[i], cols[i])]
    numeric_idx = [i for i, (k, _) in enumerate(kinds)
                   if k == "numeric" and i not in index_idx]
    temporal_idx = [i for i, (k, _) in enumerate(kinds) if k == "temporal"]
    status_idx = [i for i, (k, _) in enumerate(kinds) if k == "status"]
    text_idx = [i for i, (k, _) in enumerate(kinds)
                if k == "text" and i not in index_idx]
    if not text_idx:
        # Sin columna de texto clara, usar la primera que no sea índice ni medida
        text_idx = [i for i in range(len(headers))
                    if i not in index_idx and i not in numeric_idx
                    and i not in status_idx and i not in temporal_idx]

    n_rows = len(rows)
    proposals = []
    base = {"table_index": table_index, "section": section, "headers": headers}

    # --- Caso 1: serie temporal ---------------------------------------------
    if temporal_idx and numeric_idx:
        t = temporal_idx[0]
        series = numeric_idx[:4]
        proposals.append(dict(base,
            id="g%d_tendencia" % table_index,
            chart="line" if n_rows >= 4 else "bar",
            label_col=t,
            value_cols=series,
            title="Evolución de %s" % _join([headers[i] for i in series]),
            rationale=("Hay una columna temporal (%s) con %d puntos y valores numéricos; "
                       "una línea muestra la tendencia mejor que la tabla."
                       % (headers[t], n_rows)) if n_rows >= 4 else
                      ("Hay una columna temporal con pocos puntos (%d); "
                       "las barras comparan mejor que una línea." % n_rows),
            confidence=0.9,
        ))
        return proposals

    # --- Caso 2: columnas de estado (activa/desactivada) --------------------
    if status_idx and n_rows >= 3:
        label = text_idx[0] if text_idx else 0
        proposals.append(dict(base,
            id="g%d_estados" % table_index,
            chart="status_bar" if len(status_idx) > 1 else "donut",
            label_col=label,
            value_cols=status_idx,
            title=("Comparativo de %s" % _join([headers[i] for i in status_idx]))
                  if len(status_idx) > 1
                  else ("Distribución por %s" % (headers[status_idx[0]] or "estado").lower()),
            rationale=("Se detectaron %d columna(s) de estado sobre %d elementos. "
                       "%s" % (len(status_idx), n_rows,
                               "Un comparativo de barras muestra el cambio entre los dos estados."
                               if len(status_idx) > 1 else
                               "Un anillo muestra la proporción del estado actual.")),
            confidence=0.85,
        ))
        return proposals

    # --- Caso 3: categoría + valores numéricos ------------------------------
    if numeric_idx and (text_idx or n_rows):
        label = text_idx[0] if text_idx else None
        if label is None:
            return proposals

        labels = [clean_cell(r[label]) for r in rows]
        avg_len = sum(len(l) for l in labels) / max(len(labels), 1)
        info = kinds[numeric_idx[0]][1]
        values = info.get("values", [])

        # ¿Es reparto de un total?
        total = sum(values) if values else 0
        looks_share = (
            len(numeric_idx) == 1
            and n_rows <= 6
            and values
            and (
                (info.get("is_pct") and 95 <= total <= 105)
                or re.search(r"(?i)particip|porcentaje|share|distribu|composici|%",
                             headers[numeric_idx[0]] or "")
            )
        )

        if looks_share:
            chart, why = "donut", ("Los valores son una participación sobre el total (%d categorías); "
                                   "un anillo comunica la composición de un vistazo." % n_rows)
            conf = 0.8
        elif len(numeric_idx) >= 2 and n_rows <= 8:
            chart, why = "grouped_bar", ("Hay %d series numéricas sobre %d categorías; "
                                         "las barras agrupadas permiten compararlas lado a lado."
                                         % (len(numeric_idx), n_rows))
            conf = 0.8
        elif n_rows > 10 or avg_len > 22:
            chart, why = "barh", ("Hay %d categorías con etiquetas largas; las barras horizontales "
                                  "evitan que los rótulos se solapen." % n_rows)
            conf = 0.75
        elif n_rows >= 2:
            chart, why = "bar", ("Una categoría con valores numéricos sobre %d elementos; "
                                 "las barras verticales comparan magnitudes directamente." % n_rows)
            conf = 0.75
        else:
            return proposals

        proposals.append(dict(base,
            id="g%d_%s" % (table_index, chart),
            chart=chart,
            label_col=label,
            value_cols=numeric_idx[:4],
            title=_title_for(headers, label, numeric_idx),
            rationale=why,
            confidence=conf,
        ))

    return proposals


def _join(items):
    items = [i for i in items if i]
    if not items:
        return "los valores"
    if len(items) == 1:
        return items[0].lower()
    return ", ".join(i.lower() for i in items[:-1]) + " y " + items[-1].lower()


def _title_for(headers, label_idx, value_idx):
    vals = _join([headers[i] for i in value_idx])
    cat = (headers[label_idx] or "categoría").lower()
    return "%s por %s" % (vals[:1].upper() + vals[1:], cat)


# --------------------------------------------------------------------------
# Recorrido del documento
# --------------------------------------------------------------------------

def analyze_document(blocks):
    """Recorre los bloques y devuelve todas las propuestas de gráfica."""
    proposals = []
    current_section = None
    table_index = 0

    for pos, block in enumerate(blocks):
        if block["type"] == "section":
            current_section = block["text"]
        elif block["type"] == "table":
            table_index += 1
            found = analyze_table(
                block["headers"], block["rows"], table_index, current_section
            )
            for p in found:
                p["after_block"] = pos
                p["enabled"] = p["confidence"] >= 0.75
            proposals.extend(found)

    return proposals


def describe(proposals):
    """Resumen legible de las propuestas, para mostrar al usuario."""
    if not proposals:
        return "No se encontraron datos graficables en el documento."
    lines = []
    for p in proposals:
        mark = "✓" if p.get("enabled") else "·"
        lines.append(
            "%s [%s] %s\n    tipo: %s   confianza: %.0f%%   sección: %s\n    razón: %s"
            % (mark, p["id"], p["title"], p["chart"], p["confidence"] * 100,
               p.get("section") or "—", p["rationale"])
        )
    return "\n".join(lines)
